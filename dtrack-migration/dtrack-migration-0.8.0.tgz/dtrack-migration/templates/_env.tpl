{{/*
Target (v5) database env vars for v4-migrator (bootstrap + run).
Usage: include "dtrack-migration.targetEnv" .
*/}}
{{- define "dtrack-migration.targetEnv" -}}
{{- $target := .Values.target -}}
- name: TARGET_URL
  value: {{ printf "%s?sslmode=disable" (required "target.jdbcUrl is required" $target.jdbcUrl) | quote }}
- name: TARGET_USER
  valueFrom:
    secretKeyRef:
      name: {{ required "target.usernameSecret.name is required" $target.usernameSecret.name }}
      key: {{ required "target.usernameSecret.key is required" $target.usernameSecret.key }}
- name: TARGET_PASS
  valueFrom:
    secretKeyRef:
      name: {{ required "target.passwordSecret.name is required" $target.passwordSecret.name }}
      key: {{ required "target.passwordSecret.key is required" $target.passwordSecret.key }}
{{- end }}

{{/*
Source (v4) database env vars for v4-migrator (run).
Usage: include "dtrack-migration.sourceEnv" .
*/}}
{{- define "dtrack-migration.sourceEnv" -}}
{{- $source := .Values.source -}}
- name: SOURCE_URL
  value: {{ required "source.jdbcUrl is required" $source.jdbcUrl | quote }}
- name: SOURCE_USER
  valueFrom:
    secretKeyRef:
      name: {{ required "source.usernameSecret.name is required" $source.usernameSecret.name }}
      key: {{ required "source.usernameSecret.key is required" $source.usernameSecret.key }}
- name: SOURCE_PASS
  valueFrom:
    secretKeyRef:
      name: {{ required "source.passwordSecret.name is required" $source.passwordSecret.name }}
      key: {{ required "source.passwordSecret.key is required" $source.passwordSecret.key }}
{{- end }}
