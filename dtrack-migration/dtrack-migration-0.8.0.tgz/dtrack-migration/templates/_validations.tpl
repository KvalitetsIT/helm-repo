{{/*
Validate a source/target database block: jdbcUrl required + PostgreSQL JDBC shape, all four secret
name/key fields required.
Usage: include "dtrack-migration.validateDatabaseBlock" (dict "label" "source" "db" .Values.source)
*/}}
{{- define "dtrack-migration.validateDatabaseBlock" -}}
{{- $label := .label -}}
{{- $db := .db -}}
{{- $jdbcUrl := required (printf "%s.jdbcUrl is required" $label) ($db.jdbcUrl | default "" | trim) -}}
{{- if not (regexMatch `^jdbc:postgresql://[^/:]+(:[0-9]+)?/[^/?]+(\?.*)?$` $jdbcUrl) -}}
  {{- fail (printf "%s.jdbcUrl must be a valid PostgreSQL JDBC URL" $label) -}}
{{- end -}}
{{- $_ := required (printf "%s.usernameSecret.name is required" $label) ($db.usernameSecret.name | default "" | trim) -}}
{{- $_ := required (printf "%s.usernameSecret.key is required" $label) ($db.usernameSecret.key | default "" | trim) -}}
{{- $_ := required (printf "%s.passwordSecret.name is required" $label) ($db.passwordSecret.name | default "" | trim) -}}
{{- $_ := required (printf "%s.passwordSecret.key is required" $label) ($db.passwordSecret.key | default "" | trim) -}}
{{- end -}}

{{/*
Full chart validation, run from templates/job.yaml on every render.
*/}}
{{- define "dtrack-migration.validate" -}}
{{- include "dtrack-migration.validateDatabaseBlock" (dict "label" "source" "db" .Values.source) -}}
{{- include "dtrack-migration.validateDatabaseBlock" (dict "label" "target" "db" .Values.target) -}}
{{- $sourceHost := include "dtrack-migration.jdbcHost" .Values.source.jdbcUrl | lower -}}
{{- $targetHost := include "dtrack-migration.jdbcHost" .Values.target.jdbcUrl | lower -}}
{{- if eq $sourceHost $targetHost -}}
  {{- fail (printf "source host %q must differ from target host %q" $sourceHost $targetHost) -}}
{{- end -}}
{{- if .Values.offlineGuard.enabled -}}
{{- if not (.Values.offlineGuard.url | default "" | trim) -}}
  {{- fail "offlineGuard.url is required when offlineGuard.enabled is true" -}}
{{- end -}}
{{- if le (int .Values.offlineGuard.timeoutSeconds) 0 -}}
  {{- fail "offlineGuard.timeoutSeconds must be greater than zero" -}}
{{- end -}}
{{- if le (int .Values.offlineGuard.periodSeconds) 0 -}}
  {{- fail "offlineGuard.periodSeconds must be greater than zero" -}}
{{- end -}}
{{- if le (int .Values.offlineGuard.failureThreshold) 0 -}}
  {{- fail "offlineGuard.failureThreshold must be greater than zero" -}}
{{- end -}}
{{- end -}}
{{- if lt (int .Values.metricsRetentionDays) 0 -}}
  {{- fail "metricsRetentionDays must be zero or greater" -}}
{{- end -}}
{{- end -}}
