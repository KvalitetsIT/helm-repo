{{/*
Expand the chart name used in labels. nameOverride intentionally follows kitapp-style semantics.
*/}}
{{- define "dtrack-migration.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "dtrack-migration.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dtrack-migration.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dtrack-migration.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.commonAnnotations }}
{{- $annotations = merge $annotations .Values.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Build complete image reference from the configured image fields.
Usage: imageRef $component (e.g., imageRef $values.image)
*/}}
{{- define "imageRef" -}}
{{- $registry := .registry | default "" -}}
{{- $repository := .repository -}}
{{- $digest := .digest | default "" -}}
{{- $tag := .tag | default "latest" -}}
{{- $image := $repository -}}
{{- if and $registry $repository -}}
  {{- $image = printf "%s/%s" $registry $repository -}}
{{- end -}}
{{- if $digest -}}
{{- printf "%s:%s@%s" $image $tag $digest -}}
{{- else -}}
{{- printf "%s:%s" $image $tag -}}
{{- end -}}
{{- end }}

{{/*
Build image reference for a component. global.image.registry takes precedence; falls back to image.registry.
Usage: include "dtrack-migration.imageRef" (dict "image" .Values.image "global" .Values.global)
*/}}
{{- define "dtrack-migration.imageRef" -}}
{{- include "imageRef" (dict
    "registry" (.global.image.registry | default .image.registry | default "")
    "repository" .image.repository
    "tag" .image.tag
    "digest" .image.digest
) -}}
{{- end }}

{{/*
Extract the host from a PostgreSQL JDBC URL.
Usage: include "dtrack-migration.jdbcHost" .Values.source.jdbcUrl
*/}}
{{- define "dtrack-migration.jdbcHost" -}}
{{- $withoutScheme := trimPrefix "jdbc:postgresql://" (. | trim) -}}
{{- $hostPort := (splitList "/" $withoutScheme | first) -}}
{{- (splitList ":" $hostPort | first) -}}
{{- end }}
