# CI Values Profiles

Chart-testing values files for `dtrack-migration`.

### `migrate-values.yaml`

Positive fixture: distinct source (v4) and target (v5) hosts, all four secrets set, `offlineGuard.url`
set. `helm template`/`helm lint` must pass.

### `same-host-values.yaml`

Negative fixture. `source.jdbcUrl` and `target.jdbcUrl` point at the same host. Since the migration
target must be a different database than the source, `helm template` must fail with a validation
error. Do not include in the all-profiles smoke loop.

### `missing-source-values.yaml`

Negative fixture. `source.jdbcUrl` is absent. `helm template` must fail with a validation error. Do
not include in the all-profiles smoke loop.

## Usage

```bash
helm template test charts/dtrack-migration -f charts/dtrack-migration/ci/migrate-values.yaml
```
