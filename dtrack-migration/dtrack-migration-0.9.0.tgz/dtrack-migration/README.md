# dtrack-migration Helm Chart

![Version: 0.9.0](https://img.shields.io/badge/Version-0.9.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.9.0](https://img.shields.io/badge/AppVersion-0.9.0-informational?style=flat-square)

This chart runs a one-shot Dependency-Track v4-to-v5 database migration as a Kubernetes Job, using
the [v4-migrator](https://dependencytrack.github.io/docs/next/guides/administration/migrating-from-v4/)
image. It is a standalone, separately installed chart: migration is a one-time, out-of-band
operation, not a steady-state part of the `dtrack` chart. Installing `dtrack-migration` IS the
intent to migrate; the Job always renders, there is no `enabled` gate.

## Prerequisites

- The existing v4 PostgreSQL database (source), reachable from the Job.
- A freshly provisioned v5 PostgreSQL database (target), reachable from the Job. Install it
  separately, for example with the [KvalitetsIT cnpg-cluster chart](https://artifacthub.io/packages/helm/kvalitetsit/cnpg-cluster).
- The v4 Dependency-Track backend must be stopped before the migration runs. This chart's offline
  guard verifies that from the outside; it does not stop the backend for you.

## Runbook

1. Scale the v4 `dtrack` release's backend (and frontend) down to zero replicas. If a v5 backend
   already exists pointed at the target database, scale it down too. Nothing should write to either
   database while the migration Job runs.
2. Install this chart with `source` pointing at the v4 database and `target` pointing at the v5
   database:

   ```yaml
   source:
     jdbcUrl: "jdbc:postgresql://v4-postgresql:5432/dtrack"
     usernameSecret:
       name: dtrack-v4-postgres-credentials
       key: username
     passwordSecret:
       name: dtrack-v4-postgres-credentials
       key: password

   target:
     jdbcUrl: "jdbc:postgresql://v5-postgresql:5432/dtrack"
     usernameSecret:
       name: dtrack-v5-postgres-credentials
       key: username
     passwordSecret:
       name: dtrack-v5-postgres-credentials
       key: password

   offlineGuard:
     url: "http://dtrack-v4-backend.dtrack.svc.cluster.local:8080/api"
   ```

   ```bash
   helm install dtrack-migration ./charts/dtrack-migration -f my-migration-values.yaml
   ```

3. The `wait-for-backend-offline` init container polls `offlineGuard.url` and only allows the
   migration to proceed once it observes `offlineGuard.failureThreshold` consecutive failed probes
   within `offlineGuard.timeoutSeconds`. This is the real safety interlock: since the v5 backend is
   not installed until after this chart finishes, nothing else writes to the target database while
   the Job runs. Set `offlineGuard.enabled: false` only if you have another way to guarantee the v4
   backend is stopped.
4. Watch the Job:

   ```bash
   kubectl logs job/dtrack-migration -c migration-bootstrap
   kubectl logs job/dtrack-migration -c migration
   ```

5. Once the Job completes successfully, upgrade the `dtrack` release to Dependency-Track v5 with
   `backend.database` pointing at the target database used above, then remove this chart:

   ```bash
   helm uninstall dtrack-migration
   ```

6. Re-run the `dtrack` bootstrap job. The v4-migrator nulls out DB-encrypted secret values
   (repository passwords, integration tokens) as part of the migration, so those credentials do not
   exist in the v5 database until bootstrap re-seeds them through the API, where v5 KEK-encrypts
   them under the fresh key.

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| nameOverride | string | `""` | Override the release/name base used for resource naming and labels. |
| fullnameOverride | string | `""` | Override the fully qualified name used for resource naming and labels. |
| commonAnnotations | object | `{}` | Common annotations added to the Job. |
| global | object | See [values.yaml](values.yaml) | Global configuration options, kept namespace-compatible with the dtrack chart's global block. |
| global.imagePullSecrets | list | `[]` | Image pull secrets applied to the Job. Merged with image.pullSecrets. |
| global.image.registry | string | `""` | Registry prefix applied to the migrator image. Takes precedence over image.registry. |
| global.waitForBackend | object | See [values.yaml](values.yaml) | Image used by the offline-guard init container that probes the v4 backend. |
| global.waitForBackend.image.registry | string | `"docker.io"` | Fallback registry prefix for the wait-for-backend image. Overridden by global.image.registry when set. |
| global.waitForBackend.image.repository | string | `"library/busybox"` | Image repository path (without registry prefix) |
| global.waitForBackend.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| global.waitForBackend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| global.waitForBackend.image.tag | string | `"1.37"` | Image tag |

### Migration Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image | object | See [values.yaml](values.yaml) | v4-migrator image used for both the bootstrap and run steps. |
| image.registry | string | `""` | Fallback registry prefix for the migrator image. Overridden by global.image.registry when set. |
| image.repository | string | `"dependencytrack/v4-migrator"` | Migrator image repository |
| image.tag | string | `"5.0.2"` | Migrator image tag |
| image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.pullSecrets | list | `[]` | Image pull secrets for the Job. Merged with global.imagePullSecrets. |
| source | object | See [values.yaml](values.yaml) | Connection details for the existing v4 source PostgreSQL database. |
| source.jdbcUrl | string | `""` | JDBC URL for the v4 source database (e.g. jdbc:postgresql://v4-postgres:5432/dtrack). Required. |
| source.usernameSecret | object | `{"key":"","name":""}` | Secret containing the v4 database username |
| source.passwordSecret | object | `{"key":"","name":""}` | Secret containing the v4 database password |
| target | object | See [values.yaml](values.yaml) | Connection details for the v5 target PostgreSQL database. |
| target.jdbcUrl | string | `""` | JDBC URL for the v5 target database (e.g. jdbc:postgresql://v5-postgres:5432/dtrack). Required, and must differ from source.jdbcUrl. |
| target.usernameSecret | object | `{"key":"","name":""}` | Secret containing the v5 database username |
| target.passwordSecret | object | `{"key":"","name":""}` | Secret containing the v5 database password |
| offlineGuard | object | See [values.yaml](values.yaml) | Bounded probe that requires consecutive backend API failures before database work starts. |
| offlineGuard.enabled | bool | `true` | Run the wait-for-backend-offline init container before the migration starts. |
| offlineGuard.url | string | `""` | Backend API base URL the guard probes for offline confirmation, pointing at the v4 backend being drained. Required when offlineGuard.enabled is true. |
| offlineGuard.timeoutSeconds | int | `300` | Maximum seconds to wait for the backend API to become unavailable |
| offlineGuard.periodSeconds | int | `5` | Seconds between backend API probes |
| offlineGuard.failureThreshold | int | `3` | Consecutive failed probes required to prove the backend is offline |
| metricsRetentionDays | int | `90` | Number of days of metrics history to migrate. 0 for none, large number for all. |
| resources | object | `{}` | Resource requests and limits for the migration Job containers. |
