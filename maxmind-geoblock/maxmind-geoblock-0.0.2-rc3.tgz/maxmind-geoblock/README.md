# maxmind-geoblock Helm Chart

This chart deploys the two GeoIP services behind Istio:

- `geoLookupService`: downloads and caches the MaxMind GeoLite2 database
- `geoAccessValidator`: evaluates requests and allows or denies access based on the GeoIP country lookup

The chart is designed to work with Istio and Gateway API. The validator is exposed through an Istio `AuthorizationPolicy` that uses an external authorization provider.

## Requirements

- Istio installed in the cluster
- Gateway API CRDs installed and enabled in Istio
- A working `extensionProviders` configuration in `istiod`
- A non-empty `geoAccessValidator.allowedCountries` list
- Optional: `imagePullSecrets` if your registry is private

If `geoAccessValidator.allowedCountries` is empty or missing, Helm rendering fails on purpose.

## Istio configuration

Add the following to your Istio configuration. Adjust the namespace and service name to match your release:

```yaml
istiod:
  meshConfig:
    defaultConfig:
      gatewayTopology:
        proxyProtocol: {}
    extensionProviders:
      - name: geoaccessvalidator
        envoyExtAuthzHttp:
          service: maxmind-geoblock-validator.istio-ingress.svc.cluster.local
          port: 8080
          pathPrefix: /auth
          timeout: 500ms
          includeRequestHeadersInCheck:
            - x-forwarded-for
            - x-request-id
            - x-envoy-external-address

gatewayApiCrds:
  enabled: true
  application:
    metadata:
      namespace: infrastructure
    syncPolicy:
      syncOptions:
        - CreateNamespace=false
        - ServerSideApply=true
        - FailOnSharedResource=true
```

The `extensionProviders` entry above is the one the chart expects. The `providerName` in the chart values must match the provider name you configure in Istio.

## AuthorizationPolicy

The chart includes an Istio `AuthorizationPolicy` template that attaches to the Gateway and calls the external auth provider.

Default values:
- `authorizationPolicy.enabled: true`
- `authorizationPolicy.namespace: istio-ingress`
- `authorizationPolicy.gatewayName: ingressgateway`
- `authorizationPolicy.providerName: geoaccessvalidator`

If your Gateway is in another namespace or has another name, adjust those values.

## Allowed countries

`geoAccessValidator.allowedCountries` is required and must contain at least one ISO country code.

Example using the country list that is currently hardcoded in the validator:

```yaml
geoAccessValidator:
  allowedCountries:
    - AT
    - BE
    - BG
    - HR
    - CY
    - CZ
    - DK
    - EE
    - FI
    - FR
    - DE
    - GR
    - HU
    - IE
    - IT
    - LV
    - LT
    - LU
    - MT
    - NL
    - PL
    - PT
    - RO
    - SK
    - SI
    - ES
    - SE
    - NO
    - CH
    - GB
```

If you want a smaller list, just reduce it to the countries you want to allow.

## Image pull secret

If the images are stored in a private registry, set the global pull secret in `values.yaml`:

```yaml
imagePullSecrets:
  - name: my-registry-pullsecret
```

The secret is applied to both pod specs in the chart.

## Monitoring

The chart can also create:

- `ServiceMonitor` resources for both services
- `PrometheusRule` alerts for stale database and refresh failures
- `PodDisruptionBudget` for the validator
- `HorizontalPodAutoscaler` for the validator

These are enabled by default in `values.yaml`.

## Local render test

From the repository root:

```bash
helm lint ./helm -f ./helm/values.ci.yaml
helm template maxmind-geoblock ./helm -f ./helm/values.ci.yaml
```

The `values.ci.yaml` file contains the required `allowedCountries` list for rendering and CI validation.
