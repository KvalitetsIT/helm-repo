# maxmind-geoblock Helm Chart

This chart deploys the two GeoIP services behind Istio:

- `geoLookupService`: downloads and caches the MaxMind GeoLite2 database
- `geoAccessValidator`: evaluates requests and allows or denies access based on the GeoIP country lookup

`geoLookupService` supports a startup bootstrap mode for empty PVCs:

- `geoLookupService.env.bootstrap: "true"`

When enabled and the PVC is empty, the service fetches the initial database from MaxMind before starting the server.
If the fetch fails (for example missing/invalid license key), startup fails fast.

The chart is designed to work with Istio and Gateway API. The validator is exposed through an Istio `AuthorizationPolicy` that uses an external authorization provider.

## Requirements

- Istio installed in the cluster
- Gateway API CRDs installed and enabled in Istio
- A working `extensionProviders` configuration in `istiod`
- A non-empty `geoAccessValidator.allowedCountries` list
- Optional: `imagePullSecrets` if your registry is private

If `geoAccessValidator.allowedCountries` is empty or missing, Helm rendering fails on purpose.

## Istio configuration

Add the following to your Istio configuration. Adjust the namespace and service name to match your release:

```yaml
istiod:
  meshConfig:
    defaultConfig:
      gatewayTopology:
        proxyProtocol: {}
    extensionProviders:
      - name: geoaccessvalidator
        envoyExtAuthzHttp:
          service: maxmind-geoblock-validator.istio-ingress.svc.cluster.local
          port: 8080
          pathPrefix: /auth
          timeout: 500ms
          includeRequestHeadersInCheck:
            - x-forwarded-for
            - x-request-id
            - x-envoy-external-address

gatewayApiCrds:
  enabled: true
  application:
    metadata:
      namespace: infrastructure
    syncPolicy:
      syncOptions:
        - CreateNamespace=false
        - ServerSideApply=true
        - FailOnSharedResource=true
```

The `extensionProviders` entry above is the one the chart expects. The `providerName` in the chart values must match the provider name you configure in Istio.

## AuthorizationPolicy

The chart includes an Istio `AuthorizationPolicy` template that attaches to the Gateway and calls the external auth provider.

Default values:
- `authorizationPolicy.enabled: true`
- `authorizationPolicy.namespace: istio-ingress`
- `authorizationPolicy.gatewayName: ingressgateway`
- `authorizationPolicy.providerName: geoaccessvalidator`

If your Gateway is in another namespace or has another name, adjust those values.

## Allowed countries

`geoAccessValidator.allowedCountries` is required and must contain at least one ISO country code.

Example using the country list that is currently hardcoded in the validator:

```yaml
geoAccessValidator:
  allowedCountries:
    - AT
    - BE
    - BG
    - HR
    - CY
    - CZ
    - DK
    - EE
    - FI
    - FR
    - DE
    - GR
    - HU
    - IE
    - IT
    - LV
    - LT
    - LU
    - MT
    - NL
    - PL
    - PT
    - RO
    - SK
    - SI
    - ES
    - SE
    - NO
    - CH
    - GB
```

If you want a smaller list, just reduce it to the countries you want to allow.

## Emergency bypass

The validator supports a fail-open toggle:

- `geoAccessValidator.env.ALWAYS_RETURN_OK: "false"` by default

When set to `"true"`, the auth service skips GeoIP validation and returns `200 OK` for all auth checks. This can be used as a temporary emergency switch if the GeoIP validation path needs to be bypassed.

## Image pull secret

If the images are stored in a private registry, set the global pull secret in `values.yaml`:

```yaml
imagePullSecrets:
  - name: my-registry-pullsecret
```

The secret is applied to both pod specs in the chart.

## Image tags and chart version

If `geoLookupService.image.tag` and `geoAccessValidator.image.tag` are left empty,
the chart uses `Chart.AppVersion` as image tag for both services.

This means a released chart version (for example `0.0.2-rc5`) will by default deploy:

- `kvalitetsit/geolookupservice:0.0.2-rc5`
- `kvalitetsit/geoaccessvalidator:0.0.2-rc5`

You can still override tags explicitly in values if needed.

## Runtime hardening

The chart enables baseline runtime hardening for both workloads by default:

- `runAsNonRoot: true`
- `readOnlyRootFilesystem: true`
- `allowPrivilegeEscalation: false`
- drop all Linux capabilities
- `seccompProfile: RuntimeDefault`

Because root filesystem is read-only, the chart mounts `/tmp` as `emptyDir` for both services.
The lookup service also writes the GeoIP database to its mounted PVC path.

You can tune these settings in `values.yaml` under `securityContext`.

## Monitoring

The chart can also create:

- `ServiceMonitor` resources for both services
- `PrometheusRule` alerts for stale database and refresh failures
- `PodDisruptionBudget` for the validator
- `HorizontalPodAutoscaler` for the validator

These are enabled by default in `values.yaml`.

If your Prometheus stack only selects `ServiceMonitor` / `PrometheusRule` objects by specific labels
(common with kube-prometheus-stack), set matching labels in this chart:

```yaml
monitoring:
  selectorLabels:
    release: prometheus-stack
```

If your Prometheus stack runs in another namespace, you can place monitoring resources there:

```yaml
monitoring:
  namespace: infrastructure
  serviceMonitor:
    # Namespace where geo services are deployed
    targetNamespace: istio-ingress
```

This lets Prometheus discover monitoring resources in `infrastructure` while scraping services in the app namespace.

## Network policies

The chart includes NetworkPolicies for both services and enables them by default.

By default, `networkPolicy.permissiveMode` is enabled so the deployment is easier to get running initially.
This allows broader traffic than a strict zero-trust setup.
You can disable permissive mode later and tighten the policies when traffic paths are verified.

- `geoaccessvalidator` ingress:
  - from namespace `istio-ingress`
  - from namespace `istio-system`
- `geoaccessvalidator` egress:
  - DNS (UDP/TCP 53)
  - `geolookupservice` on the service port

- `geolookupservice` ingress:
  - from `geoaccessvalidator`
- `geolookupservice` egress:
  - DNS (UDP/TCP 53)
  - internet egress on TCP 443 only
  - cluster CIDRs are excluded from this 443 egress rule

Relevant values:

```yaml
networkPolicy:
  enabled: true
  permissiveMode: true
  istioIngressNamespaces:
    - istio-ingress
    - istio-system
```

## Local render test

From the repository root:

```bash
helm lint ./helm -f ./helm/values.ci.yaml
helm template maxmind-geoblock ./helm -f ./helm/values.ci.yaml
```

The `values.ci.yaml` file contains the required `allowedCountries` list for rendering and CI validation.
