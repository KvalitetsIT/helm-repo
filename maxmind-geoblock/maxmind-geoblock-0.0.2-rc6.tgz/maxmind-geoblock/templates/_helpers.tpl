{{- define "maxmind-geoblock.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "maxmind-geoblock.fullname" -}}
{{- printf "%s-%s" .Release.Name (include "maxmind-geoblock.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "maxmind-geoblock.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
{{- end -}}
