# Example of using injector

## Goal
In this example i will use the oauth2-injector in the application called "kitalert". This application uses our service-chart.



## Creating all config/resource to use when the proxy is running
1. Go to your application helm-configuration
1. Copy the `oauth2-proxy-config.yaml` (places in same place as this readme) to the ´templates´-folder of your app
1. Insert the following in your `values.yaml`
   ```
   oauth2-proxy-inject:
     namespace: kit-intern
     upstream: http://localhost:8080
     service:
       selector: # Select the pod where the oauth2-proxy runs
         app.kubernetes.io/instance: kitalert
          app.kubernetes.io/name: kitalert
     oidc:
       allowed_groups: kitalert-admin # The role you need to have in keycloak to access the app
       client:
         id: kitalert # ClientId in keycloak
         secret:
           name: kitalert-oauth2-proxy-secret #Name of the secret where the client, and cookie secret are
   ```
1. Insert the following in your `values-test.yaml`
   ```
   oauth2-proxy-inject:
     ingress: #Creates an ingress with this url, that points to a new svc
       - url: kitalert.t0.hosting.kitkube.dk
         path: /
     oidc:
       issuer_url: https://keycloak.t0.hosting.kitkube.dk/auth/realms/login
       client:
         secret:
           encryptedData: #Secrets are sealed with kubeseal
             OAUTH2_PROXY_CLIENT_SECRET: AgBhsG4B44K
             OAUTH2_PROXY_COOKIE_SECRET: AgBkFzkeSp3
   ```
1. Insert the following in your `values-prod.yaml`
   ```
   oauth2-proxy-inject:
     ingress: #Creates an ingress with this url, that points to a new svc
       - url: kitalert.hosting.kitkube.dk
         path: /
     oidc:
       issuer_url: https://keycloak.hosting.kitkube.dk/auth/realms/login
       client:
         secret:
           encryptedData: #Secrets are sealed with kubeseal
             OAUTH2_PROXY_CLIENT_SECRET: AgApY2R1gKPSn4
             OAUTH2_PROXY_COOKIE_SECRET: AgBLTEMT1wMbk7
   ```
## Modify your application to use injector
> Keep in mind that i am using the service-chart
1. Go to your  `values.yaml` and insert podLabels and podAnnotations:
   ```
   service:
     ....
     ingress:
       enabled: false # Make sure that the url you are planning to use is not already in use
     ....
     podLabels:
       oauth2-proxy.kitkube.dk/inject: "true"
     podAnnotations:
       oauth2-proxy.kitkube.dk/configmap: "kitalert-oauth2-proxy-cfg"
       oauth2-proxy.kitkube.dk/secret: "kitalert-oauth2-proxy-secret"
   ```   
   
# What are created in the template
When using the template `oauth2-proxy-config.yaml`. The following are created;
- Configmap called `{{ $oauth2.oidc.client.id }}-oauth2-proxy-cfg`)
   - Sets lisiting port to `4180`
   - Upstreams to port 8080 inside the pod
- Sealedsecret (called `{{ $oauth2.oidc.client.secret.name }}`)
   - Sets the required keys `OAUTH2_PROXY_COOKIE_SECRET` and `OAUTH2_PROXY_CLIENT_SECRET`
- Service (called `{{ $oauth2.oidc.client.id }}-oauth2-proxy`)
   - Maps from svc-port 80 to targetPort 4180
- Ingress (called `{{ $oauth2.oidc.client.id }}-oauth2-proxy`)
   - Points to the Service `{{ $oauth2.oidc.client.id }}-oauth2-proxy` on port 80

# Configure openid to use redis (default is cookie)

1. `values.yaml`
   ```
   oauth2-proxy-inject:
     session_store:
       type: "redis"
       redis_use_sentinel: true
       redis_sentinel_master_name: "mymaster"
   ```

2. `values-test.yaml`
   ```
   oauth2-proxy-inject:
     ...
     session_store:
       redis_sentinel_connection_urls: redis://redis-node-0.redis-headless.medcom-sdn:26379,redis://redis-node-1.redis-headless.medcom-sdn:26379,redis://redis-node-2.redis-headless.medcom-sdn:26379
     ...
     oidc:
       ...
       client:
         ...
         secret: #The openid-container is set to use everything from secret as env
           data: # This can be env-variables
             Jens: jens
           encryptedData: #This is the way we will set the redis-password
             ...
             OAUTH2_PROXY_REDIS_PASSWORD: AgAnG046fEfbMS4BrN8
             OAUTH2_PROXY_REDIS_SENTINEL_PASSWORD: AgAnG046fEfbMS4BrN8
   ```
