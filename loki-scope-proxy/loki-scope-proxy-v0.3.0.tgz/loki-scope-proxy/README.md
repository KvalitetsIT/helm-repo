# loki-scope-proxy

JWT-aware reverse proxy that injects X-Scope-OrgID into Loki queries based on Keycloak group claims. Admin groups receive all tenant IDs (discovered from namespace labels); tenant users receive only their matching tenant ID.

**Homepage:** <https://github.com/KvalitetsIT>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| KvalitetsIT | <kithosting@kvalitetsit.dk> | <https://github.com/KvalitetsIT/helm-repo> |

## Source Code

* <https://github.com/KvalitetsIT/loki-scope-proxy>
* <https://github.com/KvalitetsIT/helm-templates-chart/tree/main/charts/templates>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://raw.githubusercontent.com/KvalitetsIT/helm-repo/master/ | kitapp | 1.0.1 |
| https://raw.githubusercontent.com/KvalitetsIT/helm-repo/master/ | templates | 2.2.0 |

## Values

### General

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fullnameOverride | string | `""` | Fullname override (overrides the default `<name>-<release>` convention used in labels and selectors). |
| upstream.url | string | `""` | Full URL of the upstream Loki instance, e.g. `http://loki.logging.svc.cluster.local:3100`. |

### Keycloak

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| keycloak.url | string | `""` | Base URL of the Keycloak instance, e.g. `https://keycloak.example.com`. |
| keycloak.realm | string | `""` | Realm name. |
| keycloak.audience | string | `""` | Expected `aud` claim (Keycloak client ID). Required when `proxy.authMode=istio`. Optional in `jwt` mode - leave empty to skip audience validation. |

### Proxy

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| proxy.authMode | string | `"jwt"` | Authentication mode. `jwt` validates the Bearer token directly; `istio` trusts the groups header injected by Istio's RequestAuthentication. |
| proxy.logLevel | string | `"info"` | Log level. One of `debug`, `info`, `warn`, `error`. |
| proxy.adminGroups | string | `"cluster-admin,cluster-readonly"` | Comma-separated Keycloak group names that grant access to all tenants. |
| proxy.tenantLabel | string | `"tenant.kitkube.dk/name"` | Kubernetes namespace label whose value is the Loki tenant ID. |
| proxy.cacheTTL | string | `"60s"` | How long to cache the namespace-based tenant list. |
| proxy.defaultTenantId | string | `"kit-admin"` | Tenant ID always included in the admin scope (covers namespaces without the tenant label). |
| proxy.caCert.secretName | string | `""` | Name of an existing Secret containing a custom CA certificate to trust for outbound HTTPS calls to Loki and Keycloak (e.g. a client's internal or self-signed root). Leave empty to disable. When set, you must also mount this Secret via `kitapp.extraVolumes` at `proxy.caCert.mountPath` - see the "Custom CA" section in the chart README for the exact snippet to copy. |
| proxy.caCert.secretKey | string | `"ca.crt"` | Key within the Secret holding the PEM-encoded CA certificate. |
| proxy.caCert.mountPath | string | `"/etc/loki-scope-proxy/ca"` | Path the CA cert is mounted at inside the container. Must match the `mountPath` used in the corresponding `kitapp.extraVolumes` entry. |

### Istio configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| proxy.istio.groupsHeader | string | `"x-auth-groups"` | HTTP header that Istio injects the groups claim into via `outputClaimToHeaders`. |
| proxy.istio.requestAuthentication | object | `{"enabled":true}` | Deploy a `RequestAuthentication` resource targeting this proxy. Requires `proxy.authMode=istio`. |
| proxy.istio.requestAuthentication.enabled | bool | `true` | Enable the RequestAuthentication resource. |
| proxy.istio.authorizationPolicy | object | `{"enabled":true}` | Deploy an `AuthorizationPolicy` that rejects requests without a validated JWT principal. Must be deployed alongside `requestAuthentication` - without it, Istio validates tokens only when present; unauthenticated requests reach the proxy and can forge the groups header. |
| proxy.istio.authorizationPolicy.enabled | bool | `true` | Enable the AuthorizationPolicy resource. Disabling this leaves the proxy exposed to groups-header injection from unauthenticated callers that can reach the pod without a JWT. |

### KIT App

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kitapp | object | See [values.yaml](values.yaml) | kitapp base chart - controls the Deployment, Service, and ServiceAccount. See [kitapp values](https://github.com/KvalitetsIT/kitapp-helm-chart) for all options. |
| kitapp.image.repository | string | `"kvalitetsit/loki-scope-proxy"` | Full image repository. |
| kitapp.image.tag | string | `"v0.3.0"` | Image tag |
| kitapp.image.digest | string | `""` | Image digest (overrides tag when set) |
| kitapp.extraEnvFrom | list | `[{"configMapRef":{"name":"loki-scope-proxy-env"}}]` | envFrom pointing at the env ConfigMap generated by this chart. Override this name per release when deploying multiple proxies in the same namespace. |

### Network policies

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicyFallback | object | See [values.yaml](values.yaml) | Settings used by the native NetworkPolicy fallback when Cilium is unavailable. |
| networkPolicyFallback.kubeApiServerCIDR | string | `"10.96.0.1/32"` | Kubernetes API server service CIDR for native NetworkPolicy egress fallback. Override this to the `kubernetes.default` service ClusterIP in clusters where it differs. |
| networkPolicies | object | See [values.yaml](values.yaml) | Kubernetes NetworkPolicy resources rendered by this chart. Entries with the same key as `ciliumNetworkPolicies` are treated as fallbacks and are rendered only when Cilium is unavailable. Entries without a matching Cilium policy are always rendered. |
| networkPolicies.loki-scope-proxy-ingress | object | See [values.yaml](values.yaml) | Native ingress policy for Grafana and Prometheus access to the proxy. Always rendered. |
| networkPolicies.loki-scope-proxy-egress | object | See [values.yaml](values.yaml) | Native egress fallback used when Cilium is unavailable. |
| networkPolicies.loki-scope-proxy-keycloak | object | See [values.yaml](values.yaml) | Optional native Keycloak egress fallback for clusters without Cilium. Native NetworkPolicy cannot match FQDNs, so enable this only with explicit IP blocks or pod/namespace selectors. |
| ciliumNetworkPolicies | object | See [values.yaml](values.yaml) | CiliumNetworkPolicy resources rendered by this chart when the `cilium.io/v2` API is available. A same-named `networkPolicies` entry is used as the native Kubernetes fallback when Cilium is unavailable. |
| ciliumNetworkPolicies.loki-scope-proxy-egress | object | See [values.yaml](values.yaml) | Cilium egress policy for DNS and kube-apiserver access. |

## Deployment

This chart is designed to deploy to the **`logging`** namespace alongside Loki.
All chart resources are namespace-agnostic (they use `Release.Namespace`), so the deploy namespace
is set by the ArgoCD `Application` resource in your environment repo.

### ArgoCD Application example

```yaml
applications:
  loki-scope-proxy:
    namespace: argocd
    project: infrastructure
    sources:
      - repoURL: https://github.com/KvalitetsIT/k8s-components.git
        targetRevision: <repo-tag>
        path: loki-scope-proxy
        helm:
          valueFiles:
            - $values/deployment/loki-scope-proxy/values-test.yaml
      - ref: values
        repoURL: https://github.com/KvalitetsIT/<env-repo>.git
        targetRevision: main
    destination:
      server: https://kubernetes.default.svc
      namespace: logging
    syncPolicy:
      automated:
        prune: true
        selfHeal: true
      syncOptions:
        - CreateNamespace=true
        - ServerSideApply=true
```

## Multiple proxy instances

When deploying multiple proxies in the same namespace, give each proxy a unique env ConfigMap name.
The chart uses `kitapp.extraEnvFrom[0].configMapRef.name` as the single source of truth for both
the generated ConfigMap and the KitApp Deployment `envFrom` reference:

```yaml
kitapp:
  extraEnvFrom:
    - configMapRef:
        name: <name-of-this-proxy-instance>-env
```

Set this in the environment/release values file for each proxy instance.

## Custom CA

If Loki or Keycloak present a certificate signed by an internal or self-signed CA (common in
client-managed clusters), create a Secret with the CA certificate and point the proxy at it.

First create the Secret (a CA certificate is public - it has no private key - so plain text is fine):

```sh
kubectl create secret generic loki-scope-proxy-ca \
  --from-file=ca.crt=/path/to/client-ca.pem \
  -n logging
```

Then set both `proxy.caCert.secretName` and a matching `kitapp.extraVolumes` entry - Helm fails
fast at render time if they don't match, since one drives the `CA_CERT_FILE` env var and the other
drives the actual Secret mount on the Deployment (rendered by different charts, so one value can't
derive the other). A YAML anchor keeps the secret name in one place:

```yaml
upstream:
  url: http://loki.logging.svc.cluster.local:3100

keycloak:
  url: https://keycloak.example.com
  realm: infrastructure

proxy:
  caCert:
    secretName: &caCertSecretName loki-scope-proxy-ca

kitapp:
  extraVolumes:
    - name: ca-cert
      mountPath: /etc/loki-scope-proxy/ca
      readOnly: true
      volumeSpec:
        secret:
          secretName: *caCertSecretName
```

## Network policies

The chart always renders a native Kubernetes `NetworkPolicy` for ingress from Grafana and Prometheus.
For egress to DNS and the Kubernetes API server, it follows the same Cilium/native fallback pattern
as the tenant project chart:

- if the `cilium.io/v2` API is available, render `ciliumNetworkPolicies.loki-scope-proxy-egress`
- otherwise, render the same-named `networkPolicies.loki-scope-proxy-egress` fallback

> [!IMPORTANT]
> Egress to Loki is **not** opened by default - deployments typically target multiple instances (e.g. `loki` and `loki-audit`) whose namespaces vary.
> Add the required egress rules in your k8s-components values.

> [!WARNING]
> In `jwt` auth mode, Keycloak egress uses a Cilium FQDN policy (`keycloak-egress-cilium-networkpolicy`).
> If Cilium is not installed, you must configure `networkPolicies.loki-scope-proxy-keycloak` with explicit
> IP blocks or pod/namespace selectors - native `NetworkPolicy` cannot match hostnames.
> Otherwise Helm fails during rendering to avoid deploying a proxy that cannot reach Keycloak.

Example native Keycloak fallback using an IP/CIDR allowlist:

```yaml
networkPolicies:
  loki-scope-proxy-keycloak:
    enabled: true
    egress:
      - to:
          - ipBlock:
              cidr: 203.0.113.10/32
        ports:
          - port: 443
            protocol: TCP
```

To disable the built-in policies:

```yaml
networkPolicies:
  loki-scope-proxy-ingress:
    enabled: false
  loki-scope-proxy-egress:
    enabled: false
ciliumNetworkPolicies:
  loki-scope-proxy-egress:
    enabled: false
```

### JWT auth mode (default)

```yaml
upstream:
  url: http://loki.logging.svc.cluster.local:3100

keycloak:
  url: https://keycloak.example.com
  realm: infrastructure
```

### Istio auth mode

```yaml
upstream:
  url: http://loki.logging.svc.cluster.local:3100

keycloak:
  url: https://keycloak.example.com
  realm: infrastructure
  audience: loki-scope-proxy

proxy:
  authMode: "istio"
```

### Multiple proxy instances (custom env ConfigMap name)

```yaml
upstream:
  url: http://loki.logging.svc.cluster.local:3100

keycloak:
  url: https://keycloak.example.com
  realm: infrastructure

kitapp:
  extraEnvFrom:
    - configMapRef:
        name: loki-scope-proxy-audit-env
```

## Multi-tenancy with Grafana

Configure the admin Grafana org's Loki datasource to point at this proxy and enable
`forwardOAuthIdentity`. The proxy reads the user's Keycloak JWT, maps groups to Loki tenant IDs,
and injects `X-Scope-OrgID` automatically.

```yaml
# GrafanaOrgDatasource for the main/admin org
spec:
  url: http://loki-scope-proxy.logging.svc.cluster.local:8080
  jsonData:
    forwardOAuthIdentity: true
```

Tenant orgs continue pointing directly at Loki with a hardcoded `X-Scope-OrgID` - no changes needed.

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
