{{/*
Validation: upstream.url is required.
*/}}
{{- define "loki-scope-proxy.validateUpstream" -}}
{{- if not ((.Values.upstream).url) }}
{{- fail "\nMissing required value: upstream.url\nSet it to the upstream Loki URL, e.g.:\n  upstream:\n    url: http://loki.logging.svc.cluster.local:3100\n" }}
{{- end }}
{{- end }}

{{/*
Validation: keycloak.url and keycloak.realm are required (both modes need them).
*/}}
{{- define "loki-scope-proxy.validateJWKS" -}}
{{- if not ((.Values.keycloak).url) }}
{{- fail "\nMissing required value: keycloak.url\nSet it to the base Keycloak URL, e.g.:\n  keycloak:\n    url: https://keycloak.example.com\n" }}
{{- end }}
{{- if not ((.Values.keycloak).realm) }}
{{- fail "\nMissing required value: keycloak.realm\nSet it to the Keycloak realm name, e.g.:\n  keycloak:\n    realm: infrastructure\n" }}
{{- end }}
{{- end }}
