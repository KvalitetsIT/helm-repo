{{- define "loki-scope-proxy.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "loki-scope-proxy.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "loki-scope-proxy.labels" -}}
helm.sh/chart: {{ include "loki-scope-proxy.chart" . }}
{{ include "kitapp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "loki-scope-proxy.selectorLabels" -}}
{{ include "kitapp.selectorLabels" . }}
{{- end }}

{{- define "loki-scope-proxy.serviceAccountName" -}}
{{- $sa := (.Values.kitapp).serviceAccount | default dict -}}
{{- $name := (.Values.kitapp).nameOverride | default .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- if $sa.create -}}
{{- $sa.name | default $name -}}
{{- else -}}
{{- $sa.name | default "default" -}}
{{- end -}}
{{- end }}
