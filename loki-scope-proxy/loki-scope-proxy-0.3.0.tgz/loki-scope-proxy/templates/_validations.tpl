{{/*
Validation: upstream.url is required.
*/}}
{{- define "loki-scope-proxy.validateUpstream" -}}
{{- if not ((.Values.upstream).url) }}
{{- fail "\nMissing required value: upstream.url\nSet it to the upstream Loki URL, e.g.:\n  upstream:\n    url: http://loki.logging.svc.cluster.local:3100\n" }}
{{- end }}
{{- end }}

{{/*
Validation: kitapp.extraEnvFrom[0].configMapRef.name is required.
*/}}
{{- define "loki-scope-proxy.validateEnvConfigMapName" -}}
{{- $_ := include "loki-scope-proxy.envConfigMapName" . -}}
{{- end }}

{{/*
Validation: keycloak.url and keycloak.realm are required (both modes need them).
*/}}
{{- define "loki-scope-proxy.validateJWKS" -}}
{{- if not ((.Values.keycloak).url) }}
{{- fail "\nMissing required value: keycloak.url\nSet it to the base Keycloak URL, e.g.:\n  keycloak:\n    url: https://keycloak.example.com\n" }}
{{- end }}
{{- if not ((.Values.keycloak).realm) }}
{{- fail "\nMissing required value: keycloak.realm\nSet it to the Keycloak realm name, e.g.:\n  keycloak:\n    realm: infrastructure\n" }}
{{- end }}
{{- end }}

{{/*
Validation: when proxy.caCert.secretName is set, kitapp.volumes/extraVolumes must mount that
Secret at proxy.caCert.mountPath - CA_CERT_FILE otherwise points at a path nothing populates.
*/}}
{{- define "loki-scope-proxy.validateCACert" -}}
{{- $caCert := .Values.proxy.caCert }}
{{- if $caCert.secretName }}
{{- $allVolumes := concat (((.Values.kitapp).volumes) | default (list)) (((.Values.kitapp).extraVolumes) | default (list)) }}
{{- $found := false }}
{{- range $allVolumes }}
{{- if and (eq .mountPath $caCert.mountPath) (eq (((.volumeSpec).secret).secretName) $caCert.secretName) }}
{{- $found = true }}
{{- end }}
{{- end }}
{{- if not $found }}
{{- fail (printf "\nproxy.caCert.secretName is set to %q, but no kitapp.extraVolumes entry mounts it at proxy.caCert.mountPath (%q).\nAdd this:\n  kitapp:\n    extraVolumes:\n      - name: ca-cert\n        mountPath: %s\n        readOnly: true\n        volumeSpec:\n          secret:\n            secretName: %s\n" $caCert.secretName $caCert.mountPath $caCert.mountPath $caCert.secretName) }}
{{- end }}
{{- end }}
{{- end }}
