# medcom-sdn-dns-cert-manager-webhook

Helm chart for deploying the SDN cert-manager ACME DNS-01 webhook solver.

## Prerequisites

- Kubernetes 1.21+
- Helm 3.0+
- [cert-manager](https://cert-manager.io/) v1.19+ installed in the cluster
- Network access from the webhook to the SDN DNS API

## Installation

```bash
helm repo add kvalitetsit https://raw.githubusercontent.com/KvalitetsIT/helm-repo/master/
helm repo update

helm install medcom-sdn-dns-cert-manager-webhook kvalitetsit/medcom-sdn-dns-cert-manager-webhook \
  --namespace cert-manager \
  --set sdn.apiUrl=<sdn-dns-api-url>
```

`sdn.apiUrl` is required and is passed to the webhook as `SDN_API_URL`.

## Usage

After installation, create a `ClusterIssuer` that uses the webhook as its DNS-01 solver:

```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    email: your@email.com
    server: https://acme-v02.api.letsencrypt.org/directory
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
      - dns01:
          webhook:
            groupName: acme-sdn.kvalitetsit.dk
            solverName: acme-sdn.kvalitetsit.dk
```

## Values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `groupName` | Unique group name for the webhook API group | `acme-sdn.kvalitetsit.dk` |
| `replicaCount` | Number of replicas | `1` |
| `image.repository` | Image repository | `kvalitetsit/medcom-sdn-dns-cert-manager-webhook` |
| `image.tag` | Image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `sdn.apiUrl` | SDN DNS API base URL (required) | `""` |
| `certManager.namespace` | Namespace where cert-manager is installed | `cert-manager` |
| `certManager.serviceAccountName` | Service account name of cert-manager | `cert-manager` |
| `resources.limits.memory` | Memory limit | `100Mi` |
| `resources.requests.cpu` | CPU request | `5m` |
| `resources.requests.memory` | Memory request | `30Mi` |
| `podSecurityContext` | Pod-level security context | `runAsNonRoot: true`, `runAsUser/Group/fsGroup: 65532` |
| `securityContext` | Container-level security context | `allowPrivilegeEscalation: false`, `readOnlyRootFilesystem: true`, capabilities `ALL` dropped |
| `networkPolicy.enabled` | Enable NetworkPolicy | `true` |
| `networkPolicy.egressPorts` | Allowed egress ports, must include the SDN DNS API port | `443`, `6443` (TCP), `53` (TCP/UDP) |
| `nodeSelector` | Node selector | `{}` |
| `tolerations` | Tolerations | `[]` |
| `affinity` | Affinity rules | `{}` |
