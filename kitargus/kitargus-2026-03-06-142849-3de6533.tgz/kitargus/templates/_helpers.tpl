{{/*
Expand the name of the chart.
*/}}
{{- define "kitargus.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kitargus.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kitargus.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kitargus.labels" -}}
helm.sh/chart: {{ include "kitargus.chart" . }}
{{ include "kitargus.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kitargus.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kitargus.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kitargus.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kitargus.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "kitargus.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.commonAnnotations }}
{{- $annotations = merge $annotations .Values.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "kitargus.hasCommonAnnotations" -}}
{{- if .Values.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Common DNS egress rule
*/}}
{{- define "kitargus.netpol.dns" -}}
- toEndpoints:
    - matchLabels:
        k8s:io.kubernetes.pod.namespace: {{ .Values.networkPolicy.dns.namespace | default "kube-system" }}
        k8s:k8s-app: {{ .Values.networkPolicy.dns.labels.k8sApp | default "kube-dns" }}
  toPorts:
    - ports:
        - port: "53"
          protocol: ANY
      rules:
        dns:
          - matchPattern: "*"
{{- end -}}

{{/*
Kubernetes API server egress rule
*/}}
{{- define "kitargus.netpol.kubeApiServer" -}}
- toEntities:
    - kube-apiserver
  toPorts:
    - ports:
        - port: {{ .Values.networkPolicy.kubeApiServer.port | default "6443" | quote }}
          protocol: TCP
{{- end -}}

{{/*
Backend egress rule (if enabled)
*/}}
{{- define "kitargus.netpol.backend" -}}
{{- if and (eq .Values.backend.type "dtrack") .Values.backend.dtrack.enabled }}
- toEndpoints:
    - matchLabels:
        {{- range $key, $value := .Values.backend.dtrack.endpoint.matchLabels }}
        {{ $key }}: {{ $value }}
        {{- end }}
        k8s:io.kubernetes.pod.namespace: {{ .Values.backend.dtrack.endpoint.namespace }}
  toPorts:
    - ports:
        - port: {{ .Values.backend.dtrack.endpoint.port | quote }}
          protocol: TCP
{{- end }}
{{- end -}}
