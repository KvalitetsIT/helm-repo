# kitargus

![Version: 0.4.1](https://img.shields.io/badge/Version-0.4.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.4.1](https://img.shields.io/badge/AppVersion-0.4.1-informational?style=flat-square)

A Helm chart for deploying KITArgus.

**Homepage:** <https://github.com/KvalitetsIT>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| KvalitetsIT | <kithosting@kvalitetsit.dk> | <https://github.com/KvalitetsIT/helm-repo> |

## Source Code

* <https://github.com/KvalitetsIT/kitargus>
* <https://github.com/KvalitetsIT/kitargus/tree/main/charts/kitargus>

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| nameOverride | string | `""` | Default settings for the name override. |
| fullnameOverride | string | `""` | Default settings for the fullname override. |
| commonAnnotations | object | `{}` | Common annotations to add to all resources |

### Controller Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` | Default settings for the controller replica count. |
| podAnnotations | object | `{}` | Default settings for the controller pod annotations. |
| podSecurityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Default settings for the controller pod security context. |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Default settings for the controller security context. |
| imagePullSecrets | list | `[]` | Default settings for the controller image pull secrets. |
| image | object | `{"pullPolicy":"IfNotPresent","repository":"kvalitetsit/kitargus","tag":"0.4.1"}` | Default settings for the controller image. |
| image.repository | string | `"kvalitetsit/kitargus"` | Default settings for the controller image repository. |
| image.pullPolicy | string | `"IfNotPresent"` | Default settings for the controller image pull policy. |
| image.tag | string | `"0.4.1"` | Default settings for the controller image tag. |
| logLevel | string | `"info"` | Default settings for the controller log level (debug, info, error, panic), or any integer over 0 for more verbose logging. |
| leaderElection | object | `{"enabled":false}` | Default settings for the controller leader election. |
| leaderElection.enabled | bool | `false` | Enable leader election for the controller |
| resources | object | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"250m","memory":"256Mi"}}` | Default settings for the controller resources. |
| resources.limits | object | `{"cpu":"500m","memory":"512Mi"}` | Default settings for the controller resources limits. |
| resources.requests | object | `{"cpu":"250m","memory":"256Mi"}` | Default settings for the controller resources requests. |
| extraEnvVars | object | `{}` | Default settings for the controller extra environment variables. |
| secretReader | object | `{"create":true,"serviceAccountName":"kitargus-secret-reader"}` | Default settings for the secret reader. |
| secretReader.create | bool | `true` | Default settings for the secret reader create. |
| secretReader.serviceAccountName | string | `"kitargus-secret-reader"` | Default settings for the secret reader service account name. |

### Monitoring Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceMonitor | object | `{"enabled":false,"interval":"1m","labels":{},"scrapeTimeout":"30s"}` | ServiceMonitor configuration for Prometheus Operator |
| serviceMonitor.enabled | bool | `false` | Enable ServiceMonitor for Prometheus Operator |
| serviceMonitor.labels | object | `{}` | Additional labels for the ServiceMonitor |
| serviceMonitor.interval | string | `"1m"` | Scrape interval (e.g., 30s) |
| serviceMonitor.scrapeTimeout | string | `"30s"` | Scrape timeout (e.g., 10s) |
| grafana | object | `{"dashboard":{"enabled":false,"labels":{"grafana_dashboard":"1"}}}` | Grafana dashboard configuration |
| grafana.dashboard.enabled | bool | `false` | Deploy a ConfigMap containing the KITArgus Grafana dashboard |
| grafana.dashboard.labels | object | `{"grafana_dashboard":"1"}` | Additional labels on the dashboard ConfigMap. The Grafana sidecar picks up ConfigMaps with label grafana_dashboard: "1" by default. |

### Network Policy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicy | object | `{"controller":{"additionalEgressRules":[],"additionalIngressRules":[]},"defaultDenyAll":true,"dns":{"labels":{"k8sApp":"kube-dns"},"namespace":"kube-system"},"enabled":true,"kubeApiServer":{"port":"6443"},"prometheus":{"matchLabels":{"app.kubernetes.io/name":"prometheus"},"namespace":"infrastructure"},"scanjob":{"additionalEgressRules":[]}}` | Network policy configuration |
| networkPolicy.prometheus | object | `{"matchLabels":{"app.kubernetes.io/name":"prometheus"},"namespace":"infrastructure"}` | Prometheus settings for metrics scraping |
| networkPolicy.prometheus.namespace | string | `"infrastructure"` | Namespace where Prometheus is running |
| networkPolicy.prometheus.matchLabels | object | `{"app.kubernetes.io/name":"prometheus"}` | Labels to match Prometheus pods |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | `{"dtrack":{"apiTokenSecret":{"key":"token","name":"kitargus-dtrack-token"},"baseURL":"","enabled":false,"endpoint":{"matchLabels":{"app.kubernetes.io/component":"backend","app.kubernetes.io/instance":"dtrack","app.kubernetes.io/name":"dtrack-backend"},"namespace":"dtrack","port":"8080"},"overrideBaseURL":""},"multitenancy":{"enabled":false,"groupMappingConfigMap":"tenant-group-mapping","namespaceLabel":"tenant.kitkube.dk/name"},"retention":{"dryRun":true,"enabled":false,"keepPrevious":2,"schedule":"168h"},"syncInterval":"10m","tags":{"global":["container_image:{{image}}"],"managed":"kitargus:managed"},"type":"dtrack"}` | Backend integration settings |
| backend.type | string | `"dtrack"` | Backend type |
| backend.syncInterval | string | `"10m"` | Backend synchronization interval (e.g., 10m) |
| backend.tags | object | `{"global":["container_image:{{image}}"],"managed":"kitargus:managed"}` | Unified tag configuration applied to all backend projects |
| backend.tags.managed | string | `"kitargus:managed"` | Ownership marker tag applied to every project kitargus creates, including collection projects. Retention uses this tag to select prunable projects. |
| backend.tags.global | list | `["container_image:{{image}}"]` | Extra tags applied to kitargus-created projects. The `{{image}}` expression expands to the full image reference on leaf projects; tags using it are omitted from collection projects. |
| backend.multitenancy | object | `{"enabled":false,"groupMappingConfigMap":"tenant-group-mapping","namespaceLabel":"tenant.kitkube.dk/name"}` | Multitenancy settings. When enabled, kitargus derives a tenant from the workload namespace and scopes backend projects to that tenant's team. |
| backend.multitenancy.enabled | bool | `false` | Enable tenant derivation and backend access-control mapping |
| backend.multitenancy.namespaceLabel | string | `"tenant.kitkube.dk/name"` | Namespace label carrying the tenant name. The value is lowercased, so "Acme" and "acme" are one tenant. A namespace without the label has no tenant: its projects are still created and scanned, they just get no access-control mapping. |
| backend.multitenancy.groupMappingConfigMap | string | `"tenant-group-mapping"` | Name of the ConfigMap carrying a tenant's role to identity-provider group mapping, one data key per role ("viewer", "developer"). It is found by the tenant label rather than by namespace, so it can live in whichever of the tenant's namespaces provisions it. Roles kitargus does not model are ignored. Each role gets its own backend team, so a viewer can read findings and a developer can also triage them. |
| backend.retention | object | `{"dryRun":true,"enabled":false,"keepPrevious":2,"schedule":"168h"}` | Backend retention settings |
| backend.retention.enabled | bool | `false` | Backend retention enabled |
| backend.retention.keepPrevious | int | `2` | Backend retention |
| backend.retention.schedule | string | `"168h"` | Backend retention schedule (e.g., 168h for 7 days) |
| backend.retention.dryRun | bool | `true` | Backend retention dry run (true to log prune candidates only) |

### Backend DTrack Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend.dtrack | object | `{"apiTokenSecret":{"key":"token","name":"kitargus-dtrack-token"},"baseURL":"","enabled":false,"endpoint":{"matchLabels":{"app.kubernetes.io/component":"backend","app.kubernetes.io/instance":"dtrack","app.kubernetes.io/name":"dtrack-backend"},"namespace":"dtrack","port":"8080"},"overrideBaseURL":""}` | Backend integration settings for Dependency Track |
| backend.dtrack.enabled | bool | `false` | Backend DTrack |
| backend.dtrack.baseURL | string | `""` | Backend DTrack base URL (e.g., https://dtrack-backend.dtrack.svc.cluster.local) |
| backend.dtrack.overrideBaseURL | string | `""` | Backend DTrack override base URL (e.g., https://dtrack-backend.dtrack.svc.cluster.local) - overrides baseURL if set |
| backend.dtrack.apiTokenSecret | object | `{"key":"token","name":"kitargus-dtrack-token"}` | Backend DTrack API token secret reference |
| backend.dtrack.apiTokenSecret.name | string | `"kitargus-dtrack-token"` | Backend DTrack API token secret reference namespace |
| backend.dtrack.apiTokenSecret.key | string | `"token"` | Backend DTrack API token secret reference |
| backend.dtrack.endpoint | object | `{"matchLabels":{"app.kubernetes.io/component":"backend","app.kubernetes.io/instance":"dtrack","app.kubernetes.io/name":"dtrack-backend"},"namespace":"dtrack","port":"8080"}` | Connection details for network policy |
| backend.dtrack.endpoint.namespace | string | `"dtrack"` | Namespace for DTrack backend service |
| backend.dtrack.endpoint.port | string | `"8080"` | Port for DTrack backend service |
| backend.dtrack.endpoint.matchLabels | object | `{"app.kubernetes.io/component":"backend","app.kubernetes.io/instance":"dtrack","app.kubernetes.io/name":"dtrack-backend"}` | Labels to match DTrack backend service |

### ScanJob Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| scanjob | object | `{"image":{"repository":"kvalitetsit/kitargus-scanjob","tag":"0.4.1"},"registries":{"azure":["*.azurecr.io","login.microsoftonline.com","*.blob.core.windows.net","mcr.microsoft.com","*.data.mcr.microsoft.com"],"docker":["index.docker.io","registry-1.docker.io","auth.docker.io","production.cloudflare.docker.com","docker-images-prod.6aa30f8b08e16409b46e0173d6de2f56.r2.cloudflarestorage.com","production.cloudfront.docker.com","cdn.registry.k8s.io","docker-registry-production.d24a988e385e0074d717b6bdaea58f0d.r2.cloudflarestorage.com"],"ecr":["ecr-public.aws.com","public.ecr.aws","*.dkr.ecr.*.amazonaws.com","api.ecr.*.amazonaws.com","s3.*.amazonaws.com","*.s3.*.amazonaws.com","sts.*.amazonaws.com","*.public.ecr.aws","*.cloudfront.net"],"extra":[],"github":["docker.pkg.github.com","docker-proxy.pkg.github.com","containers.pkg.github.com","*.github.com","*.pkg.github.com","*.ghcr.io","*.githubassets.com","*.githubusercontent.com","ghcr.io"],"google":["gcr.io","*.gcr.io","dl.google.com","*.pkg.dev"],"misc":["registry.k8s.io","prod-registry-k8s-io-eu-central-1.s3.dualstack.eu-central-1.amazonaws.com","docker-registry1.mariadb.com","docker-registry2.mariadb.com","docker-registry3.mariadb.com","registry.nspop.dk","nvcr.io","layers.nvcr.io"],"quay":["quay.io","cdn*.quay.io"]},"tmpInitImage":"busybox:1.36"}` | Container registry allowlist for scanjobs |
| scanjob.tmpInitImage | string | `"busybox:1.36"` | Init container image used for per-container tmp setup |
| scanjob.registries | object | `{"azure":["*.azurecr.io","login.microsoftonline.com","*.blob.core.windows.net","mcr.microsoft.com","*.data.mcr.microsoft.com"],"docker":["index.docker.io","registry-1.docker.io","auth.docker.io","production.cloudflare.docker.com","docker-images-prod.6aa30f8b08e16409b46e0173d6de2f56.r2.cloudflarestorage.com","production.cloudfront.docker.com","cdn.registry.k8s.io","docker-registry-production.d24a988e385e0074d717b6bdaea58f0d.r2.cloudflarestorage.com"],"ecr":["ecr-public.aws.com","public.ecr.aws","*.dkr.ecr.*.amazonaws.com","api.ecr.*.amazonaws.com","s3.*.amazonaws.com","*.s3.*.amazonaws.com","sts.*.amazonaws.com","*.public.ecr.aws","*.cloudfront.net"],"extra":[],"github":["docker.pkg.github.com","docker-proxy.pkg.github.com","containers.pkg.github.com","*.github.com","*.pkg.github.com","*.ghcr.io","*.githubassets.com","*.githubusercontent.com","ghcr.io"],"google":["gcr.io","*.gcr.io","dl.google.com","*.pkg.dev"],"misc":["registry.k8s.io","prod-registry-k8s-io-eu-central-1.s3.dualstack.eu-central-1.amazonaws.com","docker-registry1.mariadb.com","docker-registry2.mariadb.com","docker-registry3.mariadb.com","registry.nspop.dk","nvcr.io","layers.nvcr.io"],"quay":["quay.io","cdn*.quay.io"]}` | Registries scanjobs can pull from |
| scanjob.registries.docker | list | `["index.docker.io","registry-1.docker.io","auth.docker.io","production.cloudflare.docker.com","docker-images-prod.6aa30f8b08e16409b46e0173d6de2f56.r2.cloudflarestorage.com","production.cloudfront.docker.com","cdn.registry.k8s.io","docker-registry-production.d24a988e385e0074d717b6bdaea58f0d.r2.cloudflarestorage.com"]` | Docker Hub registries |
| scanjob.registries.quay | list | `["quay.io","cdn*.quay.io"]` | Quay registries |
| scanjob.registries.github | list | `["docker.pkg.github.com","docker-proxy.pkg.github.com","containers.pkg.github.com","*.github.com","*.pkg.github.com","*.ghcr.io","*.githubassets.com","*.githubusercontent.com","ghcr.io"]` | GitHub registries |
| scanjob.registries.google | list | `["gcr.io","*.gcr.io","dl.google.com","*.pkg.dev"]` | Google registries |
| scanjob.registries.azure | list | `["*.azurecr.io","login.microsoftonline.com","*.blob.core.windows.net","mcr.microsoft.com","*.data.mcr.microsoft.com"]` | Azure registries |
| scanjob.registries.ecr | list | `["ecr-public.aws.com","public.ecr.aws","*.dkr.ecr.*.amazonaws.com","api.ecr.*.amazonaws.com","s3.*.amazonaws.com","*.s3.*.amazonaws.com","sts.*.amazonaws.com","*.public.ecr.aws","*.cloudfront.net"]` | AWS ECR registries |
| scanjob.registries.misc | list | `["registry.k8s.io","prod-registry-k8s-io-eu-central-1.s3.dualstack.eu-central-1.amazonaws.com","docker-registry1.mariadb.com","docker-registry2.mariadb.com","docker-registry3.mariadb.com","registry.nspop.dk","nvcr.io","layers.nvcr.io"]` | Miscellaneous registries |
| scanjob.registries.extra | list | `[]` | Custom registries defined by the user |

### Service Account Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceAccount | object | `{"create":true,"name":""}` | Default settings for the service account. |
| serviceAccount.name | string | `""` | Default settings for the service account name. |

### RBAC Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| rbac | object | `{"additionalRules":[{"apiGroups":["postgresql.cnpg.io"],"resources":["clusters"],"verbs":["get","list","watch"]},{"apiGroups":["argoproj.io"],"resources":["workflows","cronworkflows"],"verbs":["get","list","watch"]},{"apiGroups":["acme.cert-manager.io"],"resources":["challenges"],"verbs":["get","list","watch"]}],"create":true}` | Default settings for the rbac. |
| rbac.create | bool | `true` | Default settings for the rbac create. |
| rbac.additionalRules | list | `[{"apiGroups":["postgresql.cnpg.io"],"resources":["clusters"],"verbs":["get","list","watch"]},{"apiGroups":["argoproj.io"],"resources":["workflows","cronworkflows"],"verbs":["get","list","watch"]},{"apiGroups":["acme.cert-manager.io"],"resources":["challenges"],"verbs":["get","list","watch"]}]` | Additional rules to add to the cluster role. |

### Configuration Settings

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| config | object | `{"customWorkloadKinds":["postgresql.cnpg.io/v1/Cluster","argoproj.io/v1alpha1/Workflow","argoproj.io/v1alpha1/CronWorkflow","acme.cert-manager.io/v1/Challenge"],"excludeNamespaces":[],"insecureSkipTLSVerifyHosts":[],"maxRetries":3,"namespace":"kitargus","scanConcurrencyLimit":10,"scanJobActiveDeadlineSeconds":"30m","scanJobTTLSeconds":"6h","scanLogLevel":"info","scanjobRegistry":{},"scanjobResources":{}}` | Default settings for the config. |
| config.excludeNamespaces | list | `[]` | Default settings for the controller exclude namespaces. |
| config.insecureSkipTLSVerifyHosts | list | `[]` | Registry hosts where scanjob should skip TLS verification. |
| config.scanLogLevel | string | `"info"` | Log level for scanjob pods (trace, debug, info, warn, error, fatal, panic) |
| config.namespace | string | `"kitargus"` | Default settings for the controller config namespace. |
| config.scanConcurrencyLimit | int | `10` | Default settings for the controller config scan concurrency limit. |
| config.maxRetries | int | `3` | Default settings for the controller config max retries. |
| config.scanJobTTLSeconds | string | `"6h"` | TTL duration for finished scan jobs (0 disables). |
| config.scanJobActiveDeadlineSeconds | string | `"30m"` | Active deadline for scan jobs before they are terminated (0 disables). |
| config.customWorkloadKinds | list | `["postgresql.cnpg.io/v1/Cluster","argoproj.io/v1alpha1/Workflow","argoproj.io/v1alpha1/CronWorkflow","acme.cert-manager.io/v1/Challenge"]` | Default settings for the controller config custom workload kinds. |
| config.scanjobRegistry | object | `{}` | Per-registry scanjob settings, keyed by registry host. Hosts include the port when the registry uses one, e.g. "registry.example.com:5000". `credentials_secret` names a Secret in the release namespace: a kubernetes.io/dockerconfigjson Secret needs only `name`, while an Opaque Secret also needs `username_key` and `password_key`. Example:   registry.example.com:     disable_tls_verify: false     credentials_secret:       name: registry-pull-secret |
| config.scanjobResources | object | `{}` | Scanjob container resource requests and limits. |

### Other Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicy.enabled | bool | `true` | Enable all network policies |
| networkPolicy.defaultDenyAll | bool | `true` | Enable default deny policy |
| networkPolicy.dns | object | `{"labels":{"k8sApp":"kube-dns"},"namespace":"kube-system"}` | DNS policy settings (shared by all components) |
| networkPolicy.kubeApiServer | object | `{"port":"6443"}` | Kubernetes API server settings |
| networkPolicy.controller | object | `{"additionalEgressRules":[],"additionalIngressRules":[]}` | Controller-specific network policy settings |
| networkPolicy.scanjob | object | `{"additionalEgressRules":[]}` | Scanjob-specific network policy settings |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
