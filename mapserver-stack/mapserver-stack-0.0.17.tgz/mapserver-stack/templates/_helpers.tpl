{{/*
Expand the name of the chart.
*/}}
{{- define "mapserver-stack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "mapserver-stack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "mapserver-stack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mapserver-stack.labels" -}}
helm.sh/chart: {{ include "mapserver-stack.chart" . }}
{{ include "mapserver-stack.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mapserver-stack.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mapserver-stack.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Component metadata labels. Takes a dict with "context" (.) and "component".
Use for metadata.labels; selector.matchLabels must use component.selectorLabels (strict subset).
*/}}
{{- define "mapserver-stack.component.metaLabels" -}}
helm.sh/chart: {{ include "mapserver-stack.chart" .context }}
app.kubernetes.io/name: {{ include "mapserver-stack.name" .context }}
app.kubernetes.io/instance: {{ .context.Release.Name }}
app.kubernetes.io/component: {{ .component }}
app.kubernetes.io/part-of: mapserver-stack
{{- if .context.Chart.AppVersion }}
app.kubernetes.io/version: {{ .context.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .context.Release.Service }}
{{- end }}

{{/*
Component selector labels for spec.selector.matchLabels. Selectors are immutable -
the chosen set (instance + component, no name) must stay stable across releases.
*/}}
{{- define "mapserver-stack.component.selectorLabels" -}}
app.kubernetes.io/instance: {{ .context.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "mapserver-stack.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "mapserver-stack.fullname" . }}
{{- end }}
{{- end }}

{{- define "mapserver-stack.mapserver.fullname" -}}
{{- printf "%s-mapserver" (include "mapserver-stack.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Effective replica floor for spread/pdb gating: hpa minReplicas when autoscaling
is on, else the static replicaCount.
*/}}
{{- define "mapserver-stack.mapserver.minReplicas" -}}
{{- if .Values.mapserver.autoscaling.enabled -}}
{{- .Values.mapserver.autoscaling.minReplicas -}}
{{- else -}}
{{- .Values.mapserver.replicaCount -}}
{{- end -}}
{{- end }}

{{/*
Mapserver ConfigMap name. One consolidated CM holds nginx.conf, mapserver.conf
and health.map; the deployment mounts each key via subPath.
*/}}
{{- define "mapserver-stack.mapserver.configMapName" -}}
{{- printf "%s-config" (include "mapserver-stack.mapserver.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Ingress object name. The "-ingress" suffix matches the operator's prune
selector and is also the conventional shape for chart-rendered Ingress objects.
*/}}
{{- define "mapserver-stack.ingress.fullname" -}}
{{- printf "%s-ingress" (include "mapserver-stack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
HTTPRoute object name. The "-route" suffix matches the operator's prune+delete
selector (child_name(svc, "route")).
*/}}
{{- define "mapserver-stack.httpRoute.fullname" -}}
{{- printf "%s-route" (include "mapserver-stack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Exposure routes: the ordered {path, service, port} list for the enabled
protocols, shared by the Ingress and HTTPRoute templates so routing logic
lives in one place. Args: dict "ctx" (root .), "prefix" (path prefix),
"mode" ("protocols" | "single"). Emits a YAML list; callers fromYamlArray it.
*/}}
{{- define "mapserver-stack.exposure.routes" -}}
{{- $ctx := .ctx -}}
{{- $prefix := .prefix -}}
{{- $msName := include "mapserver-stack.mapserver.fullname" $ctx -}}
{{- $msPort := $ctx.Values.mapserver.service.port -}}
{{- if eq .mode "protocols" -}}
{{- if $ctx.Values.protocols.wms.enabled }}
- path: {{ printf "%s/wms" $prefix }}
  service: {{ $msName }}
  port: {{ $msPort }}
{{- end }}
{{- if $ctx.Values.protocols.wfs.enabled }}
- path: {{ printf "%s/wfs" $prefix }}
  service: {{ $msName }}
  port: {{ $msPort }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Value validators
*/}}

{{- define "mapserver-stack.validate.exposure" -}}
{{- if and .Values.ingress.enabled .Values.httpRoute.enabled -}}
{{- fail "exposure: enable only one of ingress or httpRoute" -}}
{{- end -}}
{{- end }}

{{- define "mapserver-stack.validate.mapfiles" -}}
{{- $art := .Values.mapserver.mapfiles.artifact -}}
{{- if and (not $art.enabled) (not .Values.mapserver.mapfiles.configMap) -}}
{{- fail "mapserver.mapfiles: set either mapfiles.configMap or mapfiles.artifact.enabled=true" -}}
{{- end -}}
{{- if and $art.enabled (or (not $art.image.repository) (not $art.image.tag)) -}}
{{- fail "mapserver.mapfiles.artifact: image.repository and image.tag are both required" -}}
{{- end -}}
{{- end }}

{{- define "mapserver-stack.validate.s3" -}}
{{- if .Values.mapserver.s3.buckets -}}
{{- range .Values.mapserver.s3.buckets -}}
{{- if not .name -}}
{{- fail "mapserver.s3.buckets[].name is required for each bucket" -}}
{{- end -}}
{{- if not .bucket -}}
{{- fail (printf "mapserver.s3.buckets[].bucket is required for bucket '%s'" .name) -}}
{{- end -}}
{{- if not .secretName -}}
{{- fail (printf "mapserver.s3.buckets[].secretName is required for bucket '%s'" .name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Validate fullname leaves room for child suffixes. Longest suffix is
"-mapserver-config" (17 chars), so fullname must be <= 46 chars.
*/}}
{{- define "mapserver-stack.validate.names" -}}
{{- $full := include "mapserver-stack.fullname" . -}}
{{- $maxSuffix := 17 -}}
{{- if gt (add (len $full) $maxSuffix) 63 -}}
{{- fail (printf "fullname %q is %d chars; child names need %d more (longest suffix %q). shorten fullnameOverride to <= %d chars."
    $full (len $full) $maxSuffix "-mapserver-config" (sub 63 $maxSuffix)) -}}
{{- end -}}
{{- end }}
