{{/*
Canonical content blocks used by:
- the consolidated mapserver ConfigMap
- the deployment annotation hash (so rollouts only happen on content change).

nginxConfOverride / healthMapOverride remain as escape hatches for advanced
direct-helm users; the operator never sets them.
*/}}

{{- define "mapserver-stack.mapserverConf" -}}
CONFIG
  ENV
    MS_MAP_PATTERN "^/mapfiles/|^/etc/mapserver/|^/geodata/"
    MS_ERRORFILE "stderr"
    MS_WMS_ERROR_STATUS_CODE "ON"
  END

  MAPS
    "health" "/etc/mapserver/health.map"
    {{- if .Values.mapserver.defaultMapfile }}
    "default" {{ .Values.mapserver.defaultMapfile | quote }}
    {{- end }}
  END
END
{{- end }}

{{/*
Common fastcgi_param trailer used by every protocol location (the per-protocol
ones from mapserver.locations and the `/` catchall). Excludes SCRIPT_FILENAME
and MS_MAPFILE because those vary per location.
*/}}
{{- define "mapserver-stack.nginxConf.protocolFastcgiParams" -}}
fastcgi_param QUERY_STRING $query_string;
fastcgi_param REQUEST_METHOD $request_method;
fastcgi_param CONTENT_TYPE $content_type;
fastcgi_param CONTENT_LENGTH $content_length;
fastcgi_param REQUEST_URI $request_uri;
fastcgi_param DOCUMENT_URI $document_uri;
fastcgi_param SERVER_PROTOCOL $server_protocol;
fastcgi_param GATEWAY_INTERFACE CGI/1.1;
fastcgi_param SERVER_SOFTWARE nginx/$nginx_version;
fastcgi_param REMOTE_ADDR $remote_addr;
fastcgi_param REMOTE_PORT $remote_port;
fastcgi_param SERVER_ADDR $server_addr;
fastcgi_param SERVER_PORT $server_port;
fastcgi_param SERVER_NAME $server_name;
fastcgi_param HTTPS $https if_not_empty;
fastcgi_param HTTP_HOST $http_host;
fastcgi_param SCRIPT_NAME $fastcgi_script_name;
fastcgi_param REQUEST_SCHEME $scheme;
fastcgi_param PGSYSCONFDIR /etc/postgresql;
fastcgi_param PGSERVICEFILE /etc/postgresql/pg_service.conf;
fastcgi_param GDAL_CONFIG_FILE /home/www-data/.gdal/gdalrc;
fastcgi_connect_timeout 5s;
fastcgi_read_timeout 60s;
fastcgi_send_timeout 30s;
{{- end }}

{{/*
Canonical nginx.conf body. Driven by structured values:
- mapserver.fcgi.processes        (upstream port count, one per fcgi worker)
- mapserver.nginx.workerProcesses (default: fcgi.processes)
- mapserver.locations[]           (per-protocol path -> mapfile bindings)
- mapserver.postgis.connections[] (db_health_* layers in /ready query)
- mapserver.defaultMapfile        (MS_MAPFILE on / catchall)
*/}}
{{- define "mapserver-stack.nginxConf" -}}
{{- $workers := .Values.mapserver.nginx.workerProcesses | default .Values.mapserver.fcgi.processes -}}
worker_processes {{ $workers }};
error_log stderr warn;
pid /tmp/nginx.pid;

events {
    worker_connections 1024;
}

http {
    access_log /dev/stdout;

    client_body_temp_path /var/cache/nginx/client_body;
    proxy_temp_path /var/cache/nginx/proxy;
    fastcgi_temp_path /var/cache/nginx/fastcgi;

    sendfile on;
    tcp_nopush on;
    keepalive_timeout 65;

    gzip on;
    gzip_types text/xml application/xml text/plain application/json application/vnd.ogc.wms_xml;
    gzip_min_length 1000;

    upstream fcgi_backend {
        {{- range $i := until (.Values.mapserver.fcgi.processes | int) }}
        server 127.0.0.1:{{ add 9000 $i }};
        {{- end }}
    }

    server {
        listen 8080;
        server_name _;

        location /health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }

        location /ready {
            access_log off;
            fastcgi_pass fcgi_backend;
            fastcgi_param SCRIPT_FILENAME /usr/local/bin/mapserv;
            fastcgi_param MS_MAPFILE /etc/mapserver/health.map;
            {{- if .Values.mapserver.postgis.connections }}
            {{- $layers := list -}}
            {{- range .Values.mapserver.postgis.connections -}}
            {{- if .enabled -}}
            {{- $layers = append $layers (printf "db_health_%s" .name) -}}
            {{- end -}}
            {{- end }}
            fastcgi_param QUERY_STRING "SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS={{ join "," (sortAlpha $layers) }}&CRS=EPSG:4326&BBOX=-1,-1,1,1&WIDTH=1&HEIGHT=1&FORMAT=image/png";
            {{- else }}
            fastcgi_param QUERY_STRING "SERVICE=WMS&REQUEST=GetCapabilities";
            {{- end }}
            fastcgi_param REQUEST_METHOD GET;
            fastcgi_param CONTENT_TYPE "";
            fastcgi_param CONTENT_LENGTH "";
            fastcgi_param REQUEST_URI /ready;
            fastcgi_param DOCUMENT_URI /ready;
            fastcgi_param SERVER_PROTOCOL HTTP/1.1;
            fastcgi_param GATEWAY_INTERFACE CGI/1.1;
            fastcgi_param SERVER_SOFTWARE nginx/$nginx_version;
            fastcgi_param REMOTE_ADDR $remote_addr;
            fastcgi_param REMOTE_PORT $remote_port;
            fastcgi_param SERVER_ADDR $server_addr;
            fastcgi_param SERVER_PORT $server_port;
            fastcgi_param SERVER_NAME $server_name;
            fastcgi_param PGSYSCONFDIR /etc/postgresql;
            fastcgi_param PGSERVICEFILE /etc/postgresql/pg_service.conf;
            fastcgi_param GDAL_CONFIG_FILE /home/www-data/.gdal/gdalrc;

            fastcgi_connect_timeout 5s;
            fastcgi_read_timeout 10s;
            fastcgi_send_timeout 5s;
        }
        {{- range .Values.mapserver.locations }}

        location {{ .path }} {
            fastcgi_pass fcgi_backend;
            fastcgi_buffering on;
            fastcgi_buffer_size 32k;
            fastcgi_buffers 16 32k;
            fastcgi_param SCRIPT_FILENAME /usr/local/bin/mapserv;
            fastcgi_param MS_MAPFILE {{ .mapfile | quote }};
            {{- include "mapserver-stack.nginxConf.protocolFastcgiParams" $ | nindent 12 }}
        }
        {{- end }}

        location / {
            fastcgi_pass fcgi_backend;
            fastcgi_buffering on;
            fastcgi_buffer_size 32k;
            fastcgi_buffers 16 32k;
            fastcgi_param SCRIPT_FILENAME /usr/local/bin/mapserv;
            {{- if .Values.mapserver.defaultMapfile }}
            fastcgi_param MS_MAPFILE {{ .Values.mapserver.defaultMapfile | quote }};
            {{- end }}
            {{- include "mapserver-stack.nginxConf.protocolFastcgiParams" . | nindent 12 }}
        }
    }

    # loopback-only nginx metrics; scraped by the metrics sidecar (shared netns)
    server {
        listen 127.0.0.1:8090;
        location /nginx_status {
            stub_status;
            access_log off;
        }
    }
}
{{- end }}

{{/*
Canonical health.map body. Driven by mapserver.postgis.connections[] - each
enabled connection contributes a db_health_<name> layer that the readiness
probe queries via /ready.
*/}}
{{- define "mapserver-stack.healthMap" -}}
MAP
  NAME "health"
  EXTENT -1 -1 1 1
  UNITS DD
  PROJECTION
    "init=epsg:4326"
  END
  WEB
    METADATA
      "wms_title" "Health Check"
      "wms_onlineresource" "http://localhost/"
      "wms_enable_request" "*"
      "wms_srs" "EPSG:4326"
      "wms_allow_getmap_without_styles" "true"
    END
  END
  LAYER
    NAME "ping"
    TYPE POLYGON
    STATUS ON
    FEATURE
      WKT "POLYGON((-1 -1,-1 1,1 1,1 -1,-1 -1))"
    END
    CLASS
      STYLE COLOR 255 255 255 END
    END
  END
  {{- if .Values.mapserver.postgis.connections }}
  {{- $names := list -}}
  {{- range .Values.mapserver.postgis.connections -}}
  {{- if .enabled -}}
  {{- $names = append $names .name -}}
  {{- end -}}
  {{- end }}
  {{- range (sortAlpha $names) }}
  LAYER
    NAME "db_health_{{ . }}"
    TYPE POINT
    STATUS ON
    EXTENT -1 -1 1 1
    CONNECTIONTYPE POSTGIS
    CONNECTION "service={{ . }}"
    PROCESSING "CLOSE_CONNECTION=DEFER"
    DATA "geom FROM (SELECT ST_GeomFromText('POINT(0 0)', 4326) AS geom, 1 AS id) AS health_check USING UNIQUE id USING SRID=4326"
    CLASS
      STYLE COLOR 0 255 0 END
    END
  END
  {{- end }}
  {{- end }}
END
{{- end }}

{{/*
Body resolvers: prefer chart-rendered helper output; fall back to override
strings only if they're non-empty (advanced direct-helm escape hatch).
*/}}
{{- define "mapserver-stack.nginxConf.body" -}}
{{- if .Values.mapserver.nginxConfOverride -}}
{{- .Values.mapserver.nginxConfOverride -}}
{{- else -}}
{{- include "mapserver-stack.nginxConf" . -}}
{{- end -}}
{{- end }}

{{- define "mapserver-stack.healthMap.body" -}}
{{- if .Values.mapserver.healthMapOverride -}}
{{- .Values.mapserver.healthMapOverride -}}
{{- else -}}
{{- include "mapserver-stack.healthMap" . -}}
{{- end -}}
{{- end }}

{{/*
Canonical mapserver config-content block: data: section of the consolidated ConfigMap.
Hashed by the deployment annotation; emitted as data: of the consolidated CM.
*/}}
{{- define "mapserver-stack.mapserverConfig.canonical" -}}
nginx.conf: |
  {{- include "mapserver-stack.nginxConf.body" . | nindent 2 }}
mapserver.conf: |
  {{- include "mapserver-stack.mapserverConf" . | nindent 2 }}
health.map: |
  {{- include "mapserver-stack.healthMap.body" . | nindent 2 }}
{{- end }}

