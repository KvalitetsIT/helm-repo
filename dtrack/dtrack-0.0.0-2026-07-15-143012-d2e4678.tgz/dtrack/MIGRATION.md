# dtrack chart values migration prompt

Use this prompt with an LLM to migrate downstream values files for the v5-only chart cleanup (0.7.0):

```text
Update my dtrack Helm values for the v5-only chart release (0.7.0).

This chart is now v5-only. Rendering fails when backend.image.tag or frontend.image.tag has the "4." prefix.
If my values still target a v4 image, stop and tell me: v4 installs must stay on chart <= 0.6.x until they
complete the v4-to-v5 migration described in this chart's README before adopting 0.7.0.

Migrate the backend secret key to secret management (KEK):
- backend.secretKeySecret -> backend.secretManagement.kek.existingSecret, plus backend.secretManagement.kek.mode
  (default "config").
- Do NOT reuse the old secret.key value as the KEK. Generate a fresh KEK: config mode with
  `openssl rand -base64 32` into Secret key `kek`; keyset mode with `tinkey create-keyset --key-template
  AES256_GCM` into Secret key `kek-keyset.json` (keyset mode supports in-place KEK rotation).
- After cutover, re-run the bootstrap CronJob manually. A fresh KEK cannot decrypt anything encrypted under
  the old secret.key, and the v4-migrator (if a v4-to-v5 data migration is involved) nulls out DB-encrypted
  secret values anyway, so repository passwords and integration tokens must be re-seeded through bootstrap.
- Ask the user/operator before renaming or re-sealing the Secret. Many installations use SealedSecrets or
  externally managed Secrets where renaming requires re-sealing or recreating external resources. The
  suggested new name is dtrack-backend-kek (was dtrack-backend-secret-key); keep the old name in values if the
  operator does not want to re-seal.

Remove keys that no longer exist:
- backend.workers.threadMultiplier (no replacement; DT v5 sizes its own worker pools)
- backend.datanucleus.* (no replacement)
- migration.* (migration.enabled, migration.image, migration.source, migration.target,
  migration.offlineGuard, migration.metricsRetentionDays, migration.resources): migration moved out of
  this chart entirely into a separate, separately installed chart, dtrack-migration. If my values file has
  a migration block, remove it from the dtrack values file completely; it is not part of this chart
  anymore and has no effect here. If I still need to run a v4-to-v5 migration, tell me to re-express the
  same settings as dtrack-migration chart values in a separate values file: migration.source ->
  dtrack-migration's source, migration.target -> dtrack-migration's target, migration.offlineGuard ->
  dtrack-migration's offlineGuard. Point me at the dtrack-migration chart's README for the full runbook
  rather than trying to reproduce it here.

Rename environment variables in backend.env / backend.extraEnvs (ALPINE_* names no longer work; render fails
if any ALPINE_* name is present):
- ALPINE_METRICS_ENABLED -> DT_METRICS_ENABLED
- TELEMETRY_SUBMISSION_ENABLED_DEFAULT -> DT_TELEMETRY_SUBMISSION_DEFAULT_ENABLED
- LOGGING_CONFIG_PATH: <path> -> EXTRA_JAVA_OPTIONS: -Dlogback.configurationFile=<path>
- Any other ALPINE_* variable: translate to its DT_* equivalent per the Dependency-Track v5 configuration
  docs, or remove it if v5 has no equivalent. Do not leave any ALPINE_* names in place.

Review probe defaults:
- backend.livenessProbe and backend.readinessProbe now default to path /health/live and /health/ready
  respectively, served on the management port (backend.livenessProbe.port / backend.readinessProbe.port,
  default "http-metrics", port 8000) instead of the Jetty port. If I previously overrode path or port for
  these probes, keep my overrides working as-is; otherwise let the new defaults apply.
- A new backend.startupProbe block (periodSeconds/failureThreshold/timeoutSeconds, defaults 15/40/5) replaces
  any prior startup-probe configuration; raise failureThreshold if I need a wider budget for large
  post-migration init-task runs.

If migration.enabled was previously true and I am mid-migration on chart <= 0.6.x, tell me to finish that
migration cutover on 0.6.x first: this 0.7.0 release removes migration.* entirely and changes the probe and
secret-management defaults in ways that assume the migration is already complete or not yet started.

Preserve unrelated values. Do not add compatibility aliases. Remove old keys after migrating their values.
```
