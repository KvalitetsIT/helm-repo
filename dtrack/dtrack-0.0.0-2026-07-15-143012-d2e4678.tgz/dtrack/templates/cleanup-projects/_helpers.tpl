{{- define "dependencytrack-cleanup-projects.name" -}}
{{- printf "%s-cleanup-projects" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}
