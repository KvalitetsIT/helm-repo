{{/*
KEK (key-encryption key) helpers for the database secret-management provider.
The chart never generates the KEK; it is always sourced from an existing Secret.
*/}}

{{- define "dependencytrack.backend.kekMountDir" -}}/etc/dt/secrets/sm/database/kek{{- end }}

{{- define "dependencytrack.backend.kekMode" -}}
{{- $m := .Values.backend.secretManagement.kek.mode | default "config" -}}
{{- if not (has $m (list "config" "keyset")) -}}
{{- fail (printf "backend.secretManagement.kek.mode must be 'config' or 'keyset', got %q" $m) -}}
{{- end -}}
{{- $m -}}
{{- end }}

{{- define "dependencytrack.backend.kekKey" -}}
{{- $explicit := .Values.backend.secretManagement.kek.existingSecret.key -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else if eq (include "dependencytrack.backend.kekMode" .) "keyset" -}}
kek-keyset.json
{{- else -}}
kek
{{- end -}}
{{- end }}

{{- define "dependencytrack.backend.kekFilePath" -}}
{{- include "dependencytrack.backend.kekMountDir" . -}}/{{- include "dependencytrack.backend.kekKey" . -}}
{{- end }}

{{/*
KEK secret volume for the backend pod. The Secret key is projected read-only
into kekMountDir under the same name so the ${file::...} env reference resolves.
*/}}
{{- define "dependencytrack.backend.secretVolumes" -}}
- name: sm-database-kek
  secret:
    secretName: {{ .Values.backend.secretManagement.kek.existingSecret.name }}
    defaultMode: 0444
    items:
      - key: {{ include "dependencytrack.backend.kekKey" . }}
        path: {{ include "dependencytrack.backend.kekKey" . }}
{{- end }}

{{- define "dependencytrack.backend.secretVolumeMounts" -}}
- name: sm-database-kek
  mountPath: {{ include "dependencytrack.backend.kekMountDir" . }}
  readOnly: true
{{- end }}
