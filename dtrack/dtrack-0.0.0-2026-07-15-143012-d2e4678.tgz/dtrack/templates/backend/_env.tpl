{{/*
Assemble the chart-managed env for a backend pod, accounting for its role.

Usage: include "dependencytrack.backend.podEnv" (dict "ctx" . "role" "monolith")

$role selects the DT runtime profile. Only `monolith` is rendered today.
`web` (DT_CONFIG_PROFILE=web, background processing disabled) and `worker`
are the split-topology roles this switch is kept open for; do not add them
until a worker deployment lands.
*/}}
{{- define "dependencytrack.backend.podEnv" -}}
{{- $ctx := .ctx -}}
{{- $role := .role -}}
{{- $v := $ctx.Values -}}
{{- $backendAuth := include "dependencytrack.backend.authConfig" $ctx | fromYaml -}}
{{- $db := $v.backend.database -}}
{{- $jdbcUrl := include "dependencytrack.backendJdbcUrl" $ctx -}}
- name: DT_DATA_DIRECTORY
  value: "/data"
- name: DT_MANAGEMENT_PORT
  value: "8000"
- name: DT_SECRET_MANAGEMENT_PROVIDER
  value: "database"
{{- if eq (include "dependencytrack.backend.kekMode" $ctx) "keyset" }}
- name: DT_SECRET_MANAGEMENT_DATABASE_KEK_KEYSET_PATH
  value: "{{ include "dependencytrack.backend.kekFilePath" $ctx }}"
{{- else }}
- name: DT_SECRET_MANAGEMENT_DATABASE_KEK
  value: "${file::{{ include "dependencytrack.backend.kekFilePath" $ctx }}}"
{{- end }}
- name: DT_FILE_STORAGE_PROVIDER
  value: {{ $v.backend.fileStorage.provider | quote }}
{{- if eq $v.backend.fileStorage.provider "local" }}
- name: DT_FILE_STORAGE_LOCAL_DIRECTORY
  value: {{ $v.backend.fileStorage.local.directory | quote }}
{{- else if eq $v.backend.fileStorage.provider "s3" }}
- name: DT_FILE_STORAGE_S3_ENDPOINT
  value: {{ $v.backend.fileStorage.s3.endpoint | quote }}
- name: DT_FILE_STORAGE_S3_BUCKET
  value: {{ $v.backend.fileStorage.s3.bucket | quote }}
{{- with $v.backend.fileStorage.s3.region }}
- name: DT_FILE_STORAGE_S3_REGION
  value: {{ . | quote }}
{{- end }}
{{- with $v.backend.fileStorage.s3.credentialsSecret.name }}
- name: DT_FILE_STORAGE_S3_ACCESS_KEY
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: {{ $v.backend.fileStorage.s3.credentialsSecret.accessKeyKey }}
- name: DT_FILE_STORAGE_S3_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: {{ $v.backend.fileStorage.s3.credentialsSecret.secretKeyKey }}
{{- end }}
{{- end }}
- name: DT_OIDC_ENABLED
  value: {{ $backendAuth.enabled | quote }}
- name: DT_OIDC_ISSUER
  value: {{ $backendAuth.issuerUrl | quote }}
- name: DT_OIDC_CLIENT_ID
  value: {{ $backendAuth.clientId | quote }}
- name: DT_OIDC_USERNAME_CLAIM
  value: {{ $backendAuth.usernameClaim | quote }}
- name: DT_OIDC_USER_PROVISIONING
  value: {{ $backendAuth.userProvisioning | quote }}
- name: DT_OIDC_TEAMS_CLAIM
  value: {{ $backendAuth.teamsClaim | quote }}
- name: DT_OIDC_TEAM_SYNCHRONIZATION
  value: {{ $backendAuth.teamSynchronization | quote }}
- name: DT_CORS_ENABLED
  value: {{ $v.backend.cors.enabled | quote }}
- name: DT_CORS_ALLOWED_ORIGINS
  value: {{ $v.backend.cors.allowOrigin | quote }}
- name: DT_CORS_ALLOWED_METHODS
  value: {{ $v.backend.cors.allowMethods | quote }}
- name: DT_CORS_ALLOWED_HEADERS
  value: {{ $v.backend.cors.allowHeaders | quote }}
- name: DT_CORS_EXPOSED_HEADERS
  value: {{ $v.backend.cors.exposeHeaders | quote }}
- name: DT_CORS_ALLOW_CREDENTIALS
  value: {{ $v.backend.cors.allowCredentials | quote }}
- name: DT_CORS_MAX_AGE
  value: {{ $v.backend.cors.maxAge | quote }}
- name: DT_DATASOURCE_URL
  value: {{ printf "%s?sslmode=disable" $jdbcUrl | quote }}
- name: DT_DATASOURCE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ required "PostgreSQL password secret name is required" $db.passwordSecret.name }}
      key: {{ required "PostgreSQL password secret key is required" $db.passwordSecret.key }}
- name: DT_DATASOURCE_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ required "PostgreSQL username secret name is required" $db.usernameSecret.name }}
      key: {{ required "PostgreSQL username secret key is required" $db.usernameSecret.key }}
- name: DT_DATASOURCE_POOL_MAX_SIZE
  value: {{ $v.backend.pool.maxSize | quote }}
- name: DT_DATASOURCE_POOL_MIN_IDLE
  value: {{ $v.backend.pool.minIdle | quote }}
- name: DT_DATASOURCE_POOL_IDLE_TIMEOUT
  value: {{ $v.backend.pool.idleTimeout | quote }}
- name: DT_DATASOURCE_POOL_MAX_LIFETIME
  value: {{ $v.backend.pool.maxLifetime | quote }}
{{- if ne (int $v.backend.workers.threads) 0 }}
- name: DT_TASK_SCHEDULER_THREADS
  value: {{ $v.backend.workers.threads | quote }}
{{- end }}
{{- if eq $role "web" }}
- name: DT_CONFIG_PROFILE
  value: "web"
{{- end }}
{{- end }}

{{/*
Render backend.env / backend.extraEnvs verbatim.
Usage: include "dependencytrack.backend.userEnv" .
*/}}
{{- define "dependencytrack.backend.userEnv" -}}
{{- with concat (.Values.backend.env | default list) (.Values.backend.extraEnvs | default list) -}}
{{- toYaml . -}}
{{- end -}}
{{- end }}
