{{/*
wait-for-backend init container. Blocks a job until the backend /version
endpoint responds. Shared by the bootstrap and migrate-tags jobs (and any
future job binaries) so the container spec is defined once and driven by
global.waitForBackend.
Usage:
  include "dependencytrack.waitForBackend" (dict "context" . "apiUrl" (include "dependencytrack.backendApiUrl" .))
Rendered at 0-base indent; callers use nindent to place it under initContainers.
*/}}
{{- define "dependencytrack.waitForBackend" -}}
{{- $ctx := .context -}}
{{- $wfb := $ctx.Values.global.waitForBackend | default dict -}}
- name: wait-for-backend
  image: {{ include "dependencytrack.imageRef" (dict "image" (dig "image" dict $wfb) "global" $ctx.Values.global) | quote }}
  imagePullPolicy: {{ dig "image" "pullPolicy" "IfNotPresent" $wfb }}
  command:
    - sh
    - -c
    - |
      deadline=$(($(date +%s) + {{ dig "timeoutSeconds" 300 $wfb }}))
      until wget -q --spider "{{ .apiUrl }}/version" 2>/dev/null; do
        if [ "$(date +%s)" -ge "$deadline" ]; then
          echo "timed out waiting for backend"
          exit 1
        fi
        echo "waiting for backend..."
        sleep {{ dig "periodSeconds" 5 $wfb }}
      done
  resources:
    requests:
      cpu: 10m
      memory: 16Mi
    limits:
      memory: 32Mi
  securityContext:
    runAsNonRoot: true
    runAsUser: 1000
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
{{- end }}
