{{- define "dependencytrack-migrate-tags.name" -}}
{{- printf "%s-migrate-tags" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}
