{{/*
Job spec shared between the bootstrap Job and CronJob.
Render at 0-base indent; callers use nindent to place it correctly:
  - bootstrap-job.yaml:     include ... | nindent 2
  - bootstrap-cronjob.yaml: include ... | nindent 6
*/}}
{{- define "dependencytrack.bootstrap.jobspec" -}}
{{- $b := .Values.bootstrap | default dict -}}
ttlSecondsAfterFinished: 60
backoffLimit: 6
template:
  metadata:
    name: "{{ .Release.Name }}-bootstrap"
    labels:
      app.kubernetes.io/name: {{ include "dependencytrack.name" . }}-bootstrap
      app.kubernetes.io/instance: {{ .Release.Name }}
      app.kubernetes.io/component: bootstrap
      app.kubernetes.io/managed-by: {{ .Release.Service }}
      helm.sh/chart: {{ include "dependencytrack.chart" . }}
  spec:
    restartPolicy: Never
    {{- $pullSecret := .Values.bootstrap.image.pullSecret | default .Values.global.imagePullSecret }}
    {{- if $pullSecret }}
    imagePullSecrets:
      - name: {{ $pullSecret }}
    {{- end }}
    securityContext:
      seccompProfile:
        type: RuntimeDefault
      runAsUser: 1000
      runAsGroup: 1000
      fsGroup: 1000
    containers:
      - name: "{{ .Release.Name }}-bootstrap"
        image: {{ include "imageRef" .Values.bootstrap.image | quote }}
        volumeMounts:
          - name: bootstrap
            mountPath: "/bootstrap"
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          runAsGroup: 1000
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
              - ALL
        resources:
          {{- toYaml .Values.bootstrap.resources | nindent 10 }}
        env:
          - name: LOG_LEVEL
            value: "{{ .Values.bootstrap.logLevel }}"
          - name: BASE_URL
            value: "{{ include "dependencytrack.backendApiUrl" . }}"
          - name: DEFAULT_ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: "{{ .Release.Name }}-bootstrap"
                key: DEFAULT_ADMIN_PASSWORD
        {{- if dig "analyzers" "sonatype" "username" "" $b }}
          - name: SONATYPE_API_USERNAME
            valueFrom:
              secretKeyRef:
                name: "{{ .Release.Name }}-bootstrap"
                key: SONATYPE_API_USERNAME
        {{- end }}
        {{- if .Values.bootstrap.adminPasswordSecret.name }}
          - name: ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: {{ .Values.bootstrap.adminPasswordSecret.name }}
                key: {{ .Values.bootstrap.adminPasswordSecret.key }}
        {{- end }}
        {{- if dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "name" "" $b }}
          - name: GITHUB_ADVISORY_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "name" "" $b }}
                key: {{ dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "key" "" $b }}
        {{- end }}
        {{- if dig "analyzers" "trivy" "apiTokenSecret" "name" "" $b }}
          - name: TRIVY_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "analyzers" "trivy" "apiTokenSecret" "name" "" $b }}
                key: {{ dig "analyzers" "trivy" "apiTokenSecret" "key" "" $b }}
        {{- end }}
        {{- if dig "analyzers" "sonatype" "tokenSecret" "name" "" $b }}
          - name: SONATYPE_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "analyzers" "sonatype" "tokenSecret" "name" "" $b }}
                key: {{ dig "analyzers" "sonatype" "tokenSecret" "key" "" $b }}
        {{- end }}
        {{- if dig "vulnerabilitySources" "nvd" "apiKeySecret" "name" "" $b }}
          - name: NVD_API_KEY
            valueFrom:
              secretKeyRef:
                name: {{ dig "vulnerabilitySources" "nvd" "apiKeySecret" "name" "" $b }}
                key: {{ dig "vulnerabilitySources" "nvd" "apiKeySecret" "key" "" $b }}
        {{- end }}
        {{- range $i, $repository := ($b.repositories | default list) }}
        {{- if and $repository.passwordSecret $repository.passwordSecret.name $repository.passwordSecret.key }}
          - name: {{ printf "BOOTSTRAP_REPOSITORY_PASSWORD_%d" $i }}
            valueFrom:
              secretKeyRef:
                name: {{ $repository.passwordSecret.name }}
                key: {{ $repository.passwordSecret.key }}
        {{- end }}
        {{- end }}
    volumes:
      - name: bootstrap
        secret:
          secretName: "{{ .Release.Name }}-bootstrap"
{{- end }}
