{{/*
Job spec shared between the bootstrap Job and CronJob.
Render at 0-base indent; callers use nindent to place it correctly:
  - bootstrap-job.yaml:     include ... | nindent 2
  - bootstrap-cronjob.yaml: include ... | nindent 6
*/}}
{{- define "dependencytrack.bootstrap.jobspec" -}}
{{- $bootstrap := include "dependencytrack.bootstrap.config" . | fromYaml -}}
ttlSecondsAfterFinished: 60
backoffLimit: 6
template:
  metadata:
    name: "{{ .Release.Name }}-bootstrap"
    labels:
      app.kubernetes.io/name: {{ include "dependencytrack.name" . }}-bootstrap
      app.kubernetes.io/instance: {{ .Release.Name }}
      app.kubernetes.io/component: bootstrap
      app.kubernetes.io/managed-by: {{ .Release.Service }}
      helm.sh/chart: {{ include "dependencytrack.chart" . }}
  spec:
    restartPolicy: Never
    {{- $pullSecret := .Values.bootstrap.image.pullSecret | default .Values.global.imagePullSecret }}
    {{- if $pullSecret }}
    imagePullSecrets:
      - name: {{ $pullSecret }}
    {{- end }}
    securityContext:
      seccompProfile:
        type: RuntimeDefault
      runAsUser: 1000
      runAsGroup: 1000
      fsGroup: 1000
    containers:
      - name: "{{ .Release.Name }}-bootstrap"
        image: {{ include "imageRef" .Values.bootstrap.image | quote }}
        volumeMounts:
          - name: bootstrap
            mountPath: "/bootstrap"
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          runAsGroup: 1000
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
              - ALL
        resources:
          {{- toYaml .Values.bootstrap.resources | nindent 10 }}
        env:
          - name: LOG_LEVEL
            value: "{{ .Values.bootstrap.logLevel }}"
          - name: BASE_URL
            value: "{{ include "dependencytrack.backendApiUrl" . }}"
          - name: DEFAULT_ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: "{{ .Release.Name }}-bootstrap"
                key: DEFAULT_ADMIN_PASSWORD
        {{- if $bootstrap.analyzers.sonatype.username }}
          - name: SONATYPE_API_USERNAME
            valueFrom:
              secretKeyRef:
                name: "{{ .Release.Name }}-bootstrap"
                key: SONATYPE_API_USERNAME
        {{- end }}
        {{- if .Values.bootstrap.adminPasswordSecret.name }}
          - name: ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: {{ .Values.bootstrap.adminPasswordSecret.name }}
                key: {{ .Values.bootstrap.adminPasswordSecret.key }}
        {{- end }}
        {{- if $bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name }}
          - name: GITHUB_ADVISORY_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ $bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name }}
                key: {{ $bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.key }}
        {{- end }}
        {{- if $bootstrap.analyzers.trivy.apiTokenSecret.name }}
          - name: TRIVY_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ $bootstrap.analyzers.trivy.apiTokenSecret.name }}
                key: {{ $bootstrap.analyzers.trivy.apiTokenSecret.key }}
        {{- end }}
        {{- if $bootstrap.analyzers.sonatype.tokenSecret.name }}
          - name: SONATYPE_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ $bootstrap.analyzers.sonatype.tokenSecret.name }}
                key: {{ $bootstrap.analyzers.sonatype.tokenSecret.key }}
        {{- end }}
        {{- if $bootstrap.vulnerabilitySources.nvd.apiKeySecret.name }}
          - name: NVD_API_KEY
            valueFrom:
              secretKeyRef:
                name: {{ $bootstrap.vulnerabilitySources.nvd.apiKeySecret.name }}
                key: {{ $bootstrap.vulnerabilitySources.nvd.apiKeySecret.key }}
        {{- end }}
        {{- range $repository := ($bootstrap.repositories | default list) }}
        {{- if and $repository.passwordSecret $repository.passwordSecret.name $repository.passwordSecret.key $repository.passwordEnvVar }}
          - name: {{ $repository.passwordEnvVar }}
            valueFrom:
              secretKeyRef:
                name: {{ $repository.passwordSecret.name }}
                key: {{ $repository.passwordSecret.key }}
        {{- end }}
        {{- end }}
    volumes:
      - name: bootstrap
        secret:
          secretName: "{{ .Release.Name }}-bootstrap"
{{- end }}
