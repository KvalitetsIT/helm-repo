{{- define "dependencytrack-bootstrap.name" -}}
{{- printf "%s-bootstrap" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Job spec for the suspended bootstrap CronJob. Manually created Jobs inherit it.
Render at 0-base indent; bootstrap-cronjob.yaml uses nindent 6.
*/}}
{{- define "dependencytrack.bootstrap.jobspec" -}}
{{- $b := .Values.bootstrap | default dict -}}
ttlSecondsAfterFinished: 60
backoffLimit: 6
template:
  metadata:
    name: {{ include "dependencytrack-bootstrap.name" . | quote }}
    labels:
      app.kubernetes.io/name: {{ include "dependencytrack-bootstrap.name" . }}
      app.kubernetes.io/instance: {{ .Release.Name }}
      app.kubernetes.io/component: bootstrap
      app.kubernetes.io/managed-by: {{ .Release.Service }}
      helm.sh/chart: {{ include "dependencytrack.chart" . }}
  spec:
    restartPolicy: Never
    {{- $pullSecrets := concat (.Values.global.imagePullSecrets | default list) (.Values.bootstrap.image.pullSecrets | default list) }}
    {{- with $pullSecrets }}
    imagePullSecrets:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    initContainers:
      {{- include "dependencytrack.waitForBackend" (dict "context" . "apiUrl" (include "dependencytrack.backendApiUrl" .)) | nindent 6 }}
    securityContext:
      seccompProfile:
        type: RuntimeDefault
      runAsUser: 1000
      runAsGroup: 1000
      fsGroup: 1000
    containers:
      - name: {{ include "dependencytrack-bootstrap.name" . | quote }}
        image: {{ include "dependencytrack.imageRef" (dict "image" .Values.bootstrap.image "global" .Values.global) | quote }}
        volumeMounts:
          - name: bootstrap
            mountPath: "/bootstrap"
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          runAsGroup: 1000
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
              - ALL
        resources:
          {{- toYaml .Values.bootstrap.resources | nindent 10 }}
        env:
          - name: LOG_LEVEL
            value: "{{ .Values.bootstrap.logLevel }}"
          - name: BASE_URL
            value: "{{ include "dependencytrack.backendApiUrl" . }}"
          - name: DEFAULT_ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: {{ include "dependencytrack-bootstrap.name" . | quote }}
                key: DEFAULT_ADMIN_PASSWORD
        {{- if dig "analyzers" "sonatype" "username" "" $b }}
          - name: SONATYPE_API_USERNAME
            valueFrom:
              secretKeyRef:
                name: {{ include "dependencytrack-bootstrap.name" . | quote }}
                key: SONATYPE_API_USERNAME
        {{- end }}
        {{- if .Values.bootstrap.adminPasswordSecret.name }}
          - name: ADMIN_PASSWORD
            valueFrom:
              secretKeyRef:
                name: {{ .Values.bootstrap.adminPasswordSecret.name }}
                key: {{ .Values.bootstrap.adminPasswordSecret.key }}
        {{- end }}
        {{- if dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "name" "" $b }}
          - name: GITHUB_ADVISORY_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "name" "" $b }}
                key: {{ dig "vulnerabilitySources" "githubAdvisories" "tokenSecret" "key" "" $b }}
        {{- end }}
        {{- if dig "analyzers" "trivy" "apiTokenSecret" "name" "" $b }}
          - name: TRIVY_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "analyzers" "trivy" "apiTokenSecret" "name" "" $b }}
                key: {{ dig "analyzers" "trivy" "apiTokenSecret" "key" "" $b }}
        {{- end }}
        {{- if dig "analyzers" "sonatype" "tokenSecret" "name" "" $b }}
          - name: SONATYPE_API_TOKEN
            valueFrom:
              secretKeyRef:
                name: {{ dig "analyzers" "sonatype" "tokenSecret" "name" "" $b }}
                key: {{ dig "analyzers" "sonatype" "tokenSecret" "key" "" $b }}
        {{- end }}
        {{- range $i, $repository := concat ($b.repositories | default list) (dig "extraRepositories" (list) $b) }}
        {{- if and $repository.passwordSecret $repository.passwordSecret.name $repository.passwordSecret.key }}
          - name: {{ printf "BOOTSTRAP_REPOSITORY_PASSWORD_%d" $i }}
            valueFrom:
              secretKeyRef:
                name: {{ $repository.passwordSecret.name }}
                key: {{ $repository.passwordSecret.key }}
        {{- end }}
        {{- end }}
    volumes:
      - name: bootstrap
        secret:
          secretName: {{ include "dependencytrack-bootstrap.name" . | quote }}
{{- end }}
