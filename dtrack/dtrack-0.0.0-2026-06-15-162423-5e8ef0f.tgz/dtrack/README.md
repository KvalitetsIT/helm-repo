# DependencyTrack Helm Chart

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.5.0](https://img.shields.io/badge/AppVersion-0.5.0-informational?style=flat-square)

This chart deploys OWASP Dependency-Track (backend API server and frontend UI), plus optional bootstrap job
for initial provisioning of identities, repositories, vulnerability sources, and analyzers, and an optional Trivy vulnerability scanning service.
Routing is supported via standard Kubernetes Ingress or Gateway API (HTTPRoute + ListenerSet).

## Authentication (OIDC / Keycloak)

Both backend and frontend share the same OIDC configuration via `global.auth`. The `clientId` is shared — the frontend authenticates with it and the backend validates tokens issued to that same client.

```yaml
global:
  auth:
    enabled: true
    baseUrl: https://keycloak.example.com
    realm: dependency-track
    clientId: dtrack
```

## Private Registry

To pull all images from a private registry mirror, set `global.imageRegistry`. Components with an explicit `image.registry` (bootstrap uses `docker.io`, Trivy uses `ghcr.io`) keep their default unless overridden per-component.

```yaml
global:
  imageRegistry: mirror.example.com
  imagePullSecrets:
    - name: regcred
```

## Quick Start

Minimum required values to get a working installation:

```yaml
backend:
  secretKeySecret:
    name: my-secret   # must contain a 'secretKey' field

gateway-routes:
  routes:
    backend:
      httpRoute:
        hostnames:
          - dtrack-api.example.com
    frontend:
      httpRoute:
        hostnames:
          - dtrack.example.com
```

## Network Policies

The chart renders Kubernetes `NetworkPolicy` and `CiliumNetworkPolicy` resources from the `networkPolicies` and `ciliumNetworkPolicies` value maps.

Port values in `networkPolicies` must be integers (a Kubernetes requirement). Because Helm's `tpl` function cannot produce unquoted integers from template expressions, ports in the built-in `networkPolicies.backend` entry are hardcoded to their well-known defaults (`8080`, `8000`, `5432`, `4954`).

> **If you change `backend.postgresql.port` from the default `5432`, you must also override the corresponding egress rule in `networkPolicies.backend`.**

To disable all network policies:

```yaml
networkPolicies: ~
ciliumNetworkPolicies: ~
```

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global | object | `{"auth":{"baseUrl":"","clientId":"","enabled":false,"realm":"","teamSynchronization":true,"teamsClaim":"groups","userProvisioning":true,"usernameClaim":"preferred_username"},"commonAnnotations":{},"ghcrRepositories":["ghcr.io","pkg-containers.githubusercontent.com","*.ghcr.io"],"githubApi":["api.github.com"],"googleOsv":["osv-vulnerabilities.storage.googleapis.com"],"image":{"registry":""},"imagePullSecrets":[],"nvdApi":["nvd.nist.gov"],"packageRepositories":["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","pkg-containers.githubusercontent.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"],"sonatypeApi":["ossindex.sonatype.org"],"vulnerabilityFeeds":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]}` | Global configuration options |
| global.commonAnnotations | object | `{}` | Common annotations to add to all resources |
| global.imagePullSecrets | list | `[]` | Image pull secrets applied to all workloads. Per-component pullSecrets are merged with this list. |
| global.image.registry | string | `""` | Registry prefix applied to all component images. Takes precedence over per-component image.registry. |
| global.packageRepositories | list | `["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","pkg-containers.githubusercontent.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"]` | Package repository domains reachable by Cilium policies |
| global.vulnerabilityFeeds | list | `["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]` | Vulnerability feed domains reachable by Cilium policies |
| global.ghcrRepositories | list | `["ghcr.io","pkg-containers.githubusercontent.com","*.ghcr.io"]` | GitHub Container Registry domains reachable by Trivy |
| global.githubApi | list | `["api.github.com"]` | GitHub API domains for advisory and token-backed integrations |
| global.googleOsv | list | `["osv-vulnerabilities.storage.googleapis.com"]` | Google OSV domains for bootstrap OSV integration |
| global.nvdApi | list | `["nvd.nist.gov"]` | NVD API domains for bootstrap NVD integration |
| global.sonatypeApi | list | `["ossindex.sonatype.org"]` | Sonatype OSS Index domains for bootstrap analyzer integration |
| global.auth | object | See [values.yaml](values.yaml) | Shared OIDC/Keycloak auth configuration applied to both backend and frontend |
| global.auth.enabled | bool | `false` | Enable OIDC authentication |
| global.auth.baseUrl | string | `""` | Keycloak base URL (e.g. https://keycloak.example.com) |
| global.auth.realm | string | `""` | Keycloak realm name |
| global.auth.clientId | string | `""` | OAuth2 client ID |
| global.auth.usernameClaim | string | `"preferred_username"` | JWT claim used as the username |
| global.auth.userProvisioning | bool | `true` | Auto-provision users from Keycloak on first login |
| global.auth.teamsClaim | string | `"groups"` | JWT claim containing team/group membership |
| global.auth.teamSynchronization | bool | `true` | Sync team membership on every login |

### Bootstrap Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| bootstrap | object | See [values.yaml](values.yaml) | Bootstrap job configuration for initial Dependency-Track setup (users, teams, groups, repositories, vulnerability sources, analyzers) |
| bootstrap.enabled | bool | `true` | Whether to run the bootstrap job (creates users/teams/groups) |
| bootstrap.logLevel | string | `"INFO"` | Log level for bootstrap container (TRACE|DEBUG|INFO|WARN|ERROR) |
| bootstrap.image | object | `{"digest":"","pullSecrets":[],"registry":"docker.io","repository":"kvalitetsit/dtrack-bootstrap","tag":"0.5.0"}` | Bootstrap job image configuration |
| bootstrap.image.registry | string | `"docker.io"` | Fallback registry prefix for bootstrap image. Overridden by global.image.registry when set. |
| bootstrap.image.repository | string | `"kvalitetsit/dtrack-bootstrap"` | Image repository path (without registry prefix) |
| bootstrap.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| bootstrap.image.pullSecrets | list | `[]` | Image pull secrets for bootstrap job. Merged with global.imagePullSecrets. |
| bootstrap.image.tag | string | `"0.5.0"` | Image tag (overwritten automatically by CI on release) |
| bootstrap.baseUrl | string | `""` | Backend API base URL (must point to Dependency-Track /api endpoint). If empty, auto-generates based on release name. |
| bootstrap.frontendBaseUrl | string | `""` | Frontend base URL for UI links (optional) |
| bootstrap.identities | object | `{"extraOidcGroups":[],"extraTeams":[],"extraUsers":[],"oidcGroups":[],"teams":[],"userSync":"replace","users":[]}` | Identity objects created by the bootstrap job. The rendered bootstrap.yaml is mounted at /bootstrap/bootstrap.yaml inside the job pod. |
| bootstrap.identities.userSync | string | `"replace"` | How users are reconciled: replace (default) removes and recreates all listed users each run; create only adds new users without removing; ignore skips user management entirely. |
| bootstrap.identities.users | list | `[]` | Admin users to create |
| bootstrap.identities.teams | list | `[]` | Teams to create |
| bootstrap.identities.extraTeams | list | `[]` | Additional teams merged with `teams` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.extraUsers | list | `[]` | Additional users merged with `users` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.oidcGroups | list | `[]` | OIDC group-to-team mappings to create |
| bootstrap.identities.extraOidcGroups | list | `[]` | Additional OIDC group-to-team mappings merged with `oidcGroups` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.defaultAdminPassword | string | `"admin"` | Default admin password expected in a fresh install (used to rotate to adminPasswordSecret) |
| bootstrap.adminPasswordSecret | object | `{"key":"admin-password","name":"dtrack-bootstrap"}` | Secret containing new admin password |
| bootstrap.adminPasswordSecret.name | string | `"dtrack-bootstrap"` | Secret name containing admin password |
| bootstrap.adminPasswordSecret.key | string | `"admin-password"` | Key within secret containing admin password |
| bootstrap.vulnerabilitySources | object | `{"githubAdvisories":{"enabled":true,"tokenSecret":{"key":"","name":""}},"googleOsv":{"enabled":true},"nvd":{"apiKeySecret":{"key":"","name":""},"enabled":true}}` | Vulnerability source configuration managed by the bootstrap job |
| bootstrap.vulnerabilitySources.googleOsv | object | `{"enabled":true}` | Google OSV ingestion configuration |
| bootstrap.vulnerabilitySources.googleOsv.enabled | bool | `true` | Enable Google OSV ingestion during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories | object | `{"enabled":true,"tokenSecret":{"key":"","name":""}}` | GitHub advisory mirroring configuration |
| bootstrap.vulnerabilitySources.githubAdvisories.enabled | bool | `true` | Enable GitHub advisory mirroring during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name | string | `""` | Secret name containing GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.key | string | `""` | Key containing GitHub advisory token |
| bootstrap.vulnerabilitySources.nvd | object | `{"apiKeySecret":{"key":"","name":""},"enabled":true}` | NVD integration configuration |
| bootstrap.vulnerabilitySources.nvd.enabled | bool | `true` | Enable NVD integration during bootstrap |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret | object | `{"key":"","name":""}` | Secret reference for NVD API key |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.name | string | `""` | Secret name containing the NVD API key |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.key | string | `""` | Key containing the NVD API key |
| bootstrap.analyzers | object | See [values.yaml](values.yaml) | Analyzer configuration managed by the bootstrap job |
| bootstrap.analyzers.trivy.enabled | bool | `true` | Enable Trivy analyzer during bootstrap |
| bootstrap.analyzers.trivy.ignoreUnfixed | bool | `true` | Ignore unfixed vulnerabilities in Dependency-Track Trivy analyzer |
| bootstrap.analyzers.trivy.baseUrl | string | `""` | External Trivy URL. If empty and bundled Trivy is enabled, the in-cluster URL is used |
| bootstrap.analyzers.trivy.apiTokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.name | string | `""` | Secret name containing Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.key | string | `""` | Key containing Trivy API token |
| bootstrap.analyzers.sonatype.enabled | bool | `false` | Enable Sonatype OSS Index analyzer during bootstrap |
| bootstrap.analyzers.sonatype.username | string | `""` | Sonatype OSS Index username |
| bootstrap.analyzers.sonatype.tokenSecret | object | `{"key":"","name":""}` | Secret reference for Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.name | string | `""` | Secret name containing Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.key | string | `""` | Key containing Sonatype OSS Index token |
| bootstrap.repositories | list | `[]` | Repository objects managed by the bootstrap job. Each entry maps to one Dependency-Track repository object. |
| bootstrap.extraRepositories | list | `[]` | Additional repositories merged with `repositories` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.waitForBackend | object | `{"image":"busybox:1.37","periodSeconds":5,"timeoutSeconds":300}` | Init container that polls the backend /api/version endpoint before the bootstrap container starts. |
| bootstrap.waitForBackend.image | string | `"busybox:1.37"` | Image used by the init container (must have sh and wget) |
| bootstrap.waitForBackend.periodSeconds | int | `5` | Seconds between readiness poll attempts |
| bootstrap.waitForBackend.timeoutSeconds | int | `300` | Maximum seconds to wait before failing the init container |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | See [values.yaml](values.yaml) | Dependency-Track API server configuration |
| backend.logLevel | string | `"INFO"` | Backend log level |
| backend.jvm | object | `{"options":"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"}` | JVM tuning options passed via JAVA_TOOL_OPTIONS |
| backend.jvm.options | string | `"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"` | JVM flags (e.g. GC, heap sizing). Empty string = JVM defaults. |
| backend.image | object | `{"digest":"sha256:ee5f27462afa73201a362c0d8e3203b56367ffa059a661e26dedeb83dd92ae6b","pullPolicy":"IfNotPresent","pullSecrets":[],"registry":"","repository":"dependencytrack/apiserver","tag":"4.14.2-alpine"}` | Backend container image configuration |
| backend.image.registry | string | `""` | Fallback registry prefix for backend image. Overridden by global.image.registry when set. |
| backend.image.repository | string | `"dependencytrack/apiserver"` | Image repository path (without registry prefix) |
| backend.image.digest | string | `"sha256:ee5f27462afa73201a362c0d8e3203b56367ffa059a661e26dedeb83dd92ae6b"` | Optional image digest (e.g., sha256:...) |
| backend.image.pullSecrets | list | `[]` | Image pull secrets for backend pods. Merged with global.imagePullSecrets. |
| backend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| backend.image.tag | string | `"4.14.2-alpine"` | Overrides the image tag whose default is the chart appVersion |
| backend.replicaCount | int | `2` | Number of backend replicas |
| backend.podLabels | object | `{}` | Additional labels to add to backend pods |
| backend.podAnnotations | object | `{}` | Additional annotations to add to backend pods |
| backend.extraVolumes | list | `[]` | Additional volumes for backend pod (e.g., mount custom CA bundle) |
| backend.extraVolumeMounts | list | `[]` | Additional volume mounts for backend container |
| backend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for backend pods |
| backend.ingress | object | `{"annotations":{},"className":"","enabled":false,"host":"","tls":[]}` | Ingress configuration for backend API |
| backend.ingress.enabled | bool | `false` | Enable Ingress for backend API |
| backend.ingress.className | string | `""` | Ingress class name |
| backend.ingress.annotations | object | `{}` | Ingress annotations |
| backend.ingress.host | string | `""` | Ingress hostname |
| backend.ingress.tls | list | `[]` | TLS configuration |
| backend.livenessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/api/version","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Liveness probe configuration |
| backend.livenessProbe.enabled | bool | `true` | Enable liveness probe |
| backend.livenessProbe.path | string | `"/api/version"` | Path for liveness probe |
| backend.livenessProbe.initialDelaySeconds | int | `60` | Initial delay before liveness probe starts |
| backend.livenessProbe.periodSeconds | int | `10` | Period between liveness probe checks |
| backend.livenessProbe.timeoutSeconds | int | `2` | Timeout for liveness probe |
| backend.livenessProbe.successThreshold | int | `1` | Success threshold for liveness probe |
| backend.livenessProbe.failureThreshold | int | `3` | Failure threshold for liveness probe |
| backend.readinessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Readiness probe configuration |
| backend.readinessProbe.enabled | bool | `true` | Enable readiness probe |
| backend.readinessProbe.path | string | `"/"` | Path for readiness probe |
| backend.readinessProbe.initialDelaySeconds | int | `60` | Initial delay before readiness probe starts |
| backend.readinessProbe.periodSeconds | int | `10` | Period between readiness probe checks |
| backend.readinessProbe.timeoutSeconds | int | `2` | Timeout for readiness probe |
| backend.readinessProbe.successThreshold | int | `1` | Success threshold for readiness probe |
| backend.readinessProbe.failureThreshold | int | `3` | Failure threshold for readiness probe |
| backend.postgresql | object | See [values.yaml](values.yaml) | PostgreSQL database configuration |
| backend.postgresql.enabled | bool | `true` | Enable PostgreSQL for backend |
| backend.postgresql.database | string | `"dtrack"` | Database name |
| backend.postgresql.serviceName | string | `"postgresql"` | PostgreSQL service name (used for auto-generating host if not set) |
| backend.postgresql.passwordSecret.name | string | `"dtrack-postgres-user-secret"` | Secret name containing PostgreSQL password |
| backend.postgresql.passwordSecret.key | string | `"password"` | Key within secret containing PostgreSQL password |
| backend.postgresql.usernameSecret.name | string | `"dtrack-postgres-user-secret"` | Secret name containing PostgreSQL username |
| backend.postgresql.usernameSecret.key | string | `"username"` | Key within secret containing PostgreSQL username |
| backend.postgresql.host | string | `""` | PostgreSQL host. If empty, auto-generates FQDN based on serviceName and namespace. |
| backend.postgresql.namespace | string | `""` | Namespace of PostgreSQL workload for native NetworkPolicy egress |
| backend.postgresql.port | int | `5432` | PostgreSQL port |
| backend.postgresql.connectionName | string | `""` | Cloud SQL connection name (for GCP) |
| backend.postgresql.ip | string | `""` | PostgreSQL IP address |
| backend.secretKeySecret | object | `{"key":"secret.key","name":""}` | Secret providing Alpine secret.key content (required for deterministic encryption) |
| backend.secretKeySecret.name | string | `""` | Secret name containing secret.key |
| backend.secretKeySecret.key | string | `"secret.key"` | Key within secret containing secret.key content |
| backend.service | object | `{"labels":{"istio.io/ingress-use-waypoint":"true","istio.io/use-waypoint":"waypoint"}}` | Service configuration for backend |
| backend.service.labels | object | `{"istio.io/ingress-use-waypoint":"true","istio.io/use-waypoint":"waypoint"}` | Additional labels to add to the backend Service |
| backend.service.labels."istio.io/use-waypoint" | string | `"waypoint"` | Route traffic through the Istio waypoint proxy for L7 policy enforcement. |
| backend.service.labels."istio.io/ingress-use-waypoint" | string | `"true"` | Apply waypoint enforcement to ingress traffic only (not east-west mesh traffic). |
| backend.serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Service account configuration |
| backend.serviceAccount.create | bool | `true` | Create service account for backend |
| backend.serviceMonitor | object | `{"enabled":false}` | Backend ServiceMonitor configuration (used by Prometheus) |
| backend.serviceMonitor.enabled | bool | `false` | When true, add a netpol rule allowing Prometheus to scrape metrics |
| backend.persistence | object | `{"accessMode":"ReadWriteOnce","enableStatefulSetAutoDeletePVC":true,"existingClaim":"","size":"10Gi","storageClass":"","whenDeleted":"Delete","whenScaled":"Delete"}` | Persistence configuration for backend storage |
| backend.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for persistent volume |
| backend.persistence.size | string | `"10Gi"` | Size of persistent volume |
| backend.persistence.storageClass | string | `""` | Storage class for persistent volume |
| backend.persistence.existingClaim | string | `""` | Use existing PVC claim |
| backend.persistence.enableStatefulSetAutoDeletePVC | bool | `true` | Enable automatic PVC deletion in StatefulSet |
| backend.persistence.whenDeleted | string | `"Delete"` | PVC retention policy when StatefulSet is deleted |
| backend.persistence.whenScaled | string | `"Delete"` | PVC retention policy when StatefulSet is scaled down |
| backend.truststore | object | `{"accessMode":"ReadWriteOnce","ca":{"cert":"","enabled":false},"enabled":false,"mountPath":"/opt/java/openjdk/lib/security","storage":"100M","storageClassName":""}` | Truststore configuration for CA certificates |
| backend.truststore.enabled | bool | `false` | Enable truststore PVC for CA certificates |
| backend.truststore.storage | string | `"100M"` | Storage size for truststore PVC |
| backend.truststore.storageClassName | string | `""` | Storage class for truststore PVC (optional) |
| backend.truststore.accessMode | string | `"ReadWriteOnce"` | Access mode for truststore PVC |
| backend.truststore.mountPath | string | `"/opt/java/openjdk/lib/security"` | Mount path for truststore PVC |
| backend.truststore.ca | object | `{"cert":"","enabled":false}` | Root CA certificate configuration |
| backend.truststore.ca.enabled | bool | `false` | Create ConfigMap with root CA certificate |
| backend.truststore.ca.cert | string | `""` | Root CA certificate content (PEM format) |
| backend.pool | object | `{"idleTimeout":300000,"maxLifetime":600000,"maxSize":20,"minIdle":10}` | Database connection pool configuration |
| backend.pool.maxSize | int | `20` | Maximum number of database connections (idle + in-use) |
| backend.pool.minIdle | int | `10` | Minimum number of idle connections maintained in the pool |
| backend.pool.idleTimeout | int | `300000` | Maximum time (ms) a connection can sit idle before being removed |
| backend.pool.maxLifetime | int | `600000` | Maximum lifetime (ms) of a connection in the pool |
| backend.workers | object | `{"threadMultiplier":4,"threads":0}` | Event subsystem worker thread configuration |
| backend.workers.threads | int | `0` | Number of worker threads (0 = auto-detect from CPU cores) |
| backend.workers.threadMultiplier | int | `4` | Multiplier applied to CPU cores when threads=0 |
| backend.datanucleus | object | `{"cacheLevel2Type":""}` | DataNucleus ORM cache configuration |
| backend.datanucleus.cacheLevel2Type | string | `""` | L2 cache reference type ("soft" or "weak"). Empty = DTrack default ("soft"). Use "weak" for large deployments to allow GC reclamation under memory pressure. |
| backend.cors | object | `{"allowCredentials":true,"allowHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *","allowMethods":"GET, POST, PUT, PATCH, DELETE, OPTIONS","allowOrigin":"","enabled":true,"exposeHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count","maxAge":3600}` | Cross-Origin Resource Sharing (CORS) configuration |
| backend.cors.enabled | bool | `true` | Enable CORS headers in REST responses |
| backend.cors.allowOrigin | string | `""` | Allowed origins (empty string = allow all) |
| backend.cors.allowMethods | string | `"GET, POST, PUT, PATCH, DELETE, OPTIONS"` | Allowed HTTP methods |
| backend.cors.allowHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *"` | Allowed request headers |
| backend.cors.exposeHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count"` | Headers exposed to the browser |
| backend.cors.allowCredentials | bool | `true` | Allow credentials (cookies, auth headers) |
| backend.cors.maxAge | int | `3600` | Preflight response cache duration in seconds |
| backend.env | object | `{"ALPINE_METRICS_ENABLED":true,"LOGGING_CONFIG_PATH":"logback-json.xml","TELEMETRY_SUBMISSION_ENABLED_DEFAULT":false}` | Additional environment variables for backend container |
| backend.env.ALPINE_METRICS_ENABLED | bool | `true` | Enable Alpine metrics endpoint for Prometheus monitoring |
| backend.env.LOGGING_CONFIG_PATH | string | `"logback-json.xml"` | Path to logging configuration file within the container |

### Frontend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| frontend | object | See [values.yaml](values.yaml) | Dependency-Track UI configuration |
| frontend.swagger | object | `{"enabled":false,"path":"/swagger","port":8181}` | Swagger UI configuration |
| frontend.swagger.enabled | bool | `false` | Enable Swagger UI |
| frontend.swagger.path | string | `"/swagger"` | Swagger UI path |
| frontend.swagger.port | int | `8181` | Swagger UI port |
| frontend.image | object | `{"digest":"sha256:00560b57a6cfdec3c02a6e02be80fce97029241a9c653e8b83c0b670dff1f3ca","pullPolicy":"IfNotPresent","pullSecrets":[],"registry":"","repository":"dependencytrack/frontend","tag":"4.14.2"}` | Frontend container image configuration |
| frontend.image.registry | string | `""` | Fallback registry prefix for frontend image. Overridden by global.image.registry when set. |
| frontend.image.repository | string | `"dependencytrack/frontend"` | Image repository path (without registry prefix) |
| frontend.image.digest | string | `"sha256:00560b57a6cfdec3c02a6e02be80fce97029241a9c653e8b83c0b670dff1f3ca"` | Optional image digest (e.g., sha256:...) |
| frontend.image.pullSecrets | list | `[]` | Image pull secrets for frontend pods. Merged with global.imagePullSecrets. |
| frontend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| frontend.image.tag | string | `"4.14.2"` | Overrides the image tag whose default is the chart appVersion |
| frontend.service | object | `{"labels":{"istio.io/ingress-use-waypoint":"true","istio.io/use-waypoint":"waypoint"}}` | Service configuration for frontend |
| frontend.service.labels | object | `{"istio.io/ingress-use-waypoint":"true","istio.io/use-waypoint":"waypoint"}` | Additional labels to add to the frontend Service |
| frontend.service.labels."istio.io/use-waypoint" | string | `"waypoint"` | Route traffic through the Istio waypoint proxy for L7 policy enforcement. |
| frontend.service.labels."istio.io/ingress-use-waypoint" | string | `"true"` | Apply waypoint enforcement to ingress traffic only (not east-west mesh traffic). |
| frontend.replicaCount | int | `1` | Number of frontend replicas |
| frontend.podLabels | object | `{}` | Additional labels to add to frontend pods |
| frontend.podAnnotations | object | `{}` | Additional annotations to add to frontend pods |
| frontend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for frontend pods |
| frontend.ingress | object | `{"annotations":{},"className":"","enabled":false,"host":"","tls":[]}` | Ingress configuration for frontend UI |
| frontend.ingress.enabled | bool | `false` | Enable Ingress for frontend UI |
| frontend.ingress.className | string | `""` | Ingress class name |
| frontend.ingress.annotations | object | `{}` | Ingress annotations |
| frontend.ingress.host | string | `""` | Ingress hostname |
| frontend.ingress.tls | list | `[]` | TLS configuration |
| frontend.apiBaseUrl | string | `""` | API base URL exposed to browser clients. If empty, auto-generates from backend ingress or service |
| frontend.env | object | `{}` | Additional frontend environment variables beyond the derived API/OIDC keys |

### Trivy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| trivy | object | See [values.yaml](values.yaml) | Trivy server configuration (bundled vulnerability scanner) |
| trivy.enabled | bool | `true` | Enable Trivy server deployment |
| trivy.nameOverride | string | `""` | Override name for Trivy resources |
| trivy.fullnameOverride | string | `""` | Override full name for Trivy resources |
| trivy.replicaCount | int | `1` | Number of Trivy replicas |
| trivy.image | object | `{"digest":"sha256:016eae51fdcf989332a5404af7e8f625cd5d95d7c0907a221d080a996f556500","pullPolicy":"IfNotPresent","pullSecrets":[],"registry":"ghcr.io","repository":"aquasecurity/trivy","tag":"0.71.0"}` | Trivy container image configuration |
| trivy.image.registry | string | `"ghcr.io"` | Fallback registry prefix for Trivy image. Overridden by global.image.registry when set. |
| trivy.image.repository | string | `"aquasecurity/trivy"` | Image repository path (without registry prefix) |
| trivy.image.digest | string | `"sha256:016eae51fdcf989332a5404af7e8f625cd5d95d7c0907a221d080a996f556500"` | Optional image digest (e.g., sha256:...) |
| trivy.image.tag | string | `"0.71.0"` | Trivy image tag |
| trivy.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| trivy.image.pullSecrets | list | `[]` | Image pull secrets for Trivy pods. Merged with global.imagePullSecrets. |
| trivy.persistence | object | `{"accessMode":"ReadWriteOnce","enabled":true,"size":"5Gi","storageClass":""}` | Persistence configuration for Trivy cache |
| trivy.persistence.enabled | bool | `true` | Enable persistence for Trivy cache |
| trivy.persistence.storageClass | string | `""` | Storage class for Trivy persistent volume |
| trivy.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for Trivy persistent volume |
| trivy.persistence.size | string | `"5Gi"` | Size of Trivy persistent volume |
| trivy.resources | object | `{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"200m","memory":"512Mi"}}` | Resource requests and limits for Trivy pods |
| trivy.resources.requests | object | `{"cpu":"200m","memory":"512Mi"}` | Resource requests for Trivy pods |
| trivy.resources.requests.cpu | string | `"200m"` | CPU request for Trivy pods |
| trivy.resources.requests.memory | string | `"512Mi"` | Memory request for Trivy pods |
| trivy.resources.limits | object | `{"cpu":1,"memory":"1Gi"}` | Resource limits for Trivy pods |
| trivy.resources.limits.cpu | int | `1` | CPU limit for Trivy pods |
| trivy.resources.limits.memory | string | `"1Gi"` | Memory limit for Trivy pods |
| trivy.podSecurityContext | object | `{"fsGroup":65534,"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context for Trivy pods |
| trivy.podSecurityContext.runAsUser | int | `65534` | User ID to run Trivy pods |
| trivy.podSecurityContext.runAsNonRoot | bool | `true` | Enforce non-root user for Trivy pods |
| trivy.podSecurityContext.fsGroup | int | `65534` | File system group for Trivy pods |
| trivy.podSecurityContext.seccompProfile | object | `{"type":"RuntimeDefault"}` | Seccomp profile for Trivy pods |
| trivy.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` | Seccomp profile type for Trivy pods |
| trivy.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true}` | Container security context for Trivy |
| trivy.securityContext.privileged | bool | `false` | Run Trivy container in privileged mode |
| trivy.securityContext.readOnlyRootFilesystem | bool | `true` | Enforce read-only root filesystem for Trivy container |
| trivy.securityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation for Trivy container |
| trivy.securityContext.capabilities | object | `{"drop":["ALL"]}` | Capabilities for Trivy container |
| trivy.securityContext.capabilities.drop | list | `["ALL"]` | Capabilities to drop for Trivy container |
| trivy.nodeSelector | object | `{}` | Node selector for Trivy pods |
| trivy.affinity | object | `{}` | Affinity settings for Trivy pods |
| trivy.tolerations | list | `[]` | Tolerations for Trivy pods |
| trivy.podAnnotations | object | `{}` | Annotations for Trivy pods |
| trivy.config | object | `{"dbRepository":"ghcr.io/aquasecurity/trivy-db","debugMode":false,"githubTokenSecret":{"key":"","name":""},"httpProxy":"","httpsProxy":"","noProxy":"","registryPasswordSecret":{"key":"","name":""},"registryUsernameSecret":{"key":"","name":""},"skipDBUpdate":false,"tokenSecret":{"key":"","name":""}}` | Additional Trivy configuration options |
| trivy.config.debugMode | bool | `false` | Enable debug mode for Trivy |
| trivy.config.githubTokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub token |
| trivy.config.githubTokenSecret.name | string | `""` | Secret name containing GitHub token for Trivy |
| trivy.config.githubTokenSecret.key | string | `""` | Key within secret containing GitHub token for Trivy |
| trivy.config.tokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| trivy.config.tokenSecret.name | string | `""` | Secret name containing Trivy API token |
| trivy.config.tokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| trivy.config.registryUsernameSecret | object | `{"key":"","name":""}` | Secret reference for registry username |
| trivy.config.registryUsernameSecret.name | string | `""` | Secret name containing registry username for Trivy |
| trivy.config.registryUsernameSecret.key | string | `""` | Key within secret containing registry username for Trivy |
| trivy.config.registryPasswordSecret | object | `{"key":"","name":""}` | Secret reference for registry password |
| trivy.config.registryPasswordSecret.name | string | `""` | Secret name containing registry password for Trivy |
| trivy.config.registryPasswordSecret.key | string | `""` | Key within secret containing registry password for Trivy |
| trivy.config.skipDBUpdate | bool | `false` | Skip database update on Trivy startup |
| trivy.config.dbRepository | string | `"ghcr.io/aquasecurity/trivy-db"` | Trivy database repository |
| trivy.config.httpProxy | string | `""` | HTTP proxy for Trivy |
| trivy.config.httpsProxy | string | `""` | HTTPS proxy for Trivy |
| trivy.config.noProxy | string | `""` | No proxy settings for Trivy |
| trivy.cache | object | `{"redis":{"enabled":false,"tls":false,"ttl":"","url":""}}` | Trivy cache configuration |
| trivy.cache.redis | object | `{"enabled":false,"tls":false,"ttl":"","url":""}` | Redis cache configuration for Trivy |
| trivy.cache.redis.enabled | bool | `false` | Enable Redis cache for Trivy |
| trivy.cache.redis.url | string | `""` | Redis URL for Trivy cache |
| trivy.cache.redis.ttl | string | `""` | Time-to-live for Redis cache entries |
| trivy.cache.redis.tls | bool | `false` | Enable TLS for Redis connection |
| trivy.probes | object | `{"liveness":{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}}` | Liveness and readiness probe configuration for Trivy |
| trivy.probes.liveness | object | `{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Liveness probe configuration for Trivy |
| trivy.probes.liveness.initialDelaySeconds | int | `5` | Initial delay before liveness probe starts |
| trivy.probes.liveness.periodSeconds | int | `10` | Period between liveness probe checks |
| trivy.probes.liveness.successThreshold | int | `1` | Success threshold for liveness probe |
| trivy.probes.liveness.failureThreshold | int | `10` | Failure threshold for liveness probe |
| trivy.probes.readiness | object | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Readiness probe configuration for Trivy |
| trivy.probes.readiness.initialDelaySeconds | int | `5` | Initial delay before readiness probe starts |
| trivy.probes.readiness.periodSeconds | int | `10` | Period between readiness probe checks |
| trivy.probes.readiness.successThreshold | int | `1` | Success threshold for readiness probe |
| trivy.probes.readiness.failureThreshold | int | `3` | Failure threshold for readiness probe |
| trivy.serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Service account configuration for Trivy |
| trivy.serviceAccount.create | bool | `true` | Create a dedicated service account for Trivy |
| trivy.serviceAccount.name | string | `""` | Override the Trivy service account name |
| trivy.serviceAccount.annotations | object | `{}` | Annotations for Trivy service account |
| trivy.extraLabels | object | `{}` | Extra labels to add to Trivy resources |
| trivy.extraEnvVars | list | `[]` | Extra environment variables for Trivy container |

### Network Policies

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicies | object | See [values.yaml](values.yaml) | Map of Kubernetes NetworkPolicy resources. K8s-only entries (no matching ciliumNetworkPolicies key) are always rendered. Entries that share a key with ciliumNetworkPolicies act as fallbacks on non-Cilium clusters. |
| ciliumNetworkPolicies | object | See [values.yaml](values.yaml) | Map of CiliumNetworkPolicy resources. Rendered only when cilium.io/v2 is available. Entries sharing a key with networkPolicies fall back to K8s NetworkPolicy on non-Cilium clusters. |
| templates | object | `{}` | Configuration for the KvalitetsIT templates library chart (https://github.com/KvalitetsIT/helm-templates-chart). Use templates.sealedSecrets, templates.resources, etc. to render additional resources via the library. |

### Gateway Routes

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| gateway-routes | object | `{"routes":{"backend":{"httpRoute":{"hostnames":[],"rules":[{"backendRefs":[{"name":"dtrack-backend","port":8080}]}]}},"frontend":{"httpRoute":{"hostnames":[],"rules":[{"backendRefs":[{"name":"dtrack-frontend","port":80}]}]}}}}` | Configuration for the KvalitetsIT gateway-routes chart (https://github.com/KvalitetsIT/helm-gateway-routes-chart). Declares HTTPRoute and ListenerSet resources against an existing Istio gateway. |
| gateway-routes.routes.backend.httpRoute | object | `{"hostnames":[],"rules":[{"backendRefs":[{"name":"dtrack-backend","port":8080}]}]}` | HTTPRoute config for the backend API |
| gateway-routes.routes.backend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack-api.example.com]) |
| gateway-routes.routes.frontend.httpRoute | object | `{"hostnames":[],"rules":[{"backendRefs":[{"name":"dtrack-frontend","port":80}]}]}` | HTTPRoute config for the frontend UI |
| gateway-routes.routes.frontend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack.example.com]) |

## Prerequisites

- Kubernetes 1.25+
- Istio with Gateway API support (HTTPRoute + ListenerSet)
- An existing `Gateway` resource (e.g. `ingressgateway` in namespace `istio-ingress`)
- cert-manager with a `ClusterIssuer` for TLS (e.g. `letsencrypt-prod-istio`)

## Gateway Configuration

This chart supports two routing options that can be used independently or together:

- **Gateway API** (recommended): uses the [KvalitetsIT gateway-routes](https://github.com/KvalitetsIT/helm-gateway-routes-chart) library chart to declare `HTTPRoute` + `ListenerSet` resources against an existing Istio gateway.
- **Ingress**: standard Kubernetes `Ingress` resources, enabled via `backend.ingress.enabled` / `frontend.ingress.enabled`.

Set the hostnames and point at your existing Istio gateway:

```yaml
gateway-routes:
  defaults:
    gateway:
      name: ingressgateway        # name of your Gateway resource
      namespace: istio-ingress    # namespace where the Gateway lives
    clusterIssuer: letsencrypt-prod-istio

  routes:
    backend:
      httpRoute:
        hostnames:
          - dtrack-api.example.com
    frontend:
      httpRoute:
        hostnames:
          - dtrack.example.com
```

The frontend `API_BASE_URL` environment variable is derived automatically from `gateway-routes.routes.backend.httpRoute.hostnames[0]`. You only need to set `frontend.apiBaseUrl` explicitly if you want to override this.
