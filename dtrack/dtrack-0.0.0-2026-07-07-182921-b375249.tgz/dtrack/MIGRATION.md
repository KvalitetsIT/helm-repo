# dtrack chart values migration prompt

Use this prompt with an LLM to migrate downstream values files for the chart cleanup PR:

```text
Update my dtrack Helm values for the breaking chart cleanup.

Rename replica keys everywhere:
- backend.replicaCount -> backend.replicas
- frontend.replicaCount -> frontend.replicas
- trivy.replicaCount -> trivy.replicas

Migrate backend database configuration:
- backend.postgresql.database -> backend.database.name
- backend.postgresql.serviceName -> backend.database.serviceName
- backend.postgresql.namespace -> backend.database.namespace
- backend.postgresql.port -> backend.database.port
- backend.postgresql.passwordSecret -> backend.database.passwordSecret
- backend.postgresql.usernameSecret -> backend.database.usernameSecret

Remove keys that no longer exist:
- backend.postgresql.enabled (PostgreSQL is always configured by backend.database)
- backend.postgresql.host (use backend.database.serviceName and backend.database.namespace)
- backend.postgresql.connectionName
- backend.postgresql.ip
- backend.secretKeySecret.key (the Secret key must be named secret.key)
- bootstrap.endpoints.frontend.url (use bootstrap.frontendBaseUrl instead)
- fullnameOverride (use nameOverride only if a custom release/name base is required)
- trivy.nameOverride
- trivy.fullnameOverride
- trivy.extraLabels
- trivy.extraEnvVars (use trivy.extraEnvs)
- frontend.swagger.*

Rename/fix documented-but-wrong keys if present:
- global.imageRegistry -> global.image.registry
- bootstrap.baseUrl -> global.baseUrl (now shared by all job binaries; migrateTags.baseUrl no longer exists)

Review wait-for-backend settings (now shared across all job binaries):
- bootstrap.waitForBackend -> global.waitForBackend. Move any customized image/periodSeconds/timeoutSeconds there; per-component waitForBackend keys (bootstrap.waitForBackend, migrateTags.waitForBackend) no longer exist.
- global.waitForBackend.image is an image object. Move an old string value into global.waitForBackend.image.repository/tag or set registry/repository/tag/digest explicitly.

Review persistence behavior:
- backend PVC retention is now safer by default. If I previously relied on automatic PVC deletion, add backend.persistentVolumeClaimRetentionPolicy explicitly.
- Convert persistence accessMode fields to accessModes lists.
- Convert persistence size fields to resources.requests.storage.

Review environment variables:
- Convert backend.env and frontend.env maps to env lists with name/value entries.
- Use extraEnvs for overlay-only additions where needed.
- Move envFrom-style references to envFrom/extraEnvFrom lists if present.

Review bootstrap identity validation:
- Team references in bootstrap identities are validated against identities.teams, identities.extraTeams, and identities.defaultTeams.
- Dependency-Track predefined teams are included in identities.defaultTeams by default: Administrators, Automation, Badge Viewers, Portfolio Managers.
- If my values intentionally reference other pre-existing/external teams that are not managed by this chart, either add them to identities.defaultTeams or set identities.validate=false as an escape hatch.

Review resource names and route backendRefs:
- backend/frontend resource names are now release-qualified. If I override gateway-routes backendRefs manually, update them to the rendered backend/frontend Service names for my release.

Review Secret resource names and ownership:
- Prefer the current naming convention when creating new Secrets: dtrack-backend-secret-key, dtrack-bootstrap-secrets, dtrack-integration-secrets, and dtrack-postgres-credentials.
- Do not blindly rename existing Secrets. Ask the user/operator what they want to do, because many installations use SealedSecrets or externally managed Secrets where a simple Kubernetes Secret rename will not work. Renaming may require re-sealing, recreating external resources, or keeping the old Secret names in values.
- If keeping existing Secret names, preserve the existing `name` values under backend.secretKeySecret, bootstrap.*Secret, trivy.config.*Secret, and backend.database.*Secret.
- If adopting dtrack-integration-secrets, ensure the Trivy API token referenced by bootstrap.analyzers.trivy.apiTokenSecret and trivy.config.tokenSecret points to the same value when bundled Trivy is enabled.

Preserve unrelated values. Do not add compatibility aliases. Remove old keys after migrating their values.
```
