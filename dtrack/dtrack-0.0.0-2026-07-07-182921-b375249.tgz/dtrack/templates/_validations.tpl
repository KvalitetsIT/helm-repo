{{- define "dependencytrack.validateBackendReplicas" -}}
{{- if ne (int .Values.backend.replicas) 1 -}}
  {{- fail "backend.replicas must be 1 for Dependency-Track 4.x. HA support can be enabled when this chart upgrades to Dependency-Track v5." -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateDatabase" -}}
{{- if not (.Values.backend.database.serviceName | default "" | trim) -}}
  {{- fail "backend.database.serviceName is required and must point at an existing PostgreSQL Service" -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateWaitForBackend" -}}
{{- $wfb := .Values.global.waitForBackend | default dict -}}
{{- if not (kindIs "map" $wfb.image) -}}
  {{- fail "global.waitForBackend.image must be an image object with registry/repository/tag/digest, not a string" -}}
{{- end -}}
{{- if not ($wfb.image.repository | default "" | trim) -}}
  {{- fail "global.waitForBackend.image.repository is required" -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateEnvList" -}}
{{- $component := .component -}}
{{- $reserved := .reserved | default list -}}
{{- if and .values.env (not (kindIs "slice" .values.env)) -}}
  {{- fail (printf "%s.env must be a list of EnvVar objects. Convert map-style env to entries like: - name: FOO; value: bar" $component) -}}
{{- end -}}
{{- if and .values.extraEnvs (not (kindIs "slice" .values.extraEnvs)) -}}
  {{- fail (printf "%s.extraEnvs must be a list of EnvVar objects" $component) -}}
{{- end -}}
{{- if and .values.envFrom (not (kindIs "slice" .values.envFrom)) -}}
  {{- fail (printf "%s.envFrom must be a list of EnvFromSource objects" $component) -}}
{{- end -}}
{{- if and .values.extraEnvFrom (not (kindIs "slice" .values.extraEnvFrom)) -}}
  {{- fail (printf "%s.extraEnvFrom must be a list of EnvFromSource objects" $component) -}}
{{- end -}}
{{- $seen := list -}}
{{- range concat (.values.env | default list) (.values.extraEnvs | default list) -}}
  {{- if not .name -}}
    {{- fail (printf "%s.env/extraEnvs entries must include name" $component) -}}
  {{- end -}}
  {{- if has .name $seen -}}
    {{- fail (printf "%s env contains duplicate variable %q" $component .name) -}}
  {{- end -}}
  {{- if has .name $reserved -}}
    {{- fail (printf "%s env variable %q is chart-managed and cannot be overridden" $component .name) -}}
  {{- end -}}
  {{- $seen = append $seen .name -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateEnvs" -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "backend" "values" .Values.backend "reserved" (list "JAVA_TOOL_OPTIONS" "LOGGING_LEVEL" "ALPINE_DATA_DIRECTORY" "ALPINE_SECRET_KEY_PATH" "ALPINE_OIDC_ENABLED" "ALPINE_OIDC_ISSUER" "ALPINE_OIDC_CLIENT_ID" "ALPINE_OIDC_USERNAME_CLAIM" "ALPINE_OIDC_USER_PROVISIONING" "ALPINE_OIDC_TEAMS_CLAIM" "ALPINE_OIDC_TEAM_SYNCHRONIZATION" "ALPINE_DATABASE_MODE" "ALPINE_DATABASE_DRIVER" "ALPINE_DATABASE_URL" "ALPINE_DATABASE_PASSWORD" "ALPINE_DATABASE_USERNAME" "ALPINE_CORS_ENABLED" "ALPINE_CORS_ALLOW_ORIGIN" "ALPINE_CORS_ALLOW_METHODS" "ALPINE_CORS_ALLOW_HEADERS" "ALPINE_CORS_EXPOSE_HEADERS" "ALPINE_CORS_ALLOW_CREDENTIALS" "ALPINE_CORS_MAX_AGE" "ALPINE_DATABASE_POOL_MAX_SIZE" "ALPINE_DATABASE_POOL_MIN_IDLE" "ALPINE_DATABASE_POOL_IDLE_TIMEOUT" "ALPINE_DATABASE_POOL_MAX_LIFETIME" "ALPINE_WORKER_THREADS" "ALPINE_WORKER_THREAD_MULTIPLIER" "ALPINE_DATANUCLEUS_CACHE_LEVEL2_TYPE")) -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "frontend" "values" .Values.frontend "reserved" (list "API_BASE_URL" "OIDC_ISSUER" "OIDC_CLIENT_ID")) -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "trivy" "values" .Values.trivy "reserved" (list "TRIVY_DEBUG" "TRIVY_SKIP_DB_UPDATE" "TRIVY_DB_REPOSITORY" "TRIVY_CACHE_DIR" "TRIVY_CACHE_BACKEND" "TRIVY_CACHE_TTL" "TRIVY_REDIS_TLS" "HTTP_PROXY" "HTTPS_PROXY" "NO_PROXY" "TRIVY_USERNAME" "TRIVY_PASSWORD" "TRIVY_TOKEN" "GITHUB_TOKEN")) -}}
{{- end -}}

{{- define "dependencytrack.validate" -}}
{{- include "dependencytrack.validateBackendReplicas" . -}}
{{- include "dependencytrack.validateDatabase" . -}}
{{- include "dependencytrack.validateWaitForBackend" . -}}
{{- include "dependencytrack.validateEnvs" . -}}
{{- end -}}
