{{/*
Expand the name of the chart.
*/}}
{{- define "dependencytrack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}


{{- define "dependencytrack-backend.name" -}}
{{- .Chart.Name }}-backend
{{- end }}

{{- define "dependencytrack-frontend.name" -}}
{{- .Chart.Name }}-frontend
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this ().
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dependencytrack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dependencytrack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-backend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-frontend.labels" -}}
{{ include "dependencytrack-frontend.selectorLabels" . }}
{{- if .Chart.Version }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for backend
*/}}
{{- define "dependencytrack-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Selector labels for frontend
*/}}
{{- define "dependencytrack-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: frontend
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dependencytrack.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dependencytrack.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dependencytrack.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.global.commonAnnotations }}
{{- $annotations = merge $annotations .Values.global.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "dependencytrack.hasCommonAnnotations" -}}
{{- if .Values.global.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Build complete image reference from repository and tag
Usage: imageRef $component (e.g., imageRef $values.backend.image)
*/}}
{{- define "imageRef" -}}
{{- $repo := .repository -}}
{{- $tag := .tag | default "latest" -}}
{{- printf "%s:%s" $repo $tag -}}
{{- end }}

{{/*
Get egress repositories for a component, merged with global
Usage: include "egressRepositories" (dict "component" .Values.backend "global" .Values.global)
*/}}
{{- define "egressRepositories" -}}
{{- $global := .global.egress.repositories | default list -}}
{{- $component := .component.networkPolicy.repositories | default list -}}
{{- concat $global $component | uniq | toYaml -}}
{{- end }}

{{/*
Get vulnerability databases for a component, merged with global
Usage: include "egressVulnDatabases" (dict "component" .Values.backend "global" .Values.global)
*/}}
{{- define "egressVulnDatabases" -}}
{{- $global := .global.egress.vulnerabilityDatabases | default list -}}
{{- $component := .component.networkPolicy.vulnerabilityDatabases | default list -}}
{{- concat $global $component | uniq | toYaml -}}
{{- end }}

{{/*
Get the backend API base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.backendApiUrl" -}}
{{- if .Values.bootstrap.baseUrl -}}
{{- .Values.bootstrap.baseUrl -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local:8080/api" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the frontend API base URL (for browser access)
*/}}
{{- define "dependencytrack.frontendApiUrl" -}}
{{- if .Values.frontend.env.API_BASE_URL -}}
{{- .Values.frontend.env.API_BASE_URL -}}
{{- else if .Values.backend.ingress.enabled -}}
{{- if .Values.backend.ingress.tls -}}
{{- printf "https://%s" .Values.backend.ingress.host -}}
{{- else -}}
{{- printf "http://%s" .Values.backend.ingress.host -}}
{{- end -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the Trivy base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.trivyBaseUrl" -}}
{{- if .Values.bootstrap.trivy.base_url -}}
{{- .Values.bootstrap.trivy.base_url -}}
{{- else if .Values.trivy.enabled -}}
{{- $trivyServiceName := .Values.trivy.service.name | default (include "trivy.fullname" .) -}}
{{- printf "http://%s.%s.svc.cluster.local:4954" $trivyServiceName .Release.Namespace -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
Get the PostgreSQL host (FQDN)
*/}}
{{- define "dependencytrack.postgresqlHost" -}}
{{- if and .Values.backend.postgresql.host (ne .Values.backend.postgresql.host "") -}}
{{- .Values.backend.postgresql.host -}}
{{- else -}}
{{- $serviceName := .Values.backend.postgresql.serviceName | default "postgresql" -}}
{{- $namespace := .Values.backend.networkPolicy.postgresql.namespace | default .Release.Namespace -}}
{{- printf "%s.%s.svc.cluster.local" $serviceName $namespace -}}
{{- end -}}
{{- end }}
