# Chart Migration Guide

This chart has moved to a new major-version values schema. The migration is intentionally breaking: legacy keys are not supported.

The main goals of the redesign are:

- split native `NetworkPolicy` from `CiliumNetworkPolicy`
- standardize bootstrap configuration under `bootstrap.identities.*`, `bootstrap.vulnerabilitySources.*`, `bootstrap.analyzers.*`, and `bootstrap.repositories[]`
- replace implicit auth env configuration with Keycloak-only `backend.auth` and `frontend.auth`
- centralize external domains under `global.ciliumNetworkPolicy.catalog.*`

## High-Level Changes

### Network policy model

Old shape:

- `*.networkPolicy` was used for both native and Cilium concerns
- domain-based egress was mixed into the same values surface

New shape:

- `*.networkPolicy` means native Kubernetes `NetworkPolicy`
- `*.ciliumNetworkPolicy` means `CiliumNetworkPolicy`
- `global.ciliumNetworkPolicy.catalog.*` is the shared source of external domains

### Bootstrap model

Old shape:

- identities and integrations were spread across top-level bootstrap keys
- integration keys mixed snake_case and camelCase

New shape:

- `bootstrap.identities.users`
- `bootstrap.identities.teams`
- `bootstrap.identities.oidcGroups`
- `bootstrap.vulnerabilitySources.googleOsv`
- `bootstrap.vulnerabilitySources.githubAdvisories`
- `bootstrap.vulnerabilitySources.nvd`
- `bootstrap.analyzers.trivy`
- `bootstrap.analyzers.sonatype`
- `bootstrap.repositories[]`

### Auth model

Old shape:

- backend and frontend auth was mostly driven through raw env values

New shape:

- `backend.auth` is the only backend auth block
- `frontend.auth` is the only frontend auth block
- both are Keycloak-only and derive the issuer URL from `baseUrl` and `realm`

## Common Key Migrations

### Bootstrap identities

| Old key | New key |
|---|---|
| `bootstrap.users` | `bootstrap.identities.users` |
| `bootstrap.teams` | `bootstrap.identities.teams` |
| `bootstrap.groups` | `bootstrap.identities.oidcGroups` |

### Bootstrap vulnerability sources and analyzers

| Old key | New key |
|---|---|
| `bootstrap.google.osv_enabled` | `bootstrap.vulnerabilitySources.googleOsv.enabled` |
| `bootstrap.github.advisoryMirroringTokenSecret` | `bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret` |
| `bootstrap.nvd.apiKeySecret` | `bootstrap.vulnerabilitySources.nvd.apiKeySecret` |
| `bootstrap.trivy.ignore_unfixed` | `bootstrap.analyzers.trivy.ignoreUnfixed` |
| `bootstrap.trivy.base_url` | `bootstrap.analyzers.trivy.baseUrl` |
| `bootstrap.trivy.apiTokenSecret` | `bootstrap.analyzers.trivy.apiTokenSecret` |
| `bootstrap.oss_index.username` | `bootstrap.analyzers.sonatype.username` |
| `bootstrap.oss_index.tokenSecret` | `bootstrap.analyzers.sonatype.tokenSecret` |

### Network policy

| Old key | New key |
|---|---|
| `global.egress.repositories` | `global.ciliumNetworkPolicy.catalog.packageRepositories` |
| `global.egress.vulnerabilityDatabases` | `global.ciliumNetworkPolicy.catalog.vulnerabilityFeeds` |
| `backend.networkPolicy.repositories` | `backend.ciliumNetworkPolicy.extraFqdns` |
| `backend.networkPolicy.vulnerabilityDatabases` | `backend.ciliumNetworkPolicy.extraVulnerabilityFeeds` |
| `trivy.networkPolicy.repositories` | `trivy.ciliumNetworkPolicy.extraFqdns` |

### Auth

| Old key | New key |
|---|---|
| `backend.env.ALPINE_OIDC_ENABLED` | `backend.auth.enabled` |
| `backend.env.ALPINE_OIDC_ISSUER` | `backend.auth.baseUrl` + `backend.auth.realm` |
| `backend.env.ALPINE_OIDC_CLIENT_ID` | `backend.auth.clientId` |
| `backend.env.ALPINE_OIDC_USERNAME_CLAIM` | `backend.auth.usernameClaim` |
| `backend.env.ALPINE_OIDC_USER_PROVISIONING` | `backend.auth.userProvisioning` |
| `frontend.env.API_BASE_URL` | `frontend.apiBaseUrl` |
| `frontend.env.OIDC_ISSUER` | `frontend.auth.baseUrl` + `frontend.auth.realm` |
| `frontend.env.OIDC_CLIENT_ID` | `frontend.auth.clientId` |

## Recommended Migration Process

1. Copy your current values file to a new migration branch.
2. Translate bootstrap identities, vulnerability sources, and analyzers first.
3. Move any external-domain configuration into `*.ciliumNetworkPolicy` and `global.ciliumNetworkPolicy.catalog.*`.
4. Convert backend and frontend auth to Keycloak-only `auth`.
5. Move bootstrap configuration into `bootstrap.vulnerabilitySources.*`, `bootstrap.analyzers.*`, and optionally `bootstrap.repositories[]`.
5. Render with `helm template` and verify:
   - expected ingress resources
   - expected native `NetworkPolicy`
   - expected `CiliumNetworkPolicy`
   - expected bootstrap env vars and mounted `bootstrap.yaml`
6. Compare against one of the CI profiles in [`ci/`](./ci/README.md) that is closest to your deployment.

## LLM Conversion Prompt

Use the following prompt with an LLM to convert an old values file into the new major-version schema.

```text
You are migrating a Helm values file for the `charts/dtrack` chart to the new major-version schema.

Your task:
1. Read the OLD values YAML.
2. Convert it to the NEW schema only.
3. Do not preserve deprecated keys.
4. Output valid YAML only.
5. Preserve user intent exactly where possible.
6. If a legacy field has no direct equivalent, add a YAML comment above the closest new field explaining the manual follow-up required.

Important schema rules:
- `*.networkPolicy` is only for native Kubernetes `NetworkPolicy`.
- `*.ciliumNetworkPolicy` is only for `CiliumNetworkPolicy`.
- Shared external domains live under `global.ciliumNetworkPolicy.catalog.*`.
- Bootstrap identities live under:
  - `bootstrap.identities.users`
  - `bootstrap.identities.teams`
  - `bootstrap.identities.oidcGroups`
- Bootstrap vulnerability sources and analyzers live under:
  - `bootstrap.vulnerabilitySources.googleOsv`
  - `bootstrap.vulnerabilitySources.githubAdvisories`
  - `bootstrap.vulnerabilitySources.nvd`
  - `bootstrap.analyzers.trivy`
  - `bootstrap.analyzers.sonatype`
  - `bootstrap.repositories[]`
- Backend auth is defined by `backend.auth` for Keycloak only.
- Frontend auth is defined by `frontend.auth` for Keycloak only.
- `frontend.env.API_BASE_URL` must become `frontend.apiBaseUrl`.
- Old global egress keys must move to:
  - `global.ciliumNetworkPolicy.catalog.packageRepositories`
  - `global.ciliumNetworkPolicy.catalog.vulnerabilityFeeds`

Key migrations:
- `bootstrap.users` -> `bootstrap.identities.users`
- `bootstrap.teams` -> `bootstrap.identities.teams`
- `bootstrap.groups` -> `bootstrap.identities.oidcGroups`
- `bootstrap.google.osv_enabled` -> `bootstrap.vulnerabilitySources.googleOsv.enabled`
- `bootstrap.github.advisoryMirroringTokenSecret` -> `bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret`
- `bootstrap.nvd.apiKeySecret` -> `bootstrap.vulnerabilitySources.nvd.apiKeySecret`
- `bootstrap.trivy.ignore_unfixed` -> `bootstrap.analyzers.trivy.ignoreUnfixed`
- `bootstrap.trivy.base_url` -> `bootstrap.analyzers.trivy.baseUrl`
- `bootstrap.trivy.apiTokenSecret` -> `bootstrap.analyzers.trivy.apiTokenSecret`
- `bootstrap.oss_index.username` -> `bootstrap.analyzers.sonatype.username`
- `bootstrap.oss_index.tokenSecret` -> `bootstrap.analyzers.sonatype.tokenSecret`
- `backend.env.ALPINE_OIDC_ENABLED` -> `backend.auth.enabled`
- `backend.env.ALPINE_OIDC_ISSUER` should be split into `backend.auth.baseUrl` and `backend.auth.realm`
- `backend.env.ALPINE_OIDC_CLIENT_ID` -> `backend.auth.clientId`
- `backend.env.ALPINE_OIDC_USERNAME_CLAIM` -> `backend.auth.usernameClaim`
- `backend.env.ALPINE_OIDC_USER_PROVISIONING` -> `backend.auth.userProvisioning`
- `frontend.env.OIDC_ISSUER` should be split into `frontend.auth.baseUrl` and `frontend.auth.realm`
- `frontend.env.OIDC_CLIENT_ID` -> `frontend.auth.clientId`
- `frontend.env.API_BASE_URL` -> `frontend.apiBaseUrl`
- `global.egress.repositories` -> `global.ciliumNetworkPolicy.catalog.packageRepositories`
- `global.egress.vulnerabilityDatabases` -> `global.ciliumNetworkPolicy.catalog.vulnerabilityFeeds`
- `backend.networkPolicy.repositories` -> `backend.ciliumNetworkPolicy.extraFqdns`
- `backend.networkPolicy.vulnerabilityDatabases` -> `backend.ciliumNetworkPolicy.extraVulnerabilityFeeds`
- `trivy.networkPolicy.repositories` -> `trivy.ciliumNetworkPolicy.extraFqdns`

Conversion rules:
- Keep all non-deprecated keys that are still valid.
- Preserve explicit values, including booleans, strings, lists, and maps.
- If an old issuer URL follows the Keycloak realm pattern, split it into `baseUrl` and `realm`.
- Do not output generic OIDC configuration, provider fields, or raw issuer URL fields in the new schema.
- Do not invent secrets, hosts, or URLs.
- Keep YAML comments minimal and only for unresolved cases.

Return only the migrated YAML.

OLD VALUES:
<paste old values file here>
```
