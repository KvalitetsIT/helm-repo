{{/*
Expand the name of the chart.
*/}}
{{- define "dependencytrack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}


{{- define "dependencytrack-backend.name" -}}
{{- .Chart.Name }}-backend
{{- end }}

{{- define "dependencytrack-frontend.name" -}}
{{- .Chart.Name }}-frontend
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this ().
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dependencytrack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dependencytrack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-backend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-frontend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-frontend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for backend
*/}}
{{- define "dependencytrack-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Selector labels for frontend
*/}}
{{- define "dependencytrack-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: frontend
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dependencytrack.backend.serviceAccountName" -}}
{{- if .Values.backend.serviceAccount.create }}
{{- default (include "dependencytrack-backend.name" .) .Values.backend.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.backend.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "dependencytrack.trivy.serviceAccountName" -}}
{{- if .Values.trivy.serviceAccount.create }}
{{- default (include "trivy.fullname" .) .Values.trivy.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.trivy.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dependencytrack.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.global.commonAnnotations }}
{{- $annotations = merge $annotations .Values.global.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "dependencytrack.hasCommonAnnotations" -}}
{{- if .Values.global.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Build complete image reference from repository and tag
Usage: imageRef $component (e.g., imageRef $values.backend.image)
*/}}
{{- define "imageRef" -}}
{{- $repo := .repository -}}
{{- $tag := .tag | default "latest" -}}
{{- printf "%s:%s" $repo $tag -}}
{{- end }}

{{/*
Get egress repositories for a component, merged with global
Usage: include "egressRepositories" (dict "component" .Values.backend "global" .Values.global)
*/}}
{{- define "egressRepositories" -}}
{{- $global := .global.ciliumNetworkPolicy.catalog.packageRepositories | default list -}}
{{- $component := .component.ciliumNetworkPolicy.extraFqdns | default list -}}
{{- concat $global $component | uniq | toYaml -}}
{{- end }}

{{/*
Get vulnerability databases for a component, merged with global
Usage: include "egressVulnDatabases" (dict "component" .Values.backend "global" .Values.global)
*/}}
{{- define "egressVulnDatabases" -}}
{{- $global := .global.ciliumNetworkPolicy.catalog.vulnerabilityFeeds | default list -}}
{{- $component := .component.ciliumNetworkPolicy.extraVulnerabilityFeeds | default list -}}
{{- concat $global $component | uniq | toYaml -}}
{{- end }}

{{/*
Get the backend API base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.backendApiUrl" -}}
{{- if .Values.bootstrap.baseUrl -}}
{{- .Values.bootstrap.baseUrl -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local:8080/api" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the frontend API base URL (for browser access)
*/}}
{{- define "dependencytrack.frontendApiUrl" -}}
{{- $frontendAuth := include "dependencytrack.frontend.authConfig" . | fromYaml -}}
{{- if $frontendAuth.apiBaseUrl -}}
{{- $frontendAuth.apiBaseUrl -}}
{{- else if and .Values.backend.ingress.enabled .Values.backend.ingress.host -}}
{{- if .Values.backend.ingress.tls -}}
{{- printf "https://%s" .Values.backend.ingress.host -}}
{{- else -}}
{{- printf "http://%s" .Values.backend.ingress.host -}}
{{- end -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the Trivy base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.trivyBaseUrl" -}}
{{- $bootstrap := include "dependencytrack.bootstrap.config" . | fromYaml -}}
{{- if $bootstrap.analyzers.trivy.baseUrl -}}
{{- $bootstrap.analyzers.trivy.baseUrl -}}
{{- else if .Values.trivy.enabled -}}
{{- $trivyServiceName := .Values.trivy.service.name | default (include "trivy.fullname" .) -}}
{{- printf "http://%s.%s.svc.cluster.local:4954" $trivyServiceName .Release.Namespace -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
Get the PostgreSQL host (FQDN)
*/}}
{{- define "dependencytrack.postgresqlHost" -}}
{{- if and .Values.backend.postgresql.host (ne .Values.backend.postgresql.host "") -}}
{{- .Values.backend.postgresql.host -}}
{{- else -}}
{{- $serviceName := .Values.backend.postgresql.serviceName | default "postgresql" -}}
{{- $namespace := .Values.backend.postgresql.namespace | default .Release.Namespace -}}
{{- printf "%s.%s.svc.cluster.local" $serviceName $namespace -}}
{{- end -}}
{{- end }}

{{- define "dependencytrack.bootstrap.config" -}}
{{- $users := .Values.bootstrap.identities.users | default list -}}
{{- $teams := .Values.bootstrap.identities.teams | default list -}}
{{- $oidcGroups := .Values.bootstrap.identities.oidcGroups | default list -}}
{{- $googleEnabled := .Values.bootstrap.vulnerabilitySources.googleOsv.enabled | default false -}}
{{- $githubSecret := .Values.bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret | default (dict "name" "" "key" "") -}}
{{- $githubEnabled := .Values.bootstrap.vulnerabilitySources.githubAdvisories.enabled | default false -}}
{{- $nvdSecret := .Values.bootstrap.vulnerabilitySources.nvd.apiKeySecret | default (dict "name" "" "key" "") -}}
{{- $nvdEnabled := .Values.bootstrap.vulnerabilitySources.nvd.enabled | default false -}}
{{- $trivySecret := .Values.bootstrap.analyzers.trivy.apiTokenSecret | default (dict "name" "" "key" "") -}}
{{- $trivyBaseUrl := .Values.bootstrap.analyzers.trivy.baseUrl | default "" -}}
{{- $trivyIgnoreUnfixed := .Values.bootstrap.analyzers.trivy.ignoreUnfixed | default true -}}
{{- $trivyEnabled := .Values.bootstrap.analyzers.trivy.enabled | default false -}}
{{- $sonatypeTokenSecret := .Values.bootstrap.analyzers.sonatype.tokenSecret | default (dict "name" "" "key" "") -}}
{{- $sonatypeUsername := .Values.bootstrap.analyzers.sonatype.username | default "" -}}
{{- $sonatypeEnabled := .Values.bootstrap.analyzers.sonatype.enabled | default false -}}
{{- $repositories := list -}}
{{- range $index, $repository := (.Values.bootstrap.repositories | default list) -}}
  {{- $repo := deepCopy $repository -}}
  {{- if and (hasKey $repository "passwordSecret") $repository.passwordSecret.name $repository.passwordSecret.key -}}
    {{- $_ := set $repo "passwordEnvVar" (printf "BOOTSTRAP_REPOSITORY_PASSWORD_%d" $index) -}}
  {{- end -}}
  {{- $repositories = append $repositories $repo -}}
{{- end -}}

{{- $frontendBaseUrl := .Values.bootstrap.frontendBaseUrl | default "" -}}
{{- if and (hasKey .Values.bootstrap "endpoints") (hasKey .Values.bootstrap.endpoints "frontend") (hasKey .Values.bootstrap.endpoints.frontend "url") -}}
  {{- $frontendBaseUrl = .Values.bootstrap.endpoints.frontend.url -}}
{{- end -}}

{{- toYaml (dict
  "users" $users
  "teams" $teams
  "oidcGroups" $oidcGroups
  "repositories" $repositories
  "frontendBaseUrl" $frontendBaseUrl
  "vulnerabilitySources" (dict
    "googleOsv" (dict "enabled" $googleEnabled)
    "githubAdvisories" (dict "enabled" $githubEnabled "tokenSecret" $githubSecret)
    "nvd" (dict "enabled" $nvdEnabled "apiKeySecret" $nvdSecret)
  )
  "analyzers" (dict
    "trivy" (dict "enabled" $trivyEnabled "ignoreUnfixed" $trivyIgnoreUnfixed "baseUrl" $trivyBaseUrl "apiTokenSecret" $trivySecret)
    "sonatype" (dict "enabled" $sonatypeEnabled "username" $sonatypeUsername "tokenSecret" $sonatypeTokenSecret)
  )
) -}}
{{- end }}

{{- define "dependencytrack.backend.authConfig" -}}
{{- $auth := .Values.backend.auth | default dict -}}
{{- $enabled := $auth.enabled | default false -}}
{{- $clientID := $auth.clientId | default "" -}}
{{- $usernameClaim := $auth.usernameClaim | default "email" -}}
{{- $userProvisioning := $auth.userProvisioning | default true -}}
{{- $issuer := "" -}}
{{- if and $auth.baseUrl $auth.realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $auth.baseUrl) $auth.realm -}}
{{- end -}}
{{- toYaml (dict "enabled" $enabled "issuerUrl" $issuer "clientId" $clientID "usernameClaim" $usernameClaim "userProvisioning" $userProvisioning) -}}
{{- end }}

{{- define "dependencytrack.frontend.authConfig" -}}
{{- $auth := .Values.frontend.auth | default dict -}}
{{- $enabled := $auth.enabled | default false -}}
{{- $clientID := $auth.clientId | default "" -}}
{{- $apiBaseUrl := .Values.frontend.apiBaseUrl | default "" -}}
{{- $issuer := "" -}}
{{- if and $auth.baseUrl $auth.realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $auth.baseUrl) $auth.realm -}}
{{- end -}}
{{- toYaml (dict "enabled" $enabled "issuerUrl" $issuer "clientId" $clientID "apiBaseUrl" $apiBaseUrl) -}}
{{- end }}

{{- define "dependencytrack.cilium.fqdns" -}}
{{- $component := .component -}}
{{- $global := .global -}}
{{- $bootstrap := .bootstrap -}}
{{- $backendOidc := .backendOidc | default dict -}}
{{- $frontendOidc := .frontendOidc | default dict -}}
{{- $fqdns := list -}}
{{- if .includeRepositories -}}
  {{- $fqdns = concat $fqdns (include "egressRepositories" (dict "component" $component "global" $global) | fromYamlArray) -}}
{{- end -}}
{{- if .includeVulnerabilityFeeds -}}
  {{- $fqdns = concat $fqdns (include "egressVulnDatabases" (dict "component" $component "global" $global) | fromYamlArray) -}}
{{- end -}}
{{- if .includeGithubApi -}}
  {{- $fqdns = concat $fqdns ($global.ciliumNetworkPolicy.catalog.githubApi | default (list "api.github.com")) -}}
{{- end -}}
{{- if .includeGoogleOsv -}}
  {{- $fqdns = concat $fqdns ($global.ciliumNetworkPolicy.catalog.googleOsv | default (list "osv-vulnerabilities.storage.googleapis.com")) -}}
{{- end -}}
{{- if .includeNvdApi -}}
  {{- $fqdns = concat $fqdns ($global.ciliumNetworkPolicy.catalog.nvdApi | default (list "nvd.nist.gov")) -}}
{{- end -}}
{{- if .includeSonatypeApi -}}
  {{- $fqdns = concat $fqdns ($global.ciliumNetworkPolicy.catalog.sonatypeApi | default (list "ossindex.sonatype.org")) -}}
{{- end -}}
{{- if .includeBackendOidcIssuer -}}
  {{- $host := regexFind "https?://([^/]+)" ($backendOidc.issuerUrl | default "") -}}
  {{- if $host -}}{{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}{{- end -}}
{{- end -}}
{{- if .includeFrontendOidcIssuer -}}
  {{- $host := regexFind "https?://([^/]+)" ($frontendOidc.issuerUrl | default "") -}}
  {{- if $host -}}{{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}{{- end -}}
{{- end -}}
{{- if .includeExternalTrivy -}}
  {{- $host := regexFind "https?://([^/]+)" ($bootstrap.analyzers.trivy.baseUrl | default "") -}}
  {{- if $host -}}{{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}{{- end -}}
{{- end -}}
{{- $extra := $component.ciliumNetworkPolicy.extraFqdns | default list -}}
{{- toYaml (concat $fqdns $extra | uniq) -}}
{{- end }}
