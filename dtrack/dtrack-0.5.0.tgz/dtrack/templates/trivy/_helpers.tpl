{{- /*
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2019-2025 Aqua Security, Inc.
# Licensed under the Apache License, Version 2.0 (the "License");
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Modifications by: KvalitetsIT (2025)
# Modifications made:
# - Inlined and adapted for dtrack (2025-11-19).
*/}}
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "trivy.name" -}}
{{- if .Values.trivy.nameOverride -}}
{{- .Values.trivy.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-trivy" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "trivy.fullname" -}}
{{- if .Values.trivy.fullnameOverride -}}
{{- .Values.trivy.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- include "trivy.name" . -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "trivy.chart" -}}
{{- printf "%s-%s" (include "trivy.name" .) .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "trivy.labels" -}}
app.kubernetes.io/name: {{ include "trivy.name" . }}
helm.sh/chart: {{ include "trivy.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Return the proper imageRef as used by the container template spec.
*/}}
{{- define "trivy.imageRef" -}}
{{- include "imageRef" (dict
	"registry" (.Values.trivy.image.registry | default "")
	"repository" (.Values.trivy.image.repository | default "trivy")
	"tag" (.Values.trivy.image.tag | default .Chart.AppVersion | toString)
	"digest" (.Values.trivy.image.digest | default "")
) -}}
{{- end -}}
