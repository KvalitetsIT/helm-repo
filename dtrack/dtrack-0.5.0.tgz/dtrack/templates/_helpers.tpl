{{/*
Expand the name of the chart.
*/}}
{{- define "dependencytrack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}


{{- define "dependencytrack-backend.name" -}}
{{- .Chart.Name }}-backend
{{- end }}

{{- define "dependencytrack-frontend.name" -}}
{{- .Chart.Name }}-frontend
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this ().
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dependencytrack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dependencytrack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-backend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-frontend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-frontend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for backend
*/}}
{{- define "dependencytrack-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Selector labels for frontend
*/}}
{{- define "dependencytrack-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: frontend
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dependencytrack.backend.serviceAccountName" -}}
{{- if .Values.backend.serviceAccount.create }}
{{- default (include "dependencytrack-backend.name" .) .Values.backend.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.backend.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "dependencytrack.trivy.serviceAccountName" -}}
{{- if .Values.trivy.serviceAccount.create }}
{{- default (include "trivy.fullname" .) .Values.trivy.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.trivy.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dependencytrack.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.global.commonAnnotations }}
{{- $annotations = merge $annotations .Values.global.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "dependencytrack.hasCommonAnnotations" -}}
{{- if .Values.global.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Build complete image reference from the configured image fields.
Usage: imageRef $component (e.g., imageRef $values.backend.image)
*/}}
{{- define "imageRef" -}}
{{- $registry := .registry | default "" -}}
{{- $repository := .repository -}}
{{- $digest := .digest | default "" -}}
{{- $tag := .tag | default "latest" -}}
{{- $image := $repository -}}
{{- if and $registry $repository -}}
  {{- $image = printf "%s/%s" $registry $repository -}}
{{- end -}}
{{- if $digest -}}
{{- printf "%s:%s@%s" $image $tag $digest -}}
{{- else -}}
{{- printf "%s:%s" $image $tag -}}
{{- end -}}
{{- end }}

{{/*
Get egress package repository FQDNs from global catalog
Usage: include "egressRepositories" (dict "global" .Values.global)
*/}}
{{- define "egressRepositories" -}}
{{- .global.packageRepositories | default list | uniq | toYaml -}}
{{- end }}


{{/*
Get the backend API base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.backendApiUrl" -}}
{{- if .Values.bootstrap.baseUrl -}}
{{- .Values.bootstrap.baseUrl -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local:8080/api" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the frontend API base URL (for browser access)
*/}}
{{- define "dependencytrack.frontendApiUrl" -}}
{{- $frontendAuth := include "dependencytrack.frontend.authConfig" . | fromYaml -}}
{{- if $frontendAuth.apiBaseUrl -}}
{{- $frontendAuth.apiBaseUrl -}}
{{- else if and .Values.backend.ingress.enabled .Values.backend.ingress.host -}}
{{- if .Values.backend.ingress.tls -}}
{{- printf "https://%s" .Values.backend.ingress.host -}}
{{- else -}}
{{- printf "http://%s" .Values.backend.ingress.host -}}
{{- end -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the Trivy base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.trivyBaseUrl" -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- if dig "analyzers" "trivy" "baseUrl" "" $b -}}
{{- dig "analyzers" "trivy" "baseUrl" "" $b -}}
{{- else if .Values.trivy.enabled -}}
{{- $trivyServiceName := .Values.trivy.service.name | default (include "trivy.fullname" .) -}}
{{- printf "http://%s.%s.svc.cluster.local:4954" $trivyServiceName .Release.Namespace -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
Get the PostgreSQL host (FQDN)
*/}}
{{- define "dependencytrack.postgresqlHost" -}}
{{- if and .Values.backend.postgresql.host (ne .Values.backend.postgresql.host "") -}}
{{- .Values.backend.postgresql.host -}}
{{- else -}}
{{- $serviceName := .Values.backend.postgresql.serviceName | default "postgresql" -}}
{{- $namespace := .Values.backend.postgresql.namespace | default .Release.Namespace -}}
{{- printf "%s.%s.svc.cluster.local" $serviceName $namespace -}}
{{- end -}}
{{- end }}


{{- define "dependencytrack.backend.authConfig" -}}
{{- $g := .Values.global.auth | default dict -}}
{{- $baseUrl := $g.baseUrl | default "" -}}
{{- $realm := $g.realm | default "" -}}
{{- $issuer := "" -}}
{{- if and $baseUrl $realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $baseUrl) $realm -}}
{{- end -}}
enabled: {{ $g.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $g.clientId | default "" | quote }}
usernameClaim: {{ $g.usernameClaim | default "preferred_username" | quote }}
userProvisioning: {{ $g.userProvisioning | default true }}
teamsClaim: {{ $g.teamsClaim | default "groups" | quote }}
teamSynchronization: {{ $g.teamSynchronization | default true }}
{{- end }}

{{- define "dependencytrack.frontend.authConfig" -}}
{{- $g := .Values.global.auth | default dict -}}
{{- $baseUrl := $g.baseUrl | default "" -}}
{{- $realm := $g.realm | default "" -}}
{{- $issuer := "" -}}
{{- if and $baseUrl $realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $baseUrl) $realm -}}
{{- end -}}
enabled: {{ $g.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $g.clientId | default "" | quote }}
apiBaseUrl: {{ .Values.frontend.apiBaseUrl | default "" | quote }}
{{- end }}

{{- define "dependencytrack.backend.fqdns" -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- $auth := include "dependencytrack.backend.authConfig" . | fromYaml -}}
{{- $catalog := .Values.global -}}
{{- $fqdns := include "egressRepositories" (dict "global" .Values.global) | fromYamlArray -}}
{{- if dig "vulnerabilitySources" "githubAdvisories" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.githubApi | default list) -}}
{{- end -}}
{{- if dig "vulnerabilitySources" "googleOsv" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.googleOsv | default list) -}}
{{- end -}}
{{- if dig "vulnerabilitySources" "nvd" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.nvdApi | default list) -}}
{{- end -}}
{{- if dig "analyzers" "sonatype" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.sonatypeApi | default list) -}}
{{- end -}}
{{- if $auth.enabled -}}
  {{- $host := regexFind "https?://([^/]+)" ($auth.issuerUrl | default "") -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- $trivyUrl := include "dependencytrack.trivyBaseUrl" . -}}
{{- if and (dig "analyzers" "trivy" "enabled" false $b) $trivyUrl (not (contains ".cluster.local" $trivyUrl)) -}}
  {{- $host := regexFind "https?://([^/]+)" $trivyUrl -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- $fqdns = concat $fqdns (.Values.global.vulnerabilityFeeds | default list) -}}
{{- $fqdns | uniq | toYaml -}}
{{- end }}

{{- define "dependencytrack.trivy.fqdns" -}}
{{- $fqdns := .Values.global.ghcrRepositories | default list -}}
{{- if ne .Values.trivy.config.githubTokenSecret.name "" -}}
  {{- $fqdns = concat $fqdns (.Values.global.githubApi | default list) -}}
{{- end -}}
{{- $fqdns | uniq | toYaml -}}
{{- end }}
