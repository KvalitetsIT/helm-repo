{{/*
Expand the name of the chart.
*/}}
{{- define "dependencytrack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}


{{- define "dependencytrack-backend.name" -}}
{{- .Chart.Name }}-backend
{{- end }}

{{- define "dependencytrack-frontend.name" -}}
{{- .Chart.Name }}-frontend
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this ().
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dependencytrack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dependencytrack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-backend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-frontend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-frontend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for backend
*/}}
{{- define "dependencytrack-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Selector labels for frontend
*/}}
{{- define "dependencytrack-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: frontend
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dependencytrack.backend.serviceAccountName" -}}
{{- if .Values.backend.serviceAccount.create }}
{{- default (include "dependencytrack-backend.name" .) .Values.backend.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.backend.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "dependencytrack.trivy.serviceAccountName" -}}
{{- if .Values.trivy.serviceAccount.create }}
{{- default (include "trivy.fullname" .) .Values.trivy.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.trivy.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dependencytrack.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.global.commonAnnotations }}
{{- $annotations = merge $annotations .Values.global.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "dependencytrack.hasCommonAnnotations" -}}
{{- if .Values.global.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Build complete image reference from repository and tag
Usage: imageRef $component (e.g., imageRef $values.backend.image)
*/}}
{{- define "imageRef" -}}
{{- $repo := .repository -}}
{{- $tag := .tag | default "latest" -}}
{{- printf "%s:%s" $repo $tag -}}
{{- end }}

{{/*
Get egress package repository FQDNs from global catalog
Usage: include "egressRepositories" (dict "global" .Values.global)
*/}}
{{- define "egressRepositories" -}}
{{- .global.packageRepositories | default list | uniq | toYaml -}}
{{- end }}

{{/*
Get vulnerability database FQDNs from global catalog
Usage: include "egressVulnDatabases" (dict "global" .Values.global)
*/}}
{{- define "egressVulnDatabases" -}}
{{- .global.vulnerabilityFeeds | default list | uniq | toYaml -}}
{{- end }}

{{/*
Get the backend API base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.backendApiUrl" -}}
{{- if .Values.bootstrap.baseUrl -}}
{{- .Values.bootstrap.baseUrl -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local:8080/api" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the frontend API base URL (for browser access)
*/}}
{{- define "dependencytrack.frontendApiUrl" -}}
{{- $frontendAuth := include "dependencytrack.frontend.authConfig" . | fromYaml -}}
{{- if $frontendAuth.apiBaseUrl -}}
{{- $frontendAuth.apiBaseUrl -}}
{{- else if and .Values.backend.ingress.enabled .Values.backend.ingress.host -}}
{{- if .Values.backend.ingress.tls -}}
{{- printf "https://%s" .Values.backend.ingress.host -}}
{{- else -}}
{{- printf "http://%s" .Values.backend.ingress.host -}}
{{- end -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Get the Trivy base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.trivyBaseUrl" -}}
{{- $bootstrap := include "dependencytrack.bootstrap.config" . | fromYaml -}}
{{- if $bootstrap.analyzers.trivy.baseUrl -}}
{{- $bootstrap.analyzers.trivy.baseUrl -}}
{{- else if .Values.trivy.enabled -}}
{{- $trivyServiceName := .Values.trivy.service.name | default (include "trivy.fullname" .) -}}
{{- printf "http://%s.%s.svc.cluster.local:4954" $trivyServiceName .Release.Namespace -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
Get the PostgreSQL host (FQDN)
*/}}
{{- define "dependencytrack.postgresqlHost" -}}
{{- if and .Values.backend.postgresql.host (ne .Values.backend.postgresql.host "") -}}
{{- .Values.backend.postgresql.host -}}
{{- else -}}
{{- $serviceName := .Values.backend.postgresql.serviceName | default "postgresql" -}}
{{- $namespace := .Values.backend.postgresql.namespace | default .Release.Namespace -}}
{{- printf "%s.%s.svc.cluster.local" $serviceName $namespace -}}
{{- end -}}
{{- end }}

{{- define "dependencytrack.bootstrap.config" -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- $repositories := list -}}
{{- range $i, $repo := ($b.repositories | default list) -}}
  {{- $r := deepCopy $repo -}}
  {{- if and (hasKey $repo "passwordSecret") $repo.passwordSecret.name $repo.passwordSecret.key -}}
    {{- $_ := set $r "passwordEnvVar" (printf "BOOTSTRAP_REPOSITORY_PASSWORD_%d" $i) -}}
  {{- end -}}
  {{- $repositories = append $repositories $r -}}
{{- end -}}
{{- $frontendBaseUrl := $b.frontendBaseUrl | default "" -}}
{{- if and (hasKey $b "endpoints") (hasKey $b.endpoints "frontend") (hasKey $b.endpoints.frontend "url") -}}
  {{- $frontendBaseUrl = $b.endpoints.frontend.url -}}
{{- end -}}
frontendBaseUrl: {{ $frontendBaseUrl | quote }}
users:
{{- $b.identities.users | default list | toYaml | nindent 2 }}
teams:
{{- $b.identities.teams | default list | toYaml | nindent 2 }}
oidcGroups:
{{- $b.identities.oidcGroups | default list | toYaml | nindent 2 }}
repositories:
{{- $repositories | toYaml | nindent 2 }}
vulnerabilitySources:
  googleOsv:
    enabled: {{ $b.vulnerabilitySources.googleOsv.enabled | default false }}
  githubAdvisories:
    enabled: {{ $b.vulnerabilitySources.githubAdvisories.enabled | default false }}
    tokenSecret:
{{- $b.vulnerabilitySources.githubAdvisories.tokenSecret | default (dict "name" "" "key" "") | toYaml | nindent 6 }}
  nvd:
    enabled: {{ $b.vulnerabilitySources.nvd.enabled | default false }}
    apiKeySecret:
{{- $b.vulnerabilitySources.nvd.apiKeySecret | default (dict "name" "" "key" "") | toYaml | nindent 6 }}
analyzers:
  trivy:
    enabled: {{ $b.analyzers.trivy.enabled | default false }}
    ignoreUnfixed: {{ $b.analyzers.trivy.ignoreUnfixed | default true }}
    baseUrl: {{ $b.analyzers.trivy.baseUrl | default "" | quote }}
    apiTokenSecret:
{{- $b.analyzers.trivy.apiTokenSecret | default (dict "name" "" "key" "") | toYaml | nindent 6 }}
  sonatype:
    enabled: {{ $b.analyzers.sonatype.enabled | default false }}
    username: {{ $b.analyzers.sonatype.username | default "" | quote }}
    tokenSecret:
{{- $b.analyzers.sonatype.tokenSecret | default (dict "name" "" "key" "") | toYaml | nindent 6 }}
{{- end }}

{{- define "dependencytrack.backend.authConfig" -}}
{{- $auth := .Values.backend.auth | default dict -}}
{{- $issuer := "" -}}
{{- if and $auth.baseUrl $auth.realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $auth.baseUrl) $auth.realm -}}
{{- end -}}
enabled: {{ $auth.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $auth.clientId | default "" | quote }}
usernameClaim: {{ $auth.usernameClaim | default "preferred_username" | quote }}
userProvisioning: {{ $auth.userProvisioning | default true }}
teamsClaim: {{ $auth.teamsClaim | default "groups" | quote }}
teamSynchronization: {{ $auth.teamSynchronization | default true }}
{{- end }}

{{- define "dependencytrack.frontend.authConfig" -}}
{{- $auth := .Values.frontend.auth | default dict -}}
{{- $issuer := "" -}}
{{- if and $auth.baseUrl $auth.realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $auth.baseUrl) $auth.realm -}}
{{- end -}}
enabled: {{ $auth.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $auth.clientId | default "" | quote }}
apiBaseUrl: {{ .Values.frontend.apiBaseUrl | default "" | quote }}
{{- end }}

{{- define "dependencytrack.backend.fqdns" -}}
{{- $bootstrap := include "dependencytrack.bootstrap.config" . | fromYaml -}}
{{- $auth := include "dependencytrack.backend.authConfig" . | fromYaml -}}
{{- $catalog := .Values.global -}}
{{- $fqdns := include "egressRepositories" (dict "global" .Values.global) | fromYamlArray -}}
{{- if $bootstrap.vulnerabilitySources.githubAdvisories.enabled -}}
  {{- $fqdns = concat $fqdns ($catalog.githubApi | default list) -}}
{{- end -}}
{{- if $bootstrap.vulnerabilitySources.googleOsv.enabled -}}
  {{- $fqdns = concat $fqdns ($catalog.googleOsv | default list) -}}
{{- end -}}
{{- if $bootstrap.vulnerabilitySources.nvd.enabled -}}
  {{- $fqdns = concat $fqdns ($catalog.nvdApi | default list) -}}
{{- end -}}
{{- if $bootstrap.analyzers.sonatype.enabled -}}
  {{- $fqdns = concat $fqdns ($catalog.sonatypeApi | default list) -}}
{{- end -}}
{{- if $auth.enabled -}}
  {{- $host := regexFind "https?://([^/]+)" ($auth.issuerUrl | default "") -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- if and $bootstrap.analyzers.trivy.enabled (not .Values.trivy.enabled) $bootstrap.analyzers.trivy.baseUrl -}}
  {{- $host := regexFind "https?://([^/]+)" $bootstrap.analyzers.trivy.baseUrl -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- $fqdns | uniq | toYaml -}}
{{- end }}

{{- define "dependencytrack.trivy.fqdns" -}}
{{- $fqdns := include "egressRepositories" (dict "global" .Values.global) | fromYamlArray -}}
{{- $fqdns = concat $fqdns (include "egressVulnDatabases" (dict "global" .Values.global) | fromYamlArray) -}}
{{- if ne .Values.trivy.config.githubTokenSecret.name "" -}}
  {{- $fqdns = concat $fqdns (.Values.global.githubApi | default list) -}}
{{- end -}}
{{- $fqdns | uniq | toYaml -}}
{{- end }}
