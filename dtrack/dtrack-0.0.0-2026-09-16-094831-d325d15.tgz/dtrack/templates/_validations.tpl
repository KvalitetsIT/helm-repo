{{- define "dependencytrack.validateBackendReplicas" -}}
  {{- $backendReplicas := int .Values.backend.replicas -}}
  {{- $frontendReplicas := int .Values.frontend.replicas -}}
  {{- $offline := and (eq $backendReplicas 0) (eq $frontendReplicas 0) -}}
  {{- if and (not $offline) (lt $backendReplicas 1) -}}
    {{- fail "backend.replicas must be greater than zero, or backend.replicas and frontend.replicas must both be 0" -}}
  {{- end -}}
{{- end -}}

{{- define "dependencytrack.validateBackendVersion" -}}
{{- $backendTag := .Values.backend.image.tag | default "" | toString -}}
{{- $frontendTag := .Values.frontend.image.tag | default "" | toString -}}
{{- if hasPrefix "4." $backendTag -}}
  {{- fail (printf "backend.image.tag %q selects Dependency-Track 4.x, which this chart no longer supports. Pin pre-migration v4 installs to chart <= 0.7.x and follow MIGRATION.md to cut over to v5." $backendTag) -}}
{{- end -}}
{{- if hasPrefix "4." $frontendTag -}}
  {{- fail (printf "frontend.image.tag %q selects Dependency-Track 4.x, which this chart no longer supports. Pin pre-migration v4 installs to chart <= 0.7.x and follow MIGRATION.md to cut over to v5." $frontendTag) -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateSecretManagement" -}}
{{- $_ := include "dependencytrack.backend.kekMode" . -}}
{{- if not (.Values.backend.secretManagement.kek.existingSecret.name | default "" | trim) -}}
  {{- fail "backend.secretManagement.kek.existingSecret.name is required: the chart never generates the key-encryption key. Provision it in a Secret (config mode: `openssl rand -base64 32` stored under key `kek`; keyset mode: a Tink AES256_GCM keyset under key `kek-keyset.json`) and reference it here." -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateFileStorage" -}}
  {{- $replicas := int .Values.backend.replicas -}}
  {{- $provider := .Values.backend.fileStorage.provider -}}
  {{- if gt $replicas 0 -}}
  {{- if not (has $provider (list "local" "s3")) -}}
    {{- fail "backend.fileStorage.provider must be local or s3" -}}
  {{- end -}}
  {{- if eq $provider "local" -}}
    {{- $persistence := .Values.backend.fileStorage.local.persistence -}}
    {{- if and $persistence.create $persistence.existingClaim -}}
      {{- fail "backend.fileStorage.local.persistence cannot create a PVC and use an existingClaim at the same time" -}}
    {{- end -}}
    {{- if and (not $persistence.create) (not $persistence.existingClaim) -}}
      {{- fail "local file storage requires create=true or an existingClaim" -}}
    {{- end -}}
    {{- if and (gt $replicas 1) (not (has "ReadWriteMany" $persistence.accessModes)) -}}
      {{- fail "multiple backend replicas require local storage with ReadWriteMany, or the s3 provider" -}}
    {{- end -}}
  {{- end -}}
  {{- if eq $provider "s3" -}}
    {{- if not .Values.backend.fileStorage.s3.endpoint -}}
      {{- fail "backend.fileStorage.s3.endpoint is required" -}}
    {{- end -}}
    {{- if not .Values.backend.fileStorage.s3.bucket -}}
      {{- fail "backend.fileStorage.s3.bucket is required" -}}
    {{- end -}}
  {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "dependencytrack.validateDatabase" -}}
{{- if not (.Values.backend.database.serviceName | default "" | trim) -}}
  {{- fail "backend.database.serviceName is required and must point at an existing PostgreSQL Service" -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateCors" -}}
{{- $cors := .Values.backend.cors -}}
{{- if and $cors.enabled $cors.allowCredentials (eq ($cors.allowOrigin | default "" | trim) "*") -}}
  {{- fail "backend.cors.allowOrigin cannot be \"*\" while backend.cors.allowCredentials is true: Dependency-Track always sends Access-Control-Allow-Credentials, and browsers reject that combined with a wildcard origin. Set an explicit origin, or leave allowOrigin empty to derive it from the frontend hostname." -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateWaitForBackend" -}}
{{- $wfb := .Values.global.waitForBackend | default dict -}}
{{- if not (kindIs "map" $wfb.image) -}}
  {{- fail "global.waitForBackend.image must be an image object with registry/repository/tag/digest, not a string" -}}
{{- end -}}
{{- if not ($wfb.image.repository | default "" | trim) -}}
  {{- fail "global.waitForBackend.image.repository is required" -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.validateEnvList" -}}
{{- $component := .component -}}
{{- $reserved := .reserved | default list -}}
{{- if and .values.env (not (kindIs "slice" .values.env)) -}}
  {{- fail (printf "%s.env must be a list of EnvVar objects. Convert map-style env to entries like: - name: FOO; value: bar" $component) -}}
{{- end -}}
{{- if and .values.extraEnvs (not (kindIs "slice" .values.extraEnvs)) -}}
  {{- fail (printf "%s.extraEnvs must be a list of EnvVar objects" $component) -}}
{{- end -}}
{{- if and .values.envFrom (not (kindIs "slice" .values.envFrom)) -}}
  {{- fail (printf "%s.envFrom must be a list of EnvFromSource objects" $component) -}}
{{- end -}}
{{- if and .values.extraEnvFrom (not (kindIs "slice" .values.extraEnvFrom)) -}}
  {{- fail (printf "%s.extraEnvFrom must be a list of EnvFromSource objects" $component) -}}
{{- end -}}
{{- $seen := list -}}
{{- range concat (.values.env | default list) (.values.extraEnvs | default list) -}}
  {{- if not .name -}}
    {{- fail (printf "%s.env/extraEnvs entries must include name" $component) -}}
  {{- end -}}
  {{- if hasPrefix "ALPINE_" .name -}}
    {{- fail (printf "%s env variable %q uses the removed Dependency-Track 4.x ALPINE_ prefix; use the DT_* equivalent (e.g. ALPINE_METRICS_ENABLED -> DT_METRICS_ENABLED)" $component .name) -}}
  {{- end -}}
  {{- if eq .name "TELEMETRY_SUBMISSION_ENABLED_DEFAULT" -}}
    {{- fail (printf "%s env variable TELEMETRY_SUBMISSION_ENABLED_DEFAULT is a Dependency-Track 4.x name; use DT_TELEMETRY_SUBMISSION_DEFAULT_ENABLED" $component) -}}
  {{- end -}}
  {{- if eq .name "LOGGING_CONFIG_PATH" -}}
    {{- fail (printf "%s env variable LOGGING_CONFIG_PATH is a Dependency-Track 4.x name; use EXTRA_JAVA_OPTIONS: -Dlogback.configurationFile=<path>" $component) -}}
  {{- end -}}
  {{- if has .name $seen -}}
    {{- fail (printf "%s env contains duplicate variable %q" $component .name) -}}
  {{- end -}}
  {{- if has .name $reserved -}}
    {{- fail (printf "%s env variable %q is chart-managed and cannot be overridden" $component .name) -}}
  {{- end -}}
  {{- $seen = append $seen .name -}}
{{- end -}}
{{- end -}}

{{- define "dependencytrack.backend.reservedEnv" -}}
JAVA_TOOL_OPTIONS
LOGGING_LEVEL
DT_DATA_DIRECTORY
DT_MANAGEMENT_PORT
DT_SECRET_MANAGEMENT_PROVIDER
DT_SECRET_MANAGEMENT_DATABASE_KEK
DT_SECRET_MANAGEMENT_DATABASE_KEK_KEYSET_PATH
DT_FILE_STORAGE_PROVIDER
DT_FILE_STORAGE_LOCAL_DIRECTORY
DT_FILE_STORAGE_S3_ENDPOINT
DT_FILE_STORAGE_S3_BUCKET
DT_FILE_STORAGE_S3_REGION
DT_FILE_STORAGE_S3_ACCESS_KEY
DT_FILE_STORAGE_S3_SECRET_KEY
DT_OIDC_ENABLED
DT_OIDC_ISSUER
DT_OIDC_CLIENT_ID
DT_OIDC_USERNAME_CLAIM
DT_OIDC_USER_PROVISIONING
DT_OIDC_TEAMS_CLAIM
DT_OIDC_TEAM_SYNCHRONIZATION
DT_CORS_ENABLED
DT_CORS_ALLOWED_ORIGINS
DT_CORS_ALLOWED_METHODS
DT_CORS_ALLOWED_HEADERS
DT_CORS_EXPOSED_HEADERS
DT_CORS_ALLOW_CREDENTIALS
DT_CORS_MAX_AGE
DT_DATASOURCE_URL
DT_DATASOURCE_PASSWORD
DT_DATASOURCE_USERNAME
DT_DATASOURCE_POOL_MAX_SIZE
DT_DATASOURCE_POOL_MIN_IDLE
DT_DATASOURCE_POOL_IDLE_TIMEOUT
DT_DATASOURCE_POOL_MAX_LIFETIME
DT_TASK_SCHEDULER_THREADS
{{- end -}}

{{- define "dependencytrack.validateEnvs" -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "backend" "values" .Values.backend "reserved" (include "dependencytrack.backend.reservedEnv" . | trim | splitList "\n")) -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "frontend" "values" .Values.frontend "reserved" (list "API_BASE_URL" "OIDC_ISSUER" "OIDC_CLIENT_ID")) -}}
{{- include "dependencytrack.validateEnvList" (dict "component" "trivy" "values" .Values.trivy "reserved" (list "TRIVY_DEBUG" "TRIVY_SKIP_DB_UPDATE" "TRIVY_DB_REPOSITORY" "TRIVY_CACHE_DIR" "TRIVY_CACHE_BACKEND" "TRIVY_CACHE_TTL" "TRIVY_REDIS_TLS" "HTTP_PROXY" "HTTPS_PROXY" "NO_PROXY" "TRIVY_USERNAME" "TRIVY_PASSWORD" "TRIVY_TOKEN" "GITHUB_TOKEN")) -}}
{{- end -}}

{{- define "dependencytrack.validate" -}}
{{- include "dependencytrack.validateBackendVersion" . -}}
{{- include "dependencytrack.validateSecretManagement" . -}}
{{- include "dependencytrack.validateBackendReplicas" . -}}
{{- include "dependencytrack.validateDatabase" . -}}
{{- include "dependencytrack.validateCors" . -}}
{{- include "dependencytrack.validateFileStorage" . -}}
{{- include "dependencytrack.validateWaitForBackend" . -}}
{{- include "dependencytrack.validateEnvs" . -}}
{{- end -}}
