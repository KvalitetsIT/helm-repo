{{/*
Expand the chart name used in labels. nameOverride intentionally follows kitapp-style semantics.
*/}}
{{- define "dependencytrack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "dependencytrack.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end }}

{{- define "dependencytrack-backend.name" -}}
{{- printf "%s-backend" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{- define "dependencytrack-frontend.name" -}}
{{- printf "%s-frontend" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dependencytrack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-backend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dependencytrack-frontend.labels" -}}
helm.sh/chart: {{ include "dependencytrack.chart" . }}
{{ include "dependencytrack-frontend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for backend
*/}}
{{- define "dependencytrack-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Selector labels for frontend
*/}}
{{- define "dependencytrack-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dependencytrack-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: frontend
{{- end }}

{{/*
Create the name of the service account to use. Empty means do not set serviceAccountName.
*/}}
{{- define "dependencytrack.backend.serviceAccountName" -}}
{{- if .Values.backend.serviceAccount.create -}}
{{- default (include "dependencytrack-backend.name" .) .Values.backend.serviceAccount.name -}}
{{- else if .Values.backend.serviceAccount.name -}}
{{- .Values.backend.serviceAccount.name -}}
{{- end -}}
{{- end }}

{{- define "dependencytrack.trivy.serviceAccountName" -}}
{{- if .Values.trivy.serviceAccount.create -}}
{{- default (include "trivy.fullname" .) .Values.trivy.serviceAccount.name -}}
{{- else if .Values.trivy.serviceAccount.name -}}
{{- .Values.trivy.serviceAccount.name -}}
{{- end -}}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dependencytrack.commonAnnotations" -}}
{{- $annotations := dict -}}
{{- if .Values.global.commonAnnotations }}
{{- $annotations = merge $annotations .Values.global.commonAnnotations -}}
{{- end }}
{{- with $annotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Check if common annotations should be rendered
*/}}
{{- define "dependencytrack.hasCommonAnnotations" -}}
{{- if .Values.global.commonAnnotations -}}
true
{{- end -}}
{{- end }}

{{/*
Merge common annotations with component annotations.
Usage: include "dependencytrack.annotations" (dict "root" . "annotations" .Values.backend.annotations)
*/}}
{{- define "dependencytrack.annotations" -}}
{{- $annotations := dict -}}
{{- if .root.Values.global.commonAnnotations -}}
{{- $annotations = merge $annotations .root.Values.global.commonAnnotations -}}
{{- end -}}
{{- with .annotations -}}
{{- $annotations = merge $annotations . -}}
{{- end -}}
{{- with $annotations -}}
{{- toYaml . -}}
{{- end -}}
{{- end }}

{{/*
Render component labels.
Usage: include "dependencytrack.componentLabels" (dict "root" . "base" (include "...labels" . | fromYaml) "labels" .Values.backend.labels)
*/}}
{{- define "dependencytrack.componentLabels" -}}
{{- $labels := dict -}}
{{- with .base -}}{{- $labels = merge $labels . -}}{{- end -}}
{{- with .labels -}}{{- $labels = merge $labels . -}}{{- end -}}
{{- toYaml $labels -}}
{{- end }}

{{/*
Render a PVC spec from a persistence values object.
*/}}
{{- define "dependencytrack.pvcSpec" -}}
accessModes:
  {{- toYaml (.persistence.accessModes | default (list "ReadWriteOnce")) | nindent 2 }}
{{- with .persistence.storageClassName }}
storageClassName: {{ . | quote }}
{{- end }}
resources:
  {{- toYaml (.persistence.resources | default (dict "requests" (dict "storage" "1Gi"))) | nindent 2 }}
{{- end }}

{{/*
Build complete image reference from the configured image fields.
Usage: imageRef $component (e.g., imageRef $values.backend.image)
*/}}
{{- define "imageRef" -}}
{{- $registry := .registry | default "" -}}
{{- $repository := .repository -}}
{{- $digest := .digest | default "" -}}
{{- $tag := .tag | default "latest" -}}
{{- $image := $repository -}}
{{- if and $registry $repository -}}
  {{- $image = printf "%s/%s" $registry $repository -}}
{{- end -}}
{{- if $digest -}}
{{- printf "%s:%s@%s" $image $tag $digest -}}
{{- else -}}
{{- printf "%s:%s" $image $tag -}}
{{- end -}}
{{- end }}

{{/*
Build image reference for a component. global.image.registry takes precedence; falls back to image.registry.
Usage: include "dependencytrack.imageRef" (dict "image" .Values.backend.image "global" .Values.global)
*/}}
{{- define "dependencytrack.imageRef" -}}
{{- include "imageRef" (dict
    "registry" (.global.image.registry | default .image.registry | default "")
    "repository" .image.repository
    "tag" .image.tag
    "digest" .image.digest
) -}}
{{- end }}

{{/*
Get egress package repository FQDNs from global catalog
Usage: include "egressRepositories" (dict "global" .Values.global)
*/}}
{{- define "egressRepositories" -}}
{{- .global.packageRepositories | default list | uniq | toYaml -}}
{{- end }}


{{/*
Get the backend API base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.backendApiUrl" -}}
{{- if .Values.global.baseUrl -}}
{{- .Values.global.baseUrl -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local:8080/api" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Hostnames configured for one gateway-routes route, as a YAML list; empty when the
route is absent or disabled.

The `kindIs "map"` guard is load-bearing: environments disable a route by setting it
to `false` or `null`, and sprig's `dig` type-asserts every intermediate to a map, so
digging straight into a disabled route panics the render.

Usage: include "dependencytrack.routeHostnames" (dict "ctx" . "route" "frontend")
*/}}
{{- define "dependencytrack.routeHostnames" -}}
{{- $gwRoutes := index .ctx.Values "gateway-routes" | default dict -}}
{{- $route := index ($gwRoutes.routes | default dict) .route -}}
{{- if kindIs "map" $route -}}
{{- toYaml (dig "httpRoute" "hostnames" (list) $route) -}}
{{- end -}}
{{- end }}

{{/*
How dtrack is exposed to the outside world: "istio", "ingress" or "none".

Read off the routing values themselves rather than a separate switch, so the two
cannot disagree. Drives the CORS allowed origin, which network policies render,
and whether the waypoint labels are applied to the Services.
*/}}
{{- define "dependencytrack.exposureMode" -}}
{{- if or (include "dependencytrack.routeHostnames" (dict "ctx" . "route" "backend") | fromYamlArray) (include "dependencytrack.routeHostnames" (dict "ctx" . "route" "frontend") | fromYamlArray) -}}
istio
{{- else if or .Values.backend.ingress.enabled .Values.frontend.ingress.enabled -}}
ingress
{{- else -}}
none
{{- end -}}
{{- end }}

{{/*
Get the frontend API base URL (for browser access)
*/}}
{{- define "dependencytrack.frontendApiUrl" -}}
{{- $frontendAuth := include "dependencytrack.frontend.authConfig" . | fromYaml -}}
{{- if $frontendAuth.apiBaseUrl -}}
{{- $frontendAuth.apiBaseUrl -}}
{{- else -}}
{{- $backendHostnames := include "dependencytrack.routeHostnames" (dict "ctx" . "route" "backend") | fromYamlArray -}}
{{- if $backendHostnames -}}
{{- printf "https://%s" (first $backendHostnames) -}}
{{- else if and .Values.backend.ingress.enabled .Values.backend.ingress.host -}}
{{- if .Values.backend.ingress.tls -}}
{{- printf "https://%s" .Values.backend.ingress.host -}}
{{- else -}}
{{- printf "http://%s" .Values.backend.ingress.host -}}
{{- end -}}
{{- else -}}
{{- printf "http://%s.%s.svc.cluster.local" (include "dependencytrack-backend.name" .) .Release.Namespace -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Get the Trivy base URL (internal cluster URL)
*/}}
{{- define "dependencytrack.trivyBaseUrl" -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- if dig "analyzers" "trivy" "baseUrl" "" $b -}}
{{- dig "analyzers" "trivy" "baseUrl" "" $b -}}
{{- else if .Values.trivy.enabled -}}
{{- $trivyServiceName := include "trivy.fullname" . -}}
{{- printf "http://%s.%s.svc.cluster.local:4954" $trivyServiceName .Release.Namespace -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
Get the PostgreSQL host (FQDN)
*/}}
{{- define "dependencytrack.postgresqlHost" -}}
{{- $db := .Values.backend.database -}}
{{- $serviceName := $db.serviceName -}}
{{- $namespace := $db.namespace | default .Release.Namespace -}}
{{- printf "%s.%s.svc.cluster.local" $serviceName $namespace -}}
{{- end }}

{{/*
JDBC URL for backend.database (no query params).
*/}}
{{- define "dependencytrack.backendJdbcUrl" -}}
{{- $db := .Values.backend.database -}}
{{- printf "jdbc:postgresql://%s:%v/%s" (include "dependencytrack.postgresqlHost" .) $db.port $db.name -}}
{{- end }}

{{- define "dependencytrack.backend.fileStorageClaimName" -}}
{{- .Values.backend.fileStorage.local.persistence.existingClaim | default (printf "%s-data" (include "dependencytrack-backend.name" .)) -}}
{{- end }}


{{- define "dependencytrack.backend.authConfig" -}}
{{- $g := .Values.global.auth | default dict -}}
{{- $baseUrl := $g.baseUrl | default "" -}}
{{- $realm := $g.realm | default "" -}}
{{- $issuer := "" -}}
{{- if and $baseUrl $realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $baseUrl) $realm -}}
{{- end -}}
enabled: {{ $g.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $g.clientId | default "" | quote }}
usernameClaim: {{ $g.usernameClaim | default "preferred_username" | quote }}
userProvisioning: {{ $g.userProvisioning | default true }}
teamsClaim: {{ $g.teamsClaim | default "groups" | quote }}
teamSynchronization: {{ $g.teamSynchronization | default true }}
{{- end }}

{{- define "dependencytrack.frontend.authConfig" -}}
{{- $g := .Values.global.auth | default dict -}}
{{- $baseUrl := $g.baseUrl | default "" -}}
{{- $realm := $g.realm | default "" -}}
{{- $issuer := "" -}}
{{- if and $baseUrl $realm -}}
  {{- $issuer = printf "%s/realms/%s" (trimSuffix "/" $baseUrl) $realm -}}
{{- end -}}
enabled: {{ $g.enabled | default false }}
issuerUrl: {{ $issuer | quote }}
clientId: {{ $g.clientId | default "" | quote }}
apiBaseUrl: {{ .Values.frontend.apiBaseUrl | default "" | quote }}
{{- end }}

{{- define "dependencytrack.backend.fqdns" -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- $auth := include "dependencytrack.backend.authConfig" . | fromYaml -}}
{{- $catalog := .Values.global -}}
{{- $fqdns := include "egressRepositories" (dict "global" .Values.global) | fromYamlArray -}}
{{- if dig "vulnerabilitySources" "githubAdvisories" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.githubApi | default list) -}}
{{- end -}}
{{- if dig "vulnerabilitySources" "googleOsv" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.googleOsv | default list) -}}
{{- end -}}
{{- if dig "vulnerabilitySources" "nvd" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.nvdApi | default list) -}}
{{- end -}}
{{- if dig "analyzers" "sonatype" "enabled" false $b -}}
  {{- $fqdns = concat $fqdns ($catalog.sonatypeApi | default list) -}}
{{- end -}}
{{- if $auth.enabled -}}
  {{- $host := regexFind "https?://([^/]+)" ($auth.issuerUrl | default "") -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- $trivyUrl := include "dependencytrack.trivyBaseUrl" . -}}
{{- if and (dig "analyzers" "trivy" "enabled" false $b) $trivyUrl (not (contains ".cluster.local" $trivyUrl)) -}}
  {{- $host := regexFind "https?://([^/]+)" $trivyUrl -}}
  {{- if $host -}}
    {{- $fqdns = concat $fqdns (list (trimPrefix "https://" (trimPrefix "http://" $host))) -}}
  {{- end -}}
{{- end -}}
{{- $fqdns = concat $fqdns (.Values.global.vulnerabilityFeeds | default list) -}}
{{- $fqdns | uniq | toYaml -}}
{{- end }}

{{- define "dependencytrack.trivy.fqdns" -}}
{{- concat (.Values.global.ghcrRepositories | default list) (.Values.global.githubApi | default list) | uniq | toYaml -}}
{{- end }}

{{/*
Build and render a CiliumNetworkPolicy with a toFQDNs egress rule.
Usage: include "dependencytrack.ciliumFqdnPolicy" (dict "root" $ "name" $name "value" $value "fqdns" (include "dependencytrack.backend.fqdns" $))
*/}}
{{- define "dependencytrack.ciliumFqdnPolicy" -}}
{{- $toFqdns := list -}}
{{- range (.fqdns | fromYamlArray) -}}{{- $toFqdns = append $toFqdns (dict "matchPattern" .) -}}{{- end -}}
{{- $fqdnRule := dict "toFQDNs" $toFqdns "toPorts" (list (dict "ports" (list (dict "port" "443" "protocol" "TCP")))) -}}
{{- $policyValue := set (merge dict .value) "egress" (list $fqdnRule) -}}
{{- include "templates.ciliumNetworkPolicy" (dict "root" .root "name" .name "value" $policyValue) -}}
{{- end }}
