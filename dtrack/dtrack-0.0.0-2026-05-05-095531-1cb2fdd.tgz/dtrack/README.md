# DependencyTrack Helm Chart

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.5.0](https://img.shields.io/badge/AppVersion-0.5.0-informational?style=flat-square)

This chart deploys OWASP Dependency-Track (backend API server and frontend UI), plus optional bootstrap job
for initial provisioning of identities, repositories, vulnerability sources, and analyzers, and an optional Trivy vulnerability scanning service.

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global | object | `{"auth":{"baseUrl":"","clientId":"","enabled":false,"realm":"","teamSynchronization":true,"teamsClaim":"groups","userProvisioning":true,"usernameClaim":"preferred_username"},"commonAnnotations":{},"ghcrRepositories":["ghcr.io","pkg-containers.githubusercontent.com","*.ghcr.io"],"githubApi":["api.github.com"],"googleOsv":["osv-vulnerabilities.storage.googleapis.com"],"imagePullSecret":"","networkPolicy":{"defaultDenyAll":true},"nvdApi":["nvd.nist.gov"],"packageRepositories":["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","pkg-containers.githubusercontent.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"],"sonatypeApi":["ossindex.sonatype.org"],"vulnerabilityFeeds":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]}` | Global configuration options |
| global.commonAnnotations | object | `{}` | Common annotations to add to all resources |
| global.imagePullSecret | string | `""` | Default image pull secret name for all workloads (can be overridden per component) |
| global.networkPolicy | object | `{"defaultDenyAll":true}` | Global network policy configuration |
| global.networkPolicy.defaultDenyAll | bool | `true` | Enable default deny network policy |
| global.packageRepositories | list | `["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","pkg-containers.githubusercontent.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"]` | Package repository domains reachable by Cilium policies |
| global.vulnerabilityFeeds | list | `["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]` | Vulnerability feed domains reachable by Cilium policies |
| global.ghcrRepositories | list | `["ghcr.io","pkg-containers.githubusercontent.com","*.ghcr.io"]` | GitHub Container Registry domains reachable by Trivy |
| global.githubApi | list | `["api.github.com"]` | GitHub API domains for advisory and token-backed integrations |
| global.googleOsv | list | `["osv-vulnerabilities.storage.googleapis.com"]` | Google OSV domains for bootstrap OSV integration |
| global.nvdApi | list | `["nvd.nist.gov"]` | NVD API domains for bootstrap NVD integration |
| global.sonatypeApi | list | `["ossindex.sonatype.org"]` | Sonatype OSS Index domains for bootstrap analyzer integration |
| global.auth | object | `{"baseUrl":"","clientId":"","enabled":false,"realm":"","teamSynchronization":true,"teamsClaim":"groups","userProvisioning":true,"usernameClaim":"preferred_username"}` | Shared OIDC/Keycloak auth configuration applied to both backend and frontend |
| global.auth.enabled | bool | `false` | Enable OIDC authentication |
| global.auth.baseUrl | string | `""` | Keycloak base URL (e.g. https://keycloak.example.com) |
| global.auth.realm | string | `""` | Keycloak realm name |
| global.auth.clientId | string | `""` | OAuth2 client ID |
| global.auth.usernameClaim | string | `"preferred_username"` | JWT claim used as the username |
| global.auth.userProvisioning | bool | `true` | Auto-provision users from Keycloak on first login |
| global.auth.teamsClaim | string | `"groups"` | JWT claim containing team/group membership |
| global.auth.teamSynchronization | bool | `true` | Sync team membership on every login |

### Bootstrap Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| bootstrap | object | `{"adminPasswordSecret":{"key":"admin-password","name":"dtrack-bootstrap"},"analyzers":{"sonatype":{"enabled":false,"tokenSecret":{"key":"","name":""},"username":""},"trivy":{"apiTokenSecret":{"key":"","name":""},"baseUrl":"","enabled":true,"ignoreUnfixed":true}},"baseUrl":"","ciliumNetworkPolicy":{"annotations":{},"enabled":true},"defaultAdminPassword":"admin","enabled":true,"frontendBaseUrl":"","identities":{"oidcGroups":[],"teams":[],"userSync":"replace","users":[]},"image":{"digest":"","pullSecret":"","repository":"docker.io/kvalitetsit/dtrack-bootstrap","tag":"0.5.0"},"logLevel":"INFO","networkPolicy":{"annotations":{},"enabled":true},"repositories":[],"resources":{"limits":{"cpu":"50m","memory":"512Mi"},"requests":{"cpu":"10m","memory":"128Mi"}},"vulnerabilitySources":{"githubAdvisories":{"enabled":true,"tokenSecret":{"key":"","name":""}},"googleOsv":{"enabled":true},"nvd":{"apiKeySecret":{"key":"","name":""},"enabled":true}},"waitForBackend":{"image":"busybox:1.37","periodSeconds":5,"timeoutSeconds":300}}` | Bootstrap job configuration for initial Dependency-Track setup (users, teams, groups, repositories, vulnerability sources, analyzers) |
| bootstrap.enabled | bool | `true` | Whether to run the bootstrap job (creates users/teams/groups) |
| bootstrap.logLevel | string | `"INFO"` | Log level for bootstrap container (TRACE|DEBUG|INFO|WARN|ERROR) |
| bootstrap.resources.requests | object | `{"cpu":"10m","memory":"128Mi"}` | Resource requests for bootstrap job |
| bootstrap.resources.requests.memory | string | `"128Mi"` | Memory request for bootstrap job |
| bootstrap.resources.requests.cpu | string | `"10m"` | CPU request for bootstrap job |
| bootstrap.resources.limits | object | `{"cpu":"50m","memory":"512Mi"}` | Resource limits for bootstrap job |
| bootstrap.resources.limits.memory | string | `"512Mi"` | Memory limit for bootstrap job |
| bootstrap.resources.limits.cpu | string | `"50m"` | CPU limit for bootstrap job |
| bootstrap.image | object | `{"digest":"","pullSecret":"","repository":"docker.io/kvalitetsit/dtrack-bootstrap","tag":"0.5.0"}` | Bootstrap job image configuration |
| bootstrap.image.repository | string | `"docker.io/kvalitetsit/dtrack-bootstrap"` | OCI repository with image name (e.g., docker.io/kvalitetsit/dtrack-bootstrap) |
| bootstrap.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| bootstrap.image.pullSecret | string | `""` | Image pull secret name for bootstrap job |
| bootstrap.image.tag | string | `"0.5.0"` | Image tag (overwritten automatically by CI on release) |
| bootstrap.networkPolicy | object | `{"annotations":{},"enabled":true}` | Network policy configuration for bootstrap job |
| bootstrap.networkPolicy.enabled | bool | `true` | Enable network policy for bootstrap job |
| bootstrap.networkPolicy.annotations | object | `{}` | Annotations for bootstrap network policy |
| bootstrap.ciliumNetworkPolicy | object | `{"annotations":{},"enabled":true}` | Cilium network policy configuration for bootstrap DNS and external egress |
| bootstrap.ciliumNetworkPolicy.enabled | bool | `true` | Enable bootstrap CiliumNetworkPolicy |
| bootstrap.ciliumNetworkPolicy.annotations | object | `{}` | Annotations for bootstrap CiliumNetworkPolicy |
| bootstrap.baseUrl | string | `""` | Backend API base URL (must point to Dependency-Track /api endpoint). If empty, auto-generates based on release name. |
| bootstrap.frontendBaseUrl | string | `""` | Frontend base URL for UI links (optional) |
| bootstrap.identities | object | `{"oidcGroups":[],"teams":[],"userSync":"replace","users":[]}` | Identity objects created by the bootstrap job. The rendered bootstrap.yaml is mounted at /bootstrap/bootstrap.yaml inside the job pod. |
| bootstrap.identities.userSync | string | `"replace"` | How users are reconciled: replace (default) removes and recreates all listed users each run; create only adds new users without removing; ignore skips user management entirely. |
| bootstrap.identities.users | list | `[]` | Admin users to create |
| bootstrap.identities.teams | list | `[]` | Teams to create |
| bootstrap.identities.oidcGroups | list | `[]` | OIDC group-to-team mappings to create |
| bootstrap.defaultAdminPassword | string | `"admin"` | Default admin password expected in a fresh install (used to rotate to adminPasswordSecret) |
| bootstrap.adminPasswordSecret | object | `{"key":"admin-password","name":"dtrack-bootstrap"}` | Secret containing new admin password |
| bootstrap.adminPasswordSecret.name | string | `"dtrack-bootstrap"` | Secret name containing admin password |
| bootstrap.adminPasswordSecret.key | string | `"admin-password"` | Key within secret containing admin password |
| bootstrap.vulnerabilitySources | object | `{"githubAdvisories":{"enabled":true,"tokenSecret":{"key":"","name":""}},"googleOsv":{"enabled":true},"nvd":{"apiKeySecret":{"key":"","name":""},"enabled":true}}` | Vulnerability source configuration managed by the bootstrap job |
| bootstrap.vulnerabilitySources.googleOsv | object | `{"enabled":true}` | Google OSV ingestion configuration |
| bootstrap.vulnerabilitySources.googleOsv.enabled | bool | `true` | Enable Google OSV ingestion during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories | object | `{"enabled":true,"tokenSecret":{"key":"","name":""}}` | GitHub advisory mirroring configuration |
| bootstrap.vulnerabilitySources.githubAdvisories.enabled | bool | `true` | Enable GitHub advisory mirroring during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name | string | `""` | Secret name containing GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.key | string | `""` | Key containing GitHub advisory token |
| bootstrap.vulnerabilitySources.nvd | object | `{"apiKeySecret":{"key":"","name":""},"enabled":true}` | NVD integration configuration |
| bootstrap.vulnerabilitySources.nvd.enabled | bool | `true` | Enable NVD integration during bootstrap |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret | object | `{"key":"","name":""}` | Secret reference for NVD API key |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.name | string | `""` | Secret name containing the NVD API key |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.key | string | `""` | Key containing the NVD API key |
| bootstrap.analyzers | object | `{"sonatype":{"enabled":false,"tokenSecret":{"key":"","name":""},"username":""},"trivy":{"apiTokenSecret":{"key":"","name":""},"baseUrl":"","enabled":true,"ignoreUnfixed":true}}` | Analyzer configuration managed by the bootstrap job |
| bootstrap.analyzers.trivy | object | `{"apiTokenSecret":{"key":"","name":""},"baseUrl":"","enabled":true,"ignoreUnfixed":true}` | Trivy analyzer configuration |
| bootstrap.analyzers.trivy.enabled | bool | `true` | Enable Trivy analyzer during bootstrap |
| bootstrap.analyzers.trivy.ignoreUnfixed | bool | `true` | Ignore unfixed vulnerabilities in Dependency-Track Trivy analyzer |
| bootstrap.analyzers.trivy.baseUrl | string | `""` | External Trivy URL. If empty and bundled Trivy is enabled, the in-cluster URL is used |
| bootstrap.analyzers.trivy.apiTokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.name | string | `""` | Secret name containing Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.key | string | `""` | Key containing Trivy API token |
| bootstrap.analyzers.sonatype | object | `{"enabled":false,"tokenSecret":{"key":"","name":""},"username":""}` | Sonatype OSS Index analyzer configuration |
| bootstrap.analyzers.sonatype.enabled | bool | `false` | Enable Sonatype OSS Index analyzer during bootstrap |
| bootstrap.analyzers.sonatype.username | string | `""` | Sonatype OSS Index username |
| bootstrap.analyzers.sonatype.tokenSecret | object | `{"key":"","name":""}` | Secret reference for Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.name | string | `""` | Secret name containing Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.key | string | `""` | Key containing Sonatype OSS Index token |
| bootstrap.repositories | list | `[]` | Repository objects managed by the bootstrap job. Each entry maps to one Dependency-Track repository object. |
| bootstrap.waitForBackend | object | `{"image":"busybox:1.37","periodSeconds":5,"timeoutSeconds":300}` | Init container that polls the backend /api/version endpoint before the bootstrap container starts. |
| bootstrap.waitForBackend.image | string | `"busybox:1.37"` | Image used by the init container (must have sh and wget) |
| bootstrap.waitForBackend.periodSeconds | int | `5` | Seconds between readiness poll attempts |
| bootstrap.waitForBackend.timeoutSeconds | int | `300` | Maximum seconds to wait before failing the init container |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | `{"ciliumNetworkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"cors":{"allowCredentials":true,"allowHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *","allowMethods":"GET, POST, PUT, PATCH, DELETE, OPTIONS","allowOrigin":"","enabled":true,"exposeHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count","maxAge":3600},"datanucleus":{"cacheLevel2Type":""},"env":{"ALPINE_METRICS_ENABLED":true,"LOGGING_CONFIG_PATH":"logback-json.xml","TELEMETRY_SUBMISSION_ENABLED_DEFAULT":false},"extraVolumeMounts":[],"extraVolumes":[],"image":{"digest":"sha256:b64f85b3ccd4cbc8691a97077bdcb62a01139e6dfc9b00a7f97578340653072b","pullPolicy":"IfNotPresent","pullSecret":"","repository":"dependencytrack/apiserver","tag":"4.14.0-alpine"},"ingress":{"annotations":{},"className":"","enabled":true,"host":"","tls":[]},"jvm":{"options":"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"},"livenessProbe":{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/api/version","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2},"logLevel":"INFO","networkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"persistence":{"accessMode":"ReadWriteOnce","enableStatefulSetAutoDeletePVC":true,"existingClaim":"","size":"10Gi","storageClass":"","whenDeleted":"Delete","whenScaled":"Delete"},"podAnnotations":{},"podLabels":{},"pool":{"idleTimeout":300000,"maxLifetime":600000,"maxSize":20,"minIdle":10},"postgresql":{"connectionName":"","database":"dependencytrack","enabled":true,"host":"","ip":"","matchLabels":{},"namespace":"","passwordSecret":{"key":"postgresql-password","name":"dtrack-backend"},"port":5432,"serviceName":"postgresql","usernameSecret":{"key":"postgresql-username","name":"dtrack-backend"}},"readinessProbe":{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2},"replicaCount":2,"resources":{"limits":{"cpu":"2","memory":"8Gi"},"requests":{"cpu":"1","memory":"4Gi"}},"secretKeySecret":{"key":"secret.key","name":""},"serviceAccount":{"annotations":{},"create":true,"name":""},"serviceMonitor":{"enabled":false,"matchLabels":{},"namespace":"infrastructure","port":8000},"truststore":{"accessMode":"ReadWriteOnce","ca":{"cert":"","enabled":false},"enabled":false,"mountPath":"/opt/java/openjdk/lib/security","storage":"100M","storageClassName":""},"workers":{"threadMultiplier":4,"threads":0}}` | Dependency-Track API server configuration |
| backend.logLevel | string | `"INFO"` | Backend log level |
| backend.jvm | object | `{"options":"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"}` | JVM tuning options passed via JAVA_TOOL_OPTIONS |
| backend.jvm.options | string | `"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"` | JVM flags (e.g. GC, heap sizing). Empty string = JVM defaults. |
| backend.image | object | `{"digest":"sha256:b64f85b3ccd4cbc8691a97077bdcb62a01139e6dfc9b00a7f97578340653072b","pullPolicy":"IfNotPresent","pullSecret":"","repository":"dependencytrack/apiserver","tag":"4.14.0-alpine"}` | Backend container image configuration |
| backend.image.repository | string | `"dependencytrack/apiserver"` | Backend image repository with name (e.g., dependencytrack/apiserver) |
| backend.image.digest | string | `"sha256:b64f85b3ccd4cbc8691a97077bdcb62a01139e6dfc9b00a7f97578340653072b"` | Optional image digest (e.g., sha256:...) |
| backend.image.pullSecret | string | `""` | Image pull secret name for backend pods |
| backend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| backend.image.tag | string | `"4.14.0-alpine"` | Overrides the image tag whose default is the chart appVersion |
| backend.replicaCount | int | `2` | Number of backend replicas |
| backend.podLabels | object | `{}` | Additional labels to add to backend pods |
| backend.podAnnotations | object | `{}` | Additional annotations to add to backend pods |
| backend.extraVolumes | list | `[]` | Additional volumes for backend pod (e.g., mount custom CA bundle) |
| backend.extraVolumeMounts | list | `[]` | Additional volume mounts for backend container |
| backend.resources | object | `{"limits":{"cpu":"2","memory":"8Gi"},"requests":{"cpu":"1","memory":"4Gi"}}` | Resource requests and limits for backend pods |
| backend.resources.requests | object | `{"cpu":"1","memory":"4Gi"}` | Resource requests for backend pods |
| backend.resources.requests.memory | string | `"4Gi"` | Memory request for backend pods |
| backend.resources.requests.cpu | string | `"1"` | CPU request for backend pods |
| backend.resources.limits | object | `{"cpu":"2","memory":"8Gi"}` | Resource limits for backend pods |
| backend.resources.limits.memory | string | `"8Gi"` | Memory limit for backend pods |
| backend.resources.limits.cpu | string | `"2"` | CPU limit for backend pods |
| backend.networkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Network policy configuration for backend |
| backend.networkPolicy.enabled | bool | `true` | Enable network policy for backend |
| backend.networkPolicy.annotations | object | `{}` | Annotations for backend network policy |
| backend.networkPolicy.ingress | list | `[]` | Ingress rules for backend network policy |
| backend.networkPolicy.egress | list | `[]` | Egress rules for backend network policy |
| backend.ciliumNetworkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Cilium network policy configuration for backend DNS and external egress |
| backend.ciliumNetworkPolicy.enabled | bool | `true` | Enable backend CiliumNetworkPolicy |
| backend.ciliumNetworkPolicy.annotations | object | `{}` | Annotations for backend CiliumNetworkPolicy |
| backend.ciliumNetworkPolicy.egress | list | `[]` | Additional raw Cilium egress rules for backend |
| backend.ciliumNetworkPolicy.ingress | list | `[]` | Additional Cilium ingress rules for backend. Use this to allow ingress from an ingress controller or other pods by label. Example — allow nginx ingress controller to reach the backend:   ingress:     - fromEndpoints:         - matchLabels:             app.kubernetes.io/name: ingress-nginx             app.kubernetes.io/component: controller       toPorts:         - ports:             - port: "8080"               protocol: TCP |
| backend.ingress | object | `{"annotations":{},"className":"","enabled":true,"host":"","tls":[]}` | Ingress configuration for backend API |
| backend.ingress.enabled | bool | `true` | Enable ingress for backend |
| backend.ingress.className | string | `""` | Ingress class name |
| backend.ingress.annotations | object | `{}` | Ingress annotations |
| backend.ingress.host | string | `""` | Ingress hostname |
| backend.ingress.tls | list | `[]` | TLS configuration |
| backend.livenessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/api/version","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Liveness probe configuration |
| backend.livenessProbe.enabled | bool | `true` | Enable liveness probe |
| backend.livenessProbe.path | string | `"/api/version"` | Path for liveness probe |
| backend.livenessProbe.initialDelaySeconds | int | `60` | Initial delay before liveness probe starts |
| backend.livenessProbe.periodSeconds | int | `10` | Period between liveness probe checks |
| backend.livenessProbe.timeoutSeconds | int | `2` | Timeout for liveness probe |
| backend.livenessProbe.successThreshold | int | `1` | Success threshold for liveness probe |
| backend.livenessProbe.failureThreshold | int | `3` | Failure threshold for liveness probe |
| backend.readinessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Readiness probe configuration |
| backend.readinessProbe.enabled | bool | `true` | Enable readiness probe |
| backend.readinessProbe.path | string | `"/"` | Path for readiness probe |
| backend.readinessProbe.initialDelaySeconds | int | `60` | Initial delay before readiness probe starts |
| backend.readinessProbe.periodSeconds | int | `10` | Period between readiness probe checks |
| backend.readinessProbe.timeoutSeconds | int | `2` | Timeout for readiness probe |
| backend.readinessProbe.successThreshold | int | `1` | Success threshold for readiness probe |
| backend.readinessProbe.failureThreshold | int | `3` | Failure threshold for readiness probe |
| backend.postgresql | object | `{"connectionName":"","database":"dependencytrack","enabled":true,"host":"","ip":"","matchLabels":{},"namespace":"","passwordSecret":{"key":"postgresql-password","name":"dtrack-backend"},"port":5432,"serviceName":"postgresql","usernameSecret":{"key":"postgresql-username","name":"dtrack-backend"}}` | PostgreSQL database configuration |
| backend.postgresql.enabled | bool | `true` | Enable PostgreSQL for backend |
| backend.postgresql.database | string | `"dependencytrack"` | Database name |
| backend.postgresql.serviceName | string | `"postgresql"` | PostgreSQL service name (used for auto-generating host if not set) |
| backend.postgresql.passwordSecret | object | `{"key":"postgresql-password","name":"dtrack-backend"}` | Secret reference for PostgreSQL password |
| backend.postgresql.passwordSecret.name | string | `"dtrack-backend"` | Secret name containing PostgreSQL password |
| backend.postgresql.passwordSecret.key | string | `"postgresql-password"` | Key within secret containing PostgreSQL password |
| backend.postgresql.usernameSecret | object | `{"key":"postgresql-username","name":"dtrack-backend"}` | Secret reference for PostgreSQL username |
| backend.postgresql.usernameSecret.name | string | `"dtrack-backend"` | Secret name containing PostgreSQL username |
| backend.postgresql.usernameSecret.key | string | `"postgresql-username"` | Key within secret containing PostgreSQL username |
| backend.postgresql.host | string | `""` | PostgreSQL host. If empty, auto-generates FQDN based on serviceName and namespace. |
| backend.postgresql.namespace | string | `""` | Namespace of PostgreSQL workload for native NetworkPolicy egress |
| backend.postgresql.matchLabels | object | `{}` | Pod labels used to target PostgreSQL with native NetworkPolicy egress |
| backend.postgresql.port | int | `5432` | PostgreSQL port |
| backend.postgresql.connectionName | string | `""` | Cloud SQL connection name (for GCP) |
| backend.postgresql.ip | string | `""` | PostgreSQL IP address |
| backend.secretKeySecret | object | `{"key":"secret.key","name":""}` | Secret providing Alpine secret.key content (required for deterministic encryption) |
| backend.secretKeySecret.name | string | `""` | Secret name containing secret.key |
| backend.secretKeySecret.key | string | `"secret.key"` | Key within secret containing secret.key content |
| backend.serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Service account configuration |
| backend.serviceAccount.create | bool | `true` | Create service account for backend |
| backend.serviceMonitor | object | `{"enabled":false,"matchLabels":{},"namespace":"infrastructure","port":8000}` | Backend ServiceMonitor configuration (used by Prometheus) |
| backend.serviceMonitor.enabled | bool | `false` | When true, add a netpol rule allowing Prometheus to scrape metrics |
| backend.serviceMonitor.namespace | string | `"infrastructure"` | Namespace where Prometheus pods run |
| backend.serviceMonitor.matchLabels | object | `{}` | Match labels for Prometheus pod selector (optional) |
| backend.serviceMonitor.port | int | `8000` | Port to allow for Prometheus scraping (default: metrics port) |
| backend.persistence | object | `{"accessMode":"ReadWriteOnce","enableStatefulSetAutoDeletePVC":true,"existingClaim":"","size":"10Gi","storageClass":"","whenDeleted":"Delete","whenScaled":"Delete"}` | Persistence configuration for backend storage |
| backend.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for persistent volume |
| backend.persistence.size | string | `"10Gi"` | Size of persistent volume |
| backend.persistence.storageClass | string | `""` | Storage class for persistent volume |
| backend.persistence.existingClaim | string | `""` | Use existing PVC claim |
| backend.persistence.enableStatefulSetAutoDeletePVC | bool | `true` | Enable automatic PVC deletion in StatefulSet |
| backend.persistence.whenDeleted | string | `"Delete"` | PVC retention policy when StatefulSet is deleted |
| backend.persistence.whenScaled | string | `"Delete"` | PVC retention policy when StatefulSet is scaled down |
| backend.truststore | object | `{"accessMode":"ReadWriteOnce","ca":{"cert":"","enabled":false},"enabled":false,"mountPath":"/opt/java/openjdk/lib/security","storage":"100M","storageClassName":""}` | Truststore configuration for CA certificates |
| backend.truststore.enabled | bool | `false` | Enable truststore PVC for CA certificates |
| backend.truststore.storage | string | `"100M"` | Storage size for truststore PVC |
| backend.truststore.storageClassName | string | `""` | Storage class for truststore PVC (optional) |
| backend.truststore.mountPath | string | `"/opt/java/openjdk/lib/security"` | Mount path for truststore PVC |
| backend.truststore.ca | object | `{"cert":"","enabled":false}` | Root CA certificate configuration |
| backend.truststore.ca.enabled | bool | `false` | Create ConfigMap with root CA certificate |
| backend.truststore.ca.cert | string | `""` | Root CA certificate content (PEM format) |
| backend.pool | object | `{"idleTimeout":300000,"maxLifetime":600000,"maxSize":20,"minIdle":10}` | Database connection pool configuration |
| backend.pool.maxSize | int | `20` | Maximum number of database connections (idle + in-use) |
| backend.pool.minIdle | int | `10` | Minimum number of idle connections maintained in the pool |
| backend.pool.idleTimeout | int | `300000` | Maximum time (ms) a connection can sit idle before being removed |
| backend.pool.maxLifetime | int | `600000` | Maximum lifetime (ms) of a connection in the pool |
| backend.workers | object | `{"threadMultiplier":4,"threads":0}` | Event subsystem worker thread configuration |
| backend.workers.threads | int | `0` | Number of worker threads (0 = auto-detect from CPU cores) |
| backend.workers.threadMultiplier | int | `4` | Multiplier applied to CPU cores when threads=0 |
| backend.datanucleus | object | `{"cacheLevel2Type":""}` | DataNucleus ORM cache configuration |
| backend.datanucleus.cacheLevel2Type | string | `""` | L2 cache reference type ("soft" or "weak"). Empty = DTrack default ("soft"). Use "weak" for large deployments to allow GC reclamation under memory pressure. |
| backend.cors | object | `{"allowCredentials":true,"allowHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *","allowMethods":"GET, POST, PUT, PATCH, DELETE, OPTIONS","allowOrigin":"","enabled":true,"exposeHeaders":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count","maxAge":3600}` | Cross-Origin Resource Sharing (CORS) configuration |
| backend.cors.enabled | bool | `true` | Enable CORS headers in REST responses |
| backend.cors.allowOrigin | string | `""` | Allowed origins (empty string = allow all) |
| backend.cors.allowMethods | string | `"GET, POST, PUT, PATCH, DELETE, OPTIONS"` | Allowed HTTP methods |
| backend.cors.allowHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *"` | Allowed request headers |
| backend.cors.exposeHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count"` | Headers exposed to the browser |
| backend.cors.allowCredentials | bool | `true` | Allow credentials (cookies, auth headers) |
| backend.cors.maxAge | int | `3600` | Preflight response cache duration in seconds |
| backend.env | object | `{"ALPINE_METRICS_ENABLED":true,"LOGGING_CONFIG_PATH":"logback-json.xml","TELEMETRY_SUBMISSION_ENABLED_DEFAULT":false}` | Additional environment variables for backend container |
| backend.env.ALPINE_METRICS_ENABLED | bool | `true` | Enable Alpine metrics endpoint for Prometheus monitoring |
| backend.env.LOGGING_CONFIG_PATH | string | `"logback-json.xml"` | Path to logging configuration file within the container |

### Frontend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| frontend | object | `{"apiBaseUrl":"","ciliumNetworkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"env":{},"image":{"digest":"sha256:e752c200d5ad67856494e9ceee7fc58b156a7d03e6ffc5c414b7382b7b0a5085","pullPolicy":"IfNotPresent","pullSecret":"","repository":"dependencytrack/frontend","tag":"4.14.0"},"ingress":{"annotations":{},"className":"","enabled":true,"host":"","tls":[]},"networkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"podAnnotations":{},"podLabels":{},"replicaCount":1,"resources":{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"128m","memory":"256Mi"}},"swagger":{"enabled":false,"path":"/swagger","port":8181}}` | Dependency-Track UI configuration |
| frontend.swagger | object | `{"enabled":false,"path":"/swagger","port":8181}` | Swagger UI configuration |
| frontend.swagger.enabled | bool | `false` | Enable Swagger UI |
| frontend.swagger.path | string | `"/swagger"` | Swagger UI path |
| frontend.swagger.port | int | `8181` | Swagger UI port |
| frontend.image | object | `{"digest":"sha256:e752c200d5ad67856494e9ceee7fc58b156a7d03e6ffc5c414b7382b7b0a5085","pullPolicy":"IfNotPresent","pullSecret":"","repository":"dependencytrack/frontend","tag":"4.14.0"}` | Frontend container image configuration |
| frontend.image.repository | string | `"dependencytrack/frontend"` | Frontend image repository with name (e.g., dependencytrack/frontend) |
| frontend.image.digest | string | `"sha256:e752c200d5ad67856494e9ceee7fc58b156a7d03e6ffc5c414b7382b7b0a5085"` | Optional image digest (e.g., sha256:...) |
| frontend.image.pullSecret | string | `""` | Image pull secret name for frontend pods |
| frontend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| frontend.image.tag | string | `"4.14.0"` | Overrides the image tag whose default is the chart appVersion |
| frontend.replicaCount | int | `1` | Number of frontend replicas |
| frontend.podLabels | object | `{}` | Additional labels to add to frontend pods |
| frontend.podAnnotations | object | `{}` | Additional annotations to add to frontend pods |
| frontend.resources | object | `{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"128m","memory":"256Mi"}}` | Resource requests and limits for frontend pods |
| frontend.resources.requests | object | `{"cpu":"128m","memory":"256Mi"}` | Resource requests for frontend pods |
| frontend.resources.requests.memory | string | `"256Mi"` | Memory request for frontend pods |
| frontend.resources.requests.cpu | string | `"128m"` | CPU request for frontend pods |
| frontend.resources.limits | object | `{"cpu":"1","memory":"512Mi"}` | Resource limits for frontend pods |
| frontend.resources.limits.memory | string | `"512Mi"` | Memory limit for frontend pods |
| frontend.resources.limits.cpu | string | `"1"` | CPU limit for frontend pods |
| frontend.networkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Network policy configuration for frontend |
| frontend.networkPolicy.enabled | bool | `true` | Enable network policy for frontend |
| frontend.networkPolicy.annotations | object | `{}` | Annotations for frontend network policy |
| frontend.networkPolicy.ingress | list | `[]` | Ingress rules for frontend network policy |
| frontend.networkPolicy.egress | list | `[]` | Egress rules for frontend network policy |
| frontend.ciliumNetworkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Cilium network policy configuration for frontend DNS and external egress |
| frontend.ciliumNetworkPolicy.enabled | bool | `true` | Enable frontend CiliumNetworkPolicy |
| frontend.ciliumNetworkPolicy.annotations | object | `{}` | Annotations for frontend CiliumNetworkPolicy |
| frontend.ciliumNetworkPolicy.egress | list | `[]` | Additional raw Cilium egress rules for frontend |
| frontend.ciliumNetworkPolicy.ingress | list | `[]` | Additional Cilium ingress rules for frontend. Use this to allow ingress from an ingress controller or other pods by label. Example — allow nginx ingress controller to reach the frontend:   ingress:     - fromEndpoints:         - matchLabels:             app.kubernetes.io/name: ingress-nginx             app.kubernetes.io/component: controller       toPorts:         - ports:             - port: "80"               protocol: TCP |
| frontend.ingress | object | `{"annotations":{},"className":"","enabled":true,"host":"","tls":[]}` | Ingress configuration for frontend |
| frontend.ingress.enabled | bool | `true` | Enable ingress for frontend |
| frontend.ingress.className | string | `""` | Ingress class name |
| frontend.ingress.annotations | object | `{}` | Ingress annotations |
| frontend.ingress.host | string | `""` | Ingress hostname |
| frontend.ingress.tls | list | `[]` | TLS configuration |
| frontend.apiBaseUrl | string | `""` | API base URL exposed to browser clients. If empty, auto-generates from backend ingress or service |
| frontend.env | object | `{}` | Additional frontend environment variables beyond the derived API/OIDC keys |

### Trivy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| trivy | object | `{"affinity":{},"cache":{"redis":{"enabled":false,"tls":false,"ttl":"","url":""}},"ciliumNetworkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"config":{"dbRepository":"ghcr.io/aquasecurity/trivy-db","debugMode":false,"githubTokenSecret":{"key":"","name":""},"httpProxy":"","httpsProxy":"","noProxy":"","registryPasswordSecret":{"key":"","name":""},"registryUsernameSecret":{"key":"","name":""},"skipDBUpdate":false,"tokenSecret":{"key":"","name":""}},"enabled":true,"extraEnvVars":[],"extraLabels":{},"fullnameOverride":"","image":{"digest":"sha256:bcc376de8d77cfe086a917230e818dc9f8528e3c852f7b1aff648949b6258d1c","pullPolicy":"IfNotPresent","pullSecret":"","repository":"ghcr.io/aquasecurity/trivy","tag":"0.69.3"},"ingress":{"annotations":{},"enabled":false,"hosts":[{"host":null}],"ingressClassName":null,"path":"/","pathType":"Prefix","tls":[]},"nameOverride":"","networkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"nodeSelector":{},"persistence":{"accessMode":"ReadWriteOnce","enabled":true,"size":"5Gi","storageClass":""},"podAnnotations":{},"podSecurityContext":{"fsGroup":65534,"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}},"probes":{"liveness":{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}},"replicaCount":1,"resources":{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"200m","memory":"512Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true},"service":{"name":null,"port":4954,"sessionAffinity":"ClientIP","type":"ClusterIP"},"serviceAccount":{"annotations":{},"create":true,"name":""},"tolerations":[]}` | Trivy server configuration (bundled vulnerability scanner) |
| trivy.enabled | bool | `true` | Enable Trivy server deployment |
| trivy.nameOverride | string | `""` | Override name for Trivy resources |
| trivy.fullnameOverride | string | `""` | Override full name for Trivy resources |
| trivy.replicaCount | int | `1` | Number of Trivy replicas |
| trivy.image | object | `{"digest":"sha256:bcc376de8d77cfe086a917230e818dc9f8528e3c852f7b1aff648949b6258d1c","pullPolicy":"IfNotPresent","pullSecret":"","repository":"ghcr.io/aquasecurity/trivy","tag":"0.69.3"}` | Trivy container image configuration |
| trivy.image.repository | string | `"ghcr.io/aquasecurity/trivy"` | Trivy image repository with name (e.g., ghcr.io/aquasecurity/trivy) |
| trivy.image.digest | string | `"sha256:bcc376de8d77cfe086a917230e818dc9f8528e3c852f7b1aff648949b6258d1c"` | Optional image digest (e.g., sha256:...) |
| trivy.image.tag | string | `"0.69.3"` | Trivy image tag |
| trivy.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| trivy.image.pullSecret | string | `""` | Image pull secret name for Trivy pods |
| trivy.networkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Network policy configuration for Trivy |
| trivy.networkPolicy.enabled | bool | `true` | Enable network policy for Trivy |
| trivy.networkPolicy.annotations | object | `{}` | Annotations for Trivy network policy |
| trivy.networkPolicy.ingress | list | `[]` | Additional ingress rules for Trivy network policy |
| trivy.networkPolicy.egress | list | `[]` | Additional egress rules for Trivy network policy |
| trivy.ciliumNetworkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Cilium network policy configuration for Trivy DNS and external egress |
| trivy.ciliumNetworkPolicy.enabled | bool | `true` | Enable Trivy CiliumNetworkPolicy |
| trivy.ciliumNetworkPolicy.annotations | object | `{}` | Annotations for Trivy CiliumNetworkPolicy |
| trivy.ciliumNetworkPolicy.egress | list | `[]` | Additional raw Cilium egress rules for Trivy |
| trivy.ciliumNetworkPolicy.ingress | list | `[]` | Additional Cilium ingress rules for Trivy |
| trivy.persistence | object | `{"accessMode":"ReadWriteOnce","enabled":true,"size":"5Gi","storageClass":""}` | Persistence configuration for Trivy cache |
| trivy.persistence.enabled | bool | `true` | Enable persistence for Trivy cache |
| trivy.persistence.storageClass | string | `""` | Storage class for Trivy persistent volume |
| trivy.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for Trivy persistent volume |
| trivy.persistence.size | string | `"5Gi"` | Size of Trivy persistent volume |
| trivy.resources | object | `{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"200m","memory":"512Mi"}}` | Resource requests and limits for Trivy pods |
| trivy.resources.requests | object | `{"cpu":"200m","memory":"512Mi"}` | Resource requests for Trivy pods |
| trivy.resources.requests.cpu | string | `"200m"` | CPU request for Trivy pods |
| trivy.resources.requests.memory | string | `"512Mi"` | Memory request for Trivy pods |
| trivy.resources.limits | object | `{"cpu":1,"memory":"1Gi"}` | Resource limits for Trivy pods |
| trivy.resources.limits.cpu | int | `1` | CPU limit for Trivy pods |
| trivy.resources.limits.memory | string | `"1Gi"` | Memory limit for Trivy pods |
| trivy.podSecurityContext | object | `{"fsGroup":65534,"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context for Trivy pods |
| trivy.podSecurityContext.runAsUser | int | `65534` | User ID to run Trivy pods |
| trivy.podSecurityContext.runAsNonRoot | bool | `true` | Enforce non-root user for Trivy pods |
| trivy.podSecurityContext.fsGroup | int | `65534` | File system group for Trivy pods |
| trivy.podSecurityContext.seccompProfile | object | `{"type":"RuntimeDefault"}` | Seccomp profile for Trivy pods |
| trivy.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` | Seccomp profile type for Trivy pods |
| trivy.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true}` | Container security context for Trivy |
| trivy.securityContext.privileged | bool | `false` | Run Trivy container in privileged mode |
| trivy.securityContext.readOnlyRootFilesystem | bool | `true` | Enforce read-only root filesystem for Trivy container |
| trivy.securityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation for Trivy container |
| trivy.securityContext.capabilities | object | `{"drop":["ALL"]}` | Capabilities for Trivy container |
| trivy.securityContext.capabilities.drop | list | `["ALL"]` | Capabilities to drop for Trivy container |
| trivy.nodeSelector | object | `{}` | Node selector for Trivy pods |
| trivy.affinity | object | `{}` | Affinity settings for Trivy pods |
| trivy.tolerations | list | `[]` | Tolerations for Trivy pods |
| trivy.podAnnotations | object | `{}` | Annotations for Trivy pods |
| trivy.config | object | `{"dbRepository":"ghcr.io/aquasecurity/trivy-db","debugMode":false,"githubTokenSecret":{"key":"","name":""},"httpProxy":"","httpsProxy":"","noProxy":"","registryPasswordSecret":{"key":"","name":""},"registryUsernameSecret":{"key":"","name":""},"skipDBUpdate":false,"tokenSecret":{"key":"","name":""}}` | Additional Trivy configuration options |
| trivy.config.debugMode | bool | `false` | Enable debug mode for Trivy |
| trivy.config.githubTokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub token |
| trivy.config.githubTokenSecret.name | string | `""` | Secret name containing GitHub token for Trivy |
| trivy.config.githubTokenSecret.key | string | `""` | Key within secret containing GitHub token for Trivy |
| trivy.config.tokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| trivy.config.tokenSecret.name | string | `""` | Secret name containing Trivy API token |
| trivy.config.tokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| trivy.config.registryUsernameSecret | object | `{"key":"","name":""}` | Secret reference for registry username |
| trivy.config.registryUsernameSecret.name | string | `""` | Secret name containing registry username for Trivy |
| trivy.config.registryUsernameSecret.key | string | `""` | Key within secret containing registry username for Trivy |
| trivy.config.registryPasswordSecret | object | `{"key":"","name":""}` | Secret reference for registry password |
| trivy.config.registryPasswordSecret.name | string | `""` | Secret name containing registry password for Trivy |
| trivy.config.registryPasswordSecret.key | string | `""` | Key within secret containing registry password for Trivy |
| trivy.config.skipDBUpdate | bool | `false` | Skip database update on Trivy startup |
| trivy.config.dbRepository | string | `"ghcr.io/aquasecurity/trivy-db"` | Trivy database repository |
| trivy.config.httpProxy | string | `""` | HTTP proxy for Trivy |
| trivy.config.httpsProxy | string | `""` | HTTPS proxy for Trivy |
| trivy.config.noProxy | string | `""` | No proxy settings for Trivy |
| trivy.cache | object | `{"redis":{"enabled":false,"tls":false,"ttl":"","url":""}}` | Trivy cache configuration |
| trivy.cache.redis | object | `{"enabled":false,"tls":false,"ttl":"","url":""}` | Redis cache configuration for Trivy |
| trivy.cache.redis.enabled | bool | `false` | Enable Redis cache for Trivy |
| trivy.cache.redis.url | string | `""` | Redis URL for Trivy cache |
| trivy.cache.redis.ttl | string | `""` | Time-to-live for Redis cache entries |
| trivy.cache.redis.tls | bool | `false` | Enable TLS for Redis connection |
| trivy.probes | object | `{"liveness":{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}}` | Liveness and readiness probe configuration for Trivy |
| trivy.probes.liveness | object | `{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Liveness probe configuration for Trivy |
| trivy.probes.liveness.initialDelaySeconds | int | `5` | Initial delay before liveness probe starts |
| trivy.probes.liveness.periodSeconds | int | `10` | Period between liveness probe checks |
| trivy.probes.liveness.successThreshold | int | `1` | Success threshold for liveness probe |
| trivy.probes.liveness.failureThreshold | int | `10` | Failure threshold for liveness probe |
| trivy.probes.readiness | object | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Readiness probe configuration for Trivy |
| trivy.probes.readiness.initialDelaySeconds | int | `5` | Initial delay before readiness probe starts |
| trivy.probes.readiness.periodSeconds | int | `10` | Period between readiness probe checks |
| trivy.probes.readiness.successThreshold | int | `1` | Success threshold for readiness probe |
| trivy.probes.readiness.failureThreshold | int | `3` | Failure threshold for readiness probe |
| trivy.serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Service account configuration for Trivy |
| trivy.serviceAccount.create | bool | `true` | Create a dedicated service account for Trivy |
| trivy.serviceAccount.name | string | `""` | Override the Trivy service account name |
| trivy.serviceAccount.annotations | object | `{}` | Annotations for Trivy service account |
| trivy.extraLabels | object | `{}` | Extra labels to add to Trivy resources |
| trivy.extraEnvVars | list | `[]` | Extra environment variables for Trivy container |
| trivy.service | object | `{"name":null,"port":4954,"sessionAffinity":"ClientIP","type":"ClusterIP"}` | Service configuration for Trivy |
| trivy.service.name | string | `nil` | Service name override for Trivy service (optional) |
| trivy.service.type | string | `"ClusterIP"` | Kubernetes service type |
| trivy.service.port | int | `4954` | Kubernetes service port |
| trivy.service.sessionAffinity | string | `"ClientIP"` | Kubernetes service session affinity |
| trivy.ingress | object | `{"annotations":{},"enabled":false,"hosts":[{"host":null}],"ingressClassName":null,"path":"/","pathType":"Prefix","tls":[]}` | Ingress configuration for Trivy |
| trivy.ingress.enabled | bool | `false` | Enable ingress for Trivy |
| trivy.ingress.ingressClassName | string | `nil` | Ingress class name for Trivy |
| trivy.ingress.annotations | object | `{}` | Annotations for Trivy ingress |
| trivy.ingress.hosts | list | `[{"host":null}]` | Hosts for Trivy ingress |
| trivy.ingress.hosts[0].host | string | `nil` | Hostname for Trivy ingress |
| trivy.ingress.path | string | `"/"` | Path for Trivy ingress |
| trivy.ingress.pathType | string | `"Prefix"` | Path type for Trivy ingress |
| trivy.ingress.tls | list | `[]` | TLS configuration for Trivy ingress |
