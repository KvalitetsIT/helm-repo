# DependencyTrack Helm Chart

![Version: 0.10.0](https://img.shields.io/badge/Version-0.10.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.10.0](https://img.shields.io/badge/AppVersion-0.10.0-informational?style=flat-square)

This chart deploys OWASP Dependency-Track (backend API server and frontend UI), optional manual bootstrap
resources for initial provisioning, and an optional Trivy vulnerability scanning service.

Routing can be configured with either standard Kubernetes Ingress resources or Gateway API resources via the
KvalitetsIT `gateway-routes` library chart.

## Prerequisites

Required:

- Kubernetes 1.25+
- PostgreSQL reachable from the backend
- Dependency-Track v5 images (this chart is v5-only; see [Upgrading from v4 to v5](#upgrading-from-v4-to-v5))
- A Secret holding the KEK used by Dependency-Track's database secret-management provider

Optional, depending on enabled features:

- Istio with Gateway API support when using `gateway-routes`
- An existing Gateway resource when using Gateway API
- cert-manager with a ClusterIssuer when using Gateway API TLS automation

## Required configuration

### Secret management (KEK)

This chart only supports Dependency-Track's `database` secret-management provider: DT v5 encrypts credentials
(repository passwords, integration tokens, and other secrets written through the API) into PostgreSQL using a
key-encryption key (KEK). The chart hardcodes `DT_SECRET_MANAGEMENT_PROVIDER=database` and does not expose a
provider option, because DT's `env` provider is read-only after startup and the bootstrap job writes credentials
through the API, which the `env` provider cannot accept.

The chart never generates or inlines the KEK. Create a Secret yourself and reference it from
`backend.secretManagement.kek.existingSecret.name`:

```yaml
backend:
  secretManagement:
    kek:
      mode: config
      existingSecret:
        name: dtrack-backend-kek
```

Two KEK modes are supported:

- **`config`** (default): a base64-encoded 32-byte AES key, stored under the Secret key `kek`. Generate one with:

  ```bash
  kubectl create secret generic dtrack-backend-kek \
    --from-literal=kek="$(openssl rand -base64 32)"
  ```

- **`keyset`**: a Tink JSON keyset, stored under the Secret key `kek-keyset.json`. This is the only mode that
  supports in-place KEK rotation, so it is recommended for long-lived production installs. Generate one with
  [tinkey](https://github.com/tink-crypto/tink-go):

  ```bash
  tinkey create-keyset --key-template AES256_GCM --out kek-keyset.json
  kubectl create secret generic dtrack-backend-kek \
    --from-file=kek-keyset.json
  ```

If you manage Secrets with SealedSecrets, seal the generated value under the same suggested name
(`dtrack-backend-kek`) and commit the sealed resource; the chart only references the Secret name and key, it
never creates the Secret.

> [!WARNING]
> Losing the KEK makes every secret Dependency-Track has encrypted into PostgreSQL unrecoverable, including
> repository passwords and integration tokens. Back up the KEK Secret (or the sealed source of truth) with the
> same care as the database itself.

### PostgreSQL

> [!NOTE]
> This chart configures Dependency-Track to connect to PostgreSQL, but it does not install PostgreSQL.
> We recommend installing PostgreSQL separately with the [KvalitetsIT cnpg-cluster chart](https://artifacthub.io/packages/helm/kvalitetsit/cnpg-cluster),
> then pointing `backend.database` at that service and credentials. `backend.database.serviceName` is required.

```yaml
backend:
  database:
    serviceName: postgresql
    port: 5432
    name: dtrack
    usernameSecret:
      name: dtrack-postgres-credentials
      key: username
    passwordSecret:
      name: dtrack-postgres-credentials
      key: password
```

Size the server's `max_connections` against the pools this chart opens. Dependency-Track 5 runs
**two** HikariCP pools per backend replica (a transactional one and a read-only one), so:

```
max_connections >= backend.replicas * backend.pool.maxSize * 2 + headroom
```

Leave headroom for CNPG's own connections, backup jobs and admin sessions - 20 to 30 is enough.

### Backend file storage

Choose a file-storage provider explicitly with `backend.fileStorage.provider`.

For local storage, either let the chart create a PVC or reference an existing PVC:

```yaml
backend:
  fileStorage:
    provider: local
    local:
      persistence:
        create: true
        accessModes:
          - ReadWriteOnce
```

Multiple backend replicas using local storage require `ReadWriteMany`. Helm rejects multi-replica local
configurations without RWX. Alternatively, use S3-compatible storage, which does not create a backend PVC:

```yaml
backend:
  replicas: 2
  fileStorage:
    provider: s3
    s3:
      endpoint: https://s3.example.com
      bucket: dependency-track
      region: eu-west-1
      credentialsSecret:
        name: dtrack-s3-credentials
        accessKeyKey: access-key
        secretKeyKey: secret-key
```

### Suggested Secret names

For new installations, use purpose-oriented Secret names and keep the existing split between the KEK,
bootstrap-only credentials, shared integration tokens, and database credentials:

- `dtrack-backend-kek`: contains only the KEK (`kek` for config mode, `kek-keyset.json` for keyset mode)
- `dtrack-bootstrap-secrets`: admin password and bootstrap-only credentials such as NVD/Sonatype/repository credentials
- `dtrack-integration-secrets`: tokens shared by multiple integrations, for example Trivy and GitHub tokens used by both bootstrap configuration and the Trivy service
- `dtrack-postgres-credentials`: PostgreSQL `username` and `password`

When migrating an existing installation, do not blindly rename Secrets. Many deployments use SealedSecrets or
externally managed Secrets, so renaming may require re-sealing/recreating the Secret or keeping the old name in
values.

## Upgrading from v4 to v5

> [!IMPORTANT]
> This chart is v5-only starting with 0.7.0: rendering fails when `backend.image.tag` or `frontend.image.tag`
> has the `4.` prefix. Installations still running Dependency-Track v4 must stay on chart `<= 0.6.x` until they
> complete the cutover below.

Migration from v4 to v5 is a one-time, out-of-band operation and lives in a separate chart,
[`dtrack-migration`](../dtrack-migration/README.md), not in this chart. This chart has no `migration.*`
values: installing `dtrack-migration` is itself the intent to migrate, and its migration Job always
renders (no toggle). This is a human-driven runbook, not a Git/ArgoCD-driven cutover with Helm hooks.

1. **Provision the v5 target.** Provision a fresh v5 PostgreSQL database (for example with the
   [cnpg-cluster chart](https://artifacthub.io/packages/helm/kvalitetsit/cnpg-cluster)), and create the
   KEK Secret and v5 database credentials Secret described above.
2. **Scale everything down.** Scale the running v4 `dtrack` release's backend and frontend to zero
   replicas. If a v5 `dtrack` backend already exists pointed at the target database, scale it down too.
   Nothing should write to either database while the migration runs.
3. **Install the migration chart**, pointing `source` at the v4 database, `target` at the v5 database,
   and `offlineGuard.url` at the draining v4 backend:

   ```bash
   helm install dtrack-migration ./charts/dtrack-migration -f my-migration-values.yaml
   ```

   The chart's offline guard confirms the v4 backend is actually offline before it lets anything touch
   the databases, then bootstraps the v5 schema and migrates the data. See the
   [`dtrack-migration` README](../dtrack-migration/README.md) for the full runbook and value reference.
4. **Verify the migration Job** before proceeding:

   ```bash
   kubectl logs job/dtrack-migration -c migration-bootstrap
   kubectl logs job/dtrack-migration -c migration
   ```
5. **Upgrade the `dtrack` release to v5**: bump the chart to 0.7.x, migrate values, point
   `backend.database` at the v5 database, set `backend.image.tag`/`frontend.image.tag` to 5.x, and set
   `backend.secretManagement.kek.existingSecret`. The v5 backend starts, runs its init tasks in-pod, and
   becomes ready via `/health/started`.
6. **Remove the migration chart**:

   ```bash
   helm uninstall dtrack-migration
   ```
7. **Re-run bootstrap after cutover.** The v4-migrator nulls out DB-encrypted secret values as part of
   the migration, so repository passwords and integration tokens are gone until bootstrap re-seeds them.
   Trigger the bootstrap CronJob manually (see [Manual bootstrap](#manual-bootstrap)); this re-writes
   those credentials through the API, and v5 KEK-encrypts them under the fresh KEK.

Rollback: before cutover, revert to chart `<= 0.6.x`; the v4 database is untouched. After the migration Job
has written to the v5 database, roll back by restoring the v5 target from backup and re-running the Job.

## v5 startup and init tasks

Dependency-Track v5 runs its schema and data init tasks in-pod on every backend startup rather than via a
separate initializer Job; a Postgres advisory lock serializes these tasks across replicas, so concurrent
startups are safe. Because init tasks can take longer than a plain readiness check tolerates, the chart
exposes `backend.startupProbe` (`periodSeconds`/`failureThreshold`/`timeoutSeconds`, defaults 15/40/5) as the
operator knob: raise `failureThreshold` to widen the budget for large post-migration init-task runs. Health
endpoints (`/health/started`, `/health/live`, `/health/ready`) are served on the management port (`8000`,
`DT_MANAGEMENT_PORT`), which liveness and readiness probes also default to, so probes no longer depend on the
Jetty port (8080) being ready during init tasks.

## Manual bootstrap

When `bootstrap.enabled=true`, the chart installs a Secret and suspended CronJob. It never runs bootstrap as
an install or upgrade side effect. Trigger it explicitly when Dependency-Track is healthy:

```bash
kubectl create job --from=cronjob/dtrack-bootstrap dtrack-bootstrap-$(date +%s)
```

For local development, `mise run dev:v5:up` brings up the kind cluster, database, and chart (including a
smoke test) but does not trigger bootstrap. Run `mise run dev:bootstrap` afterwards to trigger the job from
the suspended CronJob; bootstrap is never automatic.

## Routing

This chart supports two routing options that can be used independently or together:

- **Gateway API**: configured through the `gateway-routes` dependency.
- **Ingress**: configured with `backend.ingress` and `frontend.ingress`.

### Gateway API

```yaml
gateway-routes:
  defaults:
    gateway:
      name: ingressgateway
      namespace: istio-ingress
    clusterIssuer: letsencrypt-prod-istio

  routes:
    backend:
      httpRoute:
        hostnames:
          - dtrack-api.example.com
    frontend:
      httpRoute:
        hostnames:
          - dtrack.example.com
```

The frontend `API_BASE_URL` environment variable is derived automatically from
`gateway-routes.routes.backend.httpRoute.hostnames[0]`. Set `frontend.apiBaseUrl` only when you need to override it.

If you set `nameOverride` and also use custom `gateway-routes.routes.*.httpRoute.rules`, make sure your
`backendRefs` point at the rendered backend/frontend Service names.

### Ingress

```yaml
backend:
  ingress:
    enabled: true
    host: dtrack-api.example.com

frontend:
  ingress:
    enabled: true
    host: dtrack.example.com
```

### Exposure mode

The chart derives a single `exposureMode` from the routing configuration above and uses it to
configure three things that would otherwise have to be kept in sync by hand.

| `exposureMode` | Detected when | CORS allowed origin | Ingress network policies | Waypoint Service labels |
|---|---|---|---|---|
| `istio` | `gateway-routes.routes.backend` or `.frontend` has hostnames | `https://<frontend route hostname>` | `backend-waypoint`, `frontend-waypoint` | applied |
| `ingress` | otherwise, if `backend.ingress.enabled` or `frontend.ingress.enabled` | `https://<frontend.ingress.host>` | `backend-ingress`, `frontend-ingress` | not applied |
| `none` | neither | empty, so no `Access-Control-Allow-Origin` header | neither pair | not applied |

Derived origins are always `https://`. There is no switch to set the mode by hand: it follows
whichever routing block you configured. Set `backend.cors.allowOrigin` to override just the origin.

The `ingress` policies select the RKE2-bundled `rke2-ingress-nginx` in `kube-system`. On a cluster
whose controller differs, override the `backend-ingress` and `frontend-ingress` entries in
`networkPolicies` and `ciliumNetworkPolicies` with the right selector.

## Authentication (OIDC / Keycloak)

Both backend and frontend share OIDC configuration through `global.auth`. The `clientId` is shared: the frontend
authenticates with it, and the backend validates tokens issued to that same client.

```yaml
global:
  auth:
    enabled: true
    baseUrl: https://keycloak.example.com
    realm: dependency-track
    clientId: dtrack
```

## Images and private registries

To pull all images from a private registry mirror, set `global.image.registry`. It overrides the per-component
fallback registries, so all chart-managed images use the same registry prefix unless you leave it empty.

```yaml
global:
  image:
    registry: mirror.example.com
  imagePullSecrets:
    - name: regcred
```

## Network policies

The chart renders Kubernetes `NetworkPolicy` and `CiliumNetworkPolicy` resources from the `networkPolicies` and
`ciliumNetworkPolicies` value maps.

Entries carrying an `exposure` key render only when it matches the resolved `exposureMode` (see
[Exposure mode](#exposure-mode)). Every other entry renders unconditionally. Each map entry also
supports `enabled: false` to suppress it; prefer that over an empty-map override, which ArgoCD
cannot apply without `ServerSideApply=true`.

A `CiliumNetworkPolicy` entry takes precedence over a `networkPolicies` entry of the same name
when the cluster has the `cilium.io/v2` API; without it, the `networkPolicies` twin renders
instead. Both maps ship twins for the exposure-gated entries so the app is reachable either way.

`networkPolicies.allow-kube-dns` hardcodes `169.254.20.10/32` (node-local DNS) and `10.43.0.10/32`
(cluster DNS) because a vanilla `NetworkPolicy` cannot select pods across namespaces by label.
Those are the RKE2 defaults; override the entry on a cluster that uses a different service CIDR.

Port values in `networkPolicies` must be integers (a Kubernetes requirement). Because Helm's `tpl` function cannot
produce unquoted integers from template expressions, ports in the built-in `networkPolicies.backend` entry are
hardcoded to their well-known defaults (`8080`, `8000`, `5432`, `4954`).

> [!NOTE]
> If you change `backend.database.port` from the default `5432`, you must also override the corresponding egress rule in `networkPolicies.backend`.

To disable all network policies:

```yaml
networkPolicies: ~
ciliumNetworkPolicies: ~
```

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| nameOverride | string | `""` | Override the release/name base used for resource naming and labels. |
| global | object | See [values.yaml](values.yaml) | Global configuration options |
| global.commonAnnotations | object | `{}` | Common annotations to add to all resources |
| global.imagePullSecrets | list | `[]` | Image pull secrets applied to all workloads. Per-component pullSecrets are merged with this list. |
| global.image.registry | string | `""` | Registry prefix applied to all component images. Takes precedence over per-component image.registry. |
| global.baseUrl | string | `""` | Backend API base URL shared by all jobs (bootstrap, migrate-tags, and future job binaries). Must point to the Dependency-Track /api endpoint. If empty, auto-generates the in-cluster URL based on release name. |
| global.waitForBackend | object | See [values.yaml](values.yaml) | Init container that blocks jobs (bootstrap, migrate-tags, and future job binaries) until the backend /version endpoint responds. |
| global.waitForBackend.image.registry | string | `"docker.io"` | Fallback registry prefix for wait-for-backend image. Overridden by global.image.registry when set. |
| global.waitForBackend.image.repository | string | `"library/busybox"` | Image repository path (without registry prefix) |
| global.waitForBackend.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| global.waitForBackend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| global.waitForBackend.image.tag | string | `"1.37"` | Image tag |
| global.waitForBackend.periodSeconds | int | `5` | Seconds between readiness poll attempts |
| global.waitForBackend.timeoutSeconds | int | `300` | Maximum seconds to wait before failing the init container |
| global.packageRepositories | list | See [values.yaml](values.yaml) | Package repository domains reachable by Cilium policies |
| global.vulnerabilityFeeds | list | See [values.yaml](values.yaml) | Vulnerability feed domains reachable by Cilium policies |
| global.ghcrRepositories | list | See [values.yaml](values.yaml) | GitHub Container Registry domains reachable by Trivy |
| global.githubApi | list | See [values.yaml](values.yaml) | GitHub API domains for advisory and token-backed integrations |
| global.googleOsv | list | See [values.yaml](values.yaml) | Google OSV domains for bootstrap OSV integration |
| global.nvdApi | list | See [values.yaml](values.yaml) | NVD API domains for bootstrap NVD integration |
| global.sonatypeApi | list | See [values.yaml](values.yaml) | Sonatype OSS Index domains for bootstrap analyzer integration |
| global.auth | object | See [values.yaml](values.yaml) | Shared OIDC/Keycloak auth configuration applied to both backend and frontend |
| global.auth.enabled | bool | `false` | Enable OIDC authentication |
| global.auth.baseUrl | string | `""` | Keycloak base URL (e.g. https://keycloak.example.com) |
| global.auth.realm | string | `""` | Keycloak realm name |
| global.auth.clientId | string | `""` | OAuth2 client ID |
| global.auth.usernameClaim | string | `"preferred_username"` | JWT claim used as the username |
| global.auth.userProvisioning | bool | `true` | Auto-provision users from Keycloak on first login |
| global.auth.teamsClaim | string | `"groups"` | JWT claim containing team/group membership |
| global.auth.teamSynchronization | bool | `true` | Sync team membership on every login |

### Bootstrap Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| bootstrap | object | See [values.yaml](values.yaml) | Bootstrap job configuration for initial Dependency-Track setup (users, teams, groups, repositories, vulnerability sources, analyzers) |
| bootstrap.enabled | bool | `true` | Whether to deploy the bootstrap Secret and suspended, manually triggered CronJob |
| bootstrap.logLevel | string | `"INFO"` | Log level for bootstrap container (TRACE|DEBUG|INFO|WARN|ERROR) |
| bootstrap.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for bootstrap job |
| bootstrap.image.registry | string | `"docker.io"` | Fallback registry prefix for bootstrap image. Overridden by global.image.registry when set. |
| bootstrap.image.repository | string | `"kvalitetsit/dtrack-bootstrap"` | Image repository path (without registry prefix) |
| bootstrap.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| bootstrap.image.pullSecrets | list | `[]` | Image pull secrets for bootstrap job. Merged with global.imagePullSecrets. |
| bootstrap.image.tag | string | `"0.10.0"` | Image tag (overwritten automatically by CI on release) |
| bootstrap.frontendBaseUrl | string | `""` | Frontend base URL for UI links (optional) |
| bootstrap.portfolioAccessControl.enabled | string | `nil` | Enable Dependency-Track Portfolio Access Control, restricting project-scoped operations to the teams mapped to each project. Leave null to keep whatever is configured in Dependency-Track; setting true or false makes bootstrap reconcile the value on every run. |
| bootstrap.identities.validate | bool | `true` | Enable Helm-time validation that user and OIDC group team references point at known teams. Set to false as an escape hatch when referencing pre-existing teams not listed in defaultTeams/teams/extraTeams. |
| bootstrap.identities.defaultTeams | list | `["Administrators","Automation","Badge Viewers","Portfolio Managers"]` | Predefined Dependency-Track teams accepted by Helm-time team reference validation. These teams exist in Dependency-Track and are not rendered into bootstrap.yaml as managed teams. |
| bootstrap.identities.userSync | string | `"replace"` | How users are reconciled: replace (default) removes and recreates all listed users each run; create only adds new users without removing; ignore skips user management entirely. |
| bootstrap.identities.users | list | `[]` | Admin users to create |
| bootstrap.identities.teams | list | See [values.yaml](values.yaml) | Teams to create |
| bootstrap.identities.extraTeams | list | `[]` | Additional teams merged with `teams` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.extraUsers | list | `[]` | Additional users merged with `users` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.oidcGroups | list | `[]` | OIDC group-to-team mappings to create |
| bootstrap.identities.extraOidcGroups | list | `[]` | Additional OIDC group-to-team mappings merged with `oidcGroups` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.defaultAdminPassword | string | `"admin"` | Default admin password expected in a fresh install (used to rotate to adminPasswordSecret) |
| bootstrap.adminPasswordSecret.name | string | `"dtrack-bootstrap-secrets"` | Secret name containing admin password |
| bootstrap.adminPasswordSecret.key | string | `"admin-password"` | Key within secret containing admin password |
| bootstrap.vulnerabilitySources.googleOsv.enabled | bool | `true` | Enable Google OSV ingestion during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.enabled | bool | `true` | Enable GitHub advisory mirroring during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name | string | `""` | Secret name containing GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.key | string | `""` | Key containing GitHub advisory token |
| bootstrap.vulnerabilitySources.nvd.enabled | bool | `true` | Enable NVD integration during bootstrap |
| bootstrap.vulnerabilitySources.nvd.cveFeedsUrl | string | `""` | CVE feed URL. Empty uses Dependency-Track's own default (https://nvd.nist.gov/feeds) |
| bootstrap.analyzers | object | See [values.yaml](values.yaml) | Analyzer configuration managed by the bootstrap job |
| bootstrap.analyzers.trivy.enabled | bool | `true` | Enable Trivy analyzer during bootstrap. Dependency-Track v5 requires apiTokenSecret to be set whenever this is true, even for the bundled Trivy server |
| bootstrap.analyzers.trivy.ignoreUnfixed | bool | `true` | Ignore unfixed vulnerabilities in Dependency-Track Trivy analyzer |
| bootstrap.analyzers.trivy.baseUrl | string | `""` | External Trivy URL. If empty and bundled Trivy is enabled, the in-cluster URL is used |
| bootstrap.analyzers.trivy.apiTokenSecret.name | string | `""` | Secret name containing Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.key | string | `""` | Key containing Trivy API token |
| bootstrap.analyzers.sonatype.enabled | bool | `false` | Enable Sonatype OSS Index analyzer during bootstrap |
| bootstrap.analyzers.sonatype.username | string | `""` | Sonatype OSS Index username |
| bootstrap.analyzers.sonatype.tokenSecret.name | string | `""` | Secret name containing Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.key | string | `""` | Key containing Sonatype OSS Index token |
| bootstrap.repositories | list | `[]` | Repository objects managed by the bootstrap job. Each entry maps to one Dependency-Track repository object. |
| bootstrap.extraRepositories | list | `[]` | Additional repositories merged with `repositories` at render time. Useful for extending a shared base values file without overriding it. |

### Migrate Tags Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| migrateTags | object | See [values.yaml](values.yaml) | Temporary project tag migration job (suspended CronJob, trigger manually) |
| migrateTags.enabled | bool | `false` | Whether to deploy the migrate-tags CronJob and ConfigMap |
| migrateTags.image.registry | string | `"docker.io"` | Fallback registry prefix for migrate-tags image. Overridden by global.image.registry when set. |
| migrateTags.image.repository | string | `"kvalitetsit/dtrack-migrate-tags"` | Image repository path (without registry prefix) |
| migrateTags.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| migrateTags.image.pullSecrets | list | `[]` | Image pull secrets for migrate-tags job. Merged with global.imagePullSecrets. |
| migrateTags.image.tag | string | `"0.10.0"` | Image tag (overwritten automatically by CI on release) |
| migrateTags.logLevel | string | `"INFO"` | Log level for migrate-tags container (TRACE|DEBUG|INFO|WARN|ERROR) |
| migrateTags.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for migrate-tags job |
| migrateTags.dryRun | bool | `true` | When true, log planned tag changes without updating projects |
| migrateTags.replacements | list | `[]` | Tag replacements applied to every project. Each entry has `from` (required), `to` (required), optional `type` (`exact` (default) or `substring`), and optional `collectionLogics` (list restricting the replacement to projects with those collection logics; empty = all projects). |

### Cleanup Projects Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cleanupProjects | object | See [values.yaml](values.yaml) | Manual project cleanup job (suspended CronJob, trigger manually) |
| cleanupProjects.enabled | bool | `false` | Whether to deploy the cleanup-projects CronJob and ConfigMap |
| cleanupProjects.image.registry | string | `"docker.io"` | Fallback registry prefix for cleanup-projects image. Overridden by global.image.registry when set. |
| cleanupProjects.image.repository | string | `"kvalitetsit/dtrack-cleanup-projects"` | Image repository path (without registry prefix) |
| cleanupProjects.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| cleanupProjects.image.pullSecrets | list | `[]` | Image pull secrets for cleanup-projects job. Merged with global.imagePullSecrets. |
| cleanupProjects.image.tag | string | `"0.10.0"` | Image tag (overwritten automatically by CI on release) |
| cleanupProjects.logLevel | string | `"INFO"` | Log level for cleanup-projects container (TRACE|DEBUG|INFO|WARN|ERROR) |
| cleanupProjects.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for cleanup-projects job |
| cleanupProjects.dryRun | bool | `true` | When true, log planned deletions without deleting projects |
| cleanupProjects.rules | list | `[]` | Project deletion rules. Each rule may specify optional matchers (`classifier`, `group`, `version`, `name` as `{ regex: ... }`) and optional `tags` (exact, all required). Every specified criterion within a rule must match (AND); a project is deleted when it matches any rule (OR). |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | See [values.yaml](values.yaml) | Dependency-Track API server configuration |
| backend.logLevel | string | `"INFO"` | Backend log level |
| backend.jvm.options | string | `"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"` | JVM flags (e.g. GC, heap sizing). Empty string = JVM defaults. |
| backend.image.registry | string | `""` | Fallback registry prefix for backend image. Overridden by global.image.registry when set. |
| backend.image.repository | string | `"dependencytrack/apiserver"` | Image repository path (without registry prefix) |
| backend.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| backend.image.pullSecrets | list | `[]` | Image pull secrets for backend pods. Merged with global.imagePullSecrets. |
| backend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| backend.image.tag | string | `"5.0.2"` | Backend image tag |
| backend.replicas | int | `1` | Number of backend replicas. Set both backend.replicas and frontend.replicas to 0 to take the release offline (e.g. before a migration cutover). |
| backend.labels | object | `{}` | Additional labels to add to backend workload resources |
| backend.annotations | object | `{}` | Additional annotations to add to backend workload resources |
| backend.podLabels | object | `{}` | Additional labels to add to backend pods |
| backend.podAnnotations | object | `{}` | Additional annotations to add to backend pods |
| backend.extraVolumes | list | `[]` | Additional volumes for backend pod (e.g., mount custom CA bundle) |
| backend.extraVolumeMounts | list | `[]` | Additional volume mounts for backend container |
| backend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for backend pods |
| backend.ingress.enabled | bool | `false` | Enable Ingress for backend API |
| backend.ingress.className | string | `""` | Ingress class name |
| backend.ingress.annotations | object | `{}` | Ingress annotations |
| backend.ingress.host | string | `""` | Ingress hostname |
| backend.ingress.tls | list | `[]` | TLS configuration |
| backend.startupProbe.periodSeconds | int | `15` | Seconds between startup probe checks against /health/started |
| backend.startupProbe.failureThreshold | int | `40` | Failed startup probes tolerated before the container is restarted. Raise this to widen the budget for large post-migration init-task runs. |
| backend.startupProbe.timeoutSeconds | int | `5` | Timeout for each startup probe |
| backend.livenessProbe.enabled | bool | `true` | Enable liveness probe |
| backend.livenessProbe.port | string | `"http-metrics"` | Container port for liveness probe. Defaults to the management port so it does not depend on Jetty during init tasks. |
| backend.livenessProbe.path | string | `"/health/live"` | Path for liveness probe |
| backend.livenessProbe.initialDelaySeconds | int | `60` | Initial delay before liveness probe starts |
| backend.livenessProbe.periodSeconds | int | `10` | Period between liveness probe checks |
| backend.livenessProbe.timeoutSeconds | int | `2` | Timeout for liveness probe |
| backend.livenessProbe.successThreshold | int | `1` | Success threshold for liveness probe |
| backend.livenessProbe.failureThreshold | int | `3` | Failure threshold for liveness probe |
| backend.readinessProbe.enabled | bool | `true` | Enable readiness probe |
| backend.readinessProbe.port | string | `"http-metrics"` | Container port for readiness probe. Defaults to the management port so it does not depend on Jetty during init tasks. |
| backend.readinessProbe.path | string | `"/health/ready"` | Path for readiness probe |
| backend.readinessProbe.initialDelaySeconds | int | `60` | Initial delay before readiness probe starts |
| backend.readinessProbe.periodSeconds | int | `10` | Period between readiness probe checks |
| backend.readinessProbe.timeoutSeconds | int | `2` | Timeout for readiness probe |
| backend.readinessProbe.successThreshold | int | `1` | Success threshold for readiness probe |
| backend.readinessProbe.failureThreshold | int | `3` | Failure threshold for readiness probe |
| backend.database | object | See [values.yaml](values.yaml) | PostgreSQL connection configuration. Install PostgreSQL separately, for example with the KvalitetsIT cnpg-cluster chart. |
| backend.database.serviceName | string | `""` | PostgreSQL service name used for auto-generating the in-cluster host. Required. |
| backend.database.namespace | string | `""` | Namespace of the PostgreSQL service. Defaults to the release namespace. |
| backend.database.port | int | `5432` | PostgreSQL port |
| backend.database.name | string | `"dtrack"` | Database name |
| backend.database.usernameSecret.name | string | `"dtrack-postgres-credentials"` | Secret name containing PostgreSQL username |
| backend.database.usernameSecret.key | string | `"username"` | Key within secret containing PostgreSQL username |
| backend.database.passwordSecret.name | string | `"dtrack-postgres-credentials"` | Secret name containing PostgreSQL password |
| backend.database.passwordSecret.key | string | `"password"` | Key within secret containing PostgreSQL password |
| backend.secretManagement | object | See [values.yaml](values.yaml) | Secret management for the database provider. Dependency-Track v5 KEK-encrypts credentials in PostgreSQL; the chart is database-provider only. |
| backend.secretManagement.kek.mode | string | `"config"` | KEK format. `config` (base64 32-byte AES key, Secret key `kek`) or `keyset` (Tink JSON keyset, Secret key `kek-keyset.json`, supports in-place rotation). |
| backend.secretManagement.kek.existingSecret.name | string | `""` | Required. Secret holding the KEK; the chart never generates it. Generate config-mode with `openssl rand -base64 32`. |
| backend.secretManagement.kek.existingSecret.key | string | `""` | Key within the Secret. Empty defaults to `kek` (config mode) or `kek-keyset.json` (keyset mode). |
| backend.fileStorage | object | See [values.yaml](values.yaml) | Backend file storage configuration. Select local PVC-backed storage or S3-compatible storage. |
| backend.fileStorage.provider | string | `""` | File storage provider. Must be `local` or `s3`. |
| backend.fileStorage.local.directory | string | `"/data/storage"` | Directory where Dependency-Track stores files when using the local provider. |
| backend.fileStorage.local.persistence.create | bool | `false` | Create a PVC for local file storage. Cannot be combined with existingClaim. |
| backend.fileStorage.local.persistence.existingClaim | string | `""` | Existing PVC to use for local file storage instead of creating one. |
| backend.fileStorage.local.persistence.accessModes | list | `["ReadWriteOnce"]` | PVC access modes. Multiple backend replicas require ReadWriteMany. |
| backend.fileStorage.local.persistence.resources | object | `{"requests":{"storage":"10Gi"}}` | Storage resources requested when creating the local PVC. |
| backend.fileStorage.local.persistence.storageClassName | string | `""` | Storage class used when creating the local PVC. Empty uses the cluster default. |
| backend.fileStorage.s3.endpoint | string | `""` | S3-compatible endpoint URL. |
| backend.fileStorage.s3.bucket | string | `""` | Existing bucket used for Dependency-Track file storage. |
| backend.fileStorage.s3.region | string | `""` | Optional S3 region. |
| backend.fileStorage.s3.credentialsSecret.name | string | `""` | Optional Secret containing both S3 credential values. |
| backend.fileStorage.s3.credentialsSecret.accessKeyKey | string | `"access-key"` | Key in the credentials Secret containing the S3 access key. |
| backend.fileStorage.s3.credentialsSecret.secretKeyKey | string | `"secret-key"` | Key in the credentials Secret containing the S3 secret key. |
| backend.service.labels | object | `{}` | Labels applied to the Service verbatim, whatever the exposure model. |
| backend.serviceAccount.create | bool | `false` | Create service account for backend |
| backend.serviceAccount.name | string | `""` | Existing ServiceAccount name to use, or generated when create=true |
| backend.serviceAccount.annotations | object | `{}` | Annotations for backend service account |
| backend.serviceAccount.automountServiceAccountToken | bool | `false` | Mount the ServiceAccount token into backend pods |
| backend.serviceMonitor.enabled | bool | `false` | Create a ServiceMonitor for the backend metrics port. Requires prometheus-operator. Network access for the scrape is granted unconditionally by the `backend-metrics` network policy, not by this toggle. |
| backend.truststore.enabled | bool | `false` | Enable truststore PVC for CA certificates |
| backend.truststore.storage | string | `"100M"` | Storage size for truststore PVC |
| backend.truststore.storageClassName | string | `""` | Storage class for truststore PVC (optional) |
| backend.truststore.accessMode | string | `"ReadWriteOnce"` | Access mode for truststore PVC |
| backend.truststore.mountPath | string | `"/opt/java/openjdk/lib/security"` | Mount path for truststore PVC |
| backend.truststore.ca.enabled | bool | `false` | Create ConfigMap with root CA certificate |
| backend.truststore.ca.cert | string | `""` | Root CA certificate content (PEM format) |
| backend.pool.maxSize | int | `20` | Maximum number of database connections (idle + in-use) |
| backend.pool.minIdle | int | `10` | Minimum number of idle connections maintained in the pool |
| backend.pool.idleTimeout | int | `300000` | Maximum time (ms) a connection can sit idle before being removed |
| backend.pool.maxLifetime | int | `600000` | Maximum lifetime (ms) of a connection in the pool |
| backend.workers.threads | int | `0` | Number of task scheduler threads (0 = DT default based on CPU cores) |
| backend.cors.enabled | bool | `true` | Enable CORS headers in REST responses |
| backend.cors.allowOrigin | string | `""` | Allowed origin. Leave empty to derive it from how the frontend is exposed: the first `gateway-routes.routes.frontend` hostname, else `frontend.ingress.host`, always as `https://`. When nothing is exposed the header is omitted entirely, which is the correct no-op - an empty value does NOT mean "allow all". `*` is rejected while `allowCredentials` is true; browsers refuse that combination and the backend always sends `Access-Control-Allow-Credentials`. |
| backend.cors.allowMethods | string | `"GET, POST, PUT, PATCH, DELETE, OPTIONS"` | Allowed HTTP methods |
| backend.cors.allowHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *"` | Allowed request headers |
| backend.cors.exposeHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count"` | Headers exposed to the browser |
| backend.cors.allowCredentials | bool | `true` | Allow credentials (cookies, auth headers) |
| backend.cors.maxAge | int | `3600` | Preflight response cache duration in seconds |
| backend.env | list | See [values.yaml](values.yaml) | Environment variables for the backend container |
| backend.extraEnvs | list | `[]` | Additional backend environment variables appended after env |
| backend.envFrom | list | `[]` | Environment variable sources for the backend container |
| backend.extraEnvFrom | list | `[]` | Additional backend environment variable sources appended after envFrom |

### Frontend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| frontend | object | See [values.yaml](values.yaml) | Dependency-Track UI configuration |
| frontend.image.registry | string | `""` | Fallback registry prefix for frontend image. Overridden by global.image.registry when set. |
| frontend.image.repository | string | `"dependencytrack/frontend"` | Image repository path (without registry prefix) |
| frontend.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| frontend.image.pullSecrets | list | `[]` | Image pull secrets for frontend pods. Merged with global.imagePullSecrets. |
| frontend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| frontend.image.tag | string | `"5.0.2"` | Frontend image tag |
| frontend.service.labels | object | `{}` | Labels applied to the Service verbatim, whatever the exposure model. |
| frontend.replicas | int | `1` | Number of frontend replicas |
| frontend.labels | object | `{}` | Additional labels to add to frontend workload resources |
| frontend.annotations | object | `{}` | Additional annotations to add to frontend workload resources |
| frontend.podLabels | object | `{}` | Additional labels to add to frontend pods |
| frontend.podAnnotations | object | `{}` | Additional annotations to add to frontend pods |
| frontend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for frontend pods |
| frontend.ingress.enabled | bool | `false` | Enable Ingress for frontend UI |
| frontend.ingress.className | string | `""` | Ingress class name |
| frontend.ingress.annotations | object | `{}` | Ingress annotations |
| frontend.ingress.host | string | `""` | Ingress hostname |
| frontend.ingress.tls | list | `[]` | TLS configuration |
| frontend.apiBaseUrl | string | `""` | API base URL exposed to browser clients. If empty, auto-generates from backend ingress or service |
| frontend.env | list | `[]` | Environment variables for the frontend container |
| frontend.extraEnvs | list | `[]` | Additional frontend environment variables appended after env |
| frontend.envFrom | list | `[]` | Environment variable sources for the frontend container |
| frontend.extraEnvFrom | list | `[]` | Additional frontend environment variable sources appended after envFrom |

### Trivy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| trivy | object | See [values.yaml](values.yaml) | Trivy server configuration (bundled vulnerability scanner) |
| trivy.enabled | bool | `true` | Enable Trivy server deployment |
| trivy.replicas | int | `1` | Number of Trivy replicas |
| trivy.labels | object | `{}` | Additional labels to add to Trivy workload resources |
| trivy.annotations | object | `{}` | Additional annotations to add to Trivy workload resources |
| trivy.image.registry | string | `"ghcr.io"` | Fallback registry prefix for Trivy image. Overridden by global.image.registry when set. |
| trivy.image.repository | string | `"aquasecurity/trivy"` | Image repository path (without registry prefix) |
| trivy.image.digest | string | `"sha256:016eae51fdcf989332a5404af7e8f625cd5d95d7c0907a221d080a996f556500"` | Optional image digest (e.g., sha256:...) |
| trivy.image.tag | string | `"0.71.0"` | Trivy image tag |
| trivy.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| trivy.image.pullSecrets | list | `[]` | Image pull secrets for Trivy pods. Merged with global.imagePullSecrets. |
| trivy.persistence.enabled | bool | `true` | Enable persistence for Trivy cache |
| trivy.persistence.storageClassName | string | `""` | Storage class for Trivy persistent volume. Empty string omits the field. |
| trivy.persistence.accessModes | list | `["ReadWriteOnce"]` | Access modes for Trivy persistent volume |
| trivy.persistence.resources | object | `{"requests":{"storage":"5Gi"}}` | PersistentVolumeClaim resource requests |
| trivy.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for Trivy pods |
| trivy.resources.requests.cpu | string | `"200m"` | CPU request for Trivy pods |
| trivy.resources.requests.memory | string | `"512Mi"` | Memory request for Trivy pods |
| trivy.resources.limits.cpu | int | `1` | CPU limit for Trivy pods |
| trivy.resources.limits.memory | string | `"1Gi"` | Memory limit for Trivy pods |
| trivy.podSecurityContext.runAsUser | int | `65534` | User ID to run Trivy pods |
| trivy.podSecurityContext.runAsNonRoot | bool | `true` | Enforce non-root user for Trivy pods |
| trivy.podSecurityContext.fsGroup | int | `65534` | File system group for Trivy pods |
| trivy.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` | Seccomp profile type for Trivy pods |
| trivy.securityContext.privileged | bool | `false` | Run Trivy container in privileged mode |
| trivy.securityContext.readOnlyRootFilesystem | bool | `true` | Enforce read-only root filesystem for Trivy container |
| trivy.securityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation for Trivy container |
| trivy.securityContext.capabilities.drop | list | `["ALL"]` | Capabilities to drop for Trivy container |
| trivy.nodeSelector | object | `{}` | Node selector for Trivy pods |
| trivy.affinity | object | `{}` | Affinity settings for Trivy pods |
| trivy.tolerations | list | `[]` | Tolerations for Trivy pods |
| trivy.podAnnotations | object | `{}` | Annotations for Trivy pods |
| trivy.config.debugMode | bool | `false` | Enable debug mode for Trivy |
| trivy.config.githubTokenSecret.name | string | `""` | Secret name containing GitHub token for Trivy |
| trivy.config.githubTokenSecret.key | string | `""` | Key within secret containing GitHub token for Trivy |
| trivy.config.tokenSecret.name | string | `""` | Secret name containing Trivy API token |
| trivy.config.tokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| trivy.config.registryUsernameSecret.name | string | `""` | Secret name containing registry username for Trivy |
| trivy.config.registryUsernameSecret.key | string | `""` | Key within secret containing registry username for Trivy |
| trivy.config.registryPasswordSecret.name | string | `""` | Secret name containing registry password for Trivy |
| trivy.config.registryPasswordSecret.key | string | `""` | Key within secret containing registry password for Trivy |
| trivy.config.skipDBUpdate | bool | `false` | Skip database update on Trivy startup |
| trivy.config.dbRepository | string | `"ghcr.io/aquasecurity/trivy-db"` | Trivy database repository |
| trivy.config.httpProxy | string | `""` | HTTP proxy for Trivy |
| trivy.config.httpsProxy | string | `""` | HTTPS proxy for Trivy |
| trivy.config.noProxy | string | `""` | No proxy settings for Trivy |
| trivy.cache.redis.enabled | bool | `false` | Enable Redis cache for Trivy |
| trivy.cache.redis.url | string | `""` | Redis URL for Trivy cache |
| trivy.cache.redis.ttl | string | `""` | Time-to-live for Redis cache entries |
| trivy.cache.redis.tls | bool | `false` | Enable TLS for Redis connection |
| trivy.probes.liveness.initialDelaySeconds | int | `5` | Initial delay before liveness probe starts |
| trivy.probes.liveness.periodSeconds | int | `10` | Period between liveness probe checks |
| trivy.probes.liveness.successThreshold | int | `1` | Success threshold for liveness probe |
| trivy.probes.liveness.failureThreshold | int | `10` | Failure threshold for liveness probe |
| trivy.probes.readiness.initialDelaySeconds | int | `5` | Initial delay before readiness probe starts |
| trivy.probes.readiness.periodSeconds | int | `10` | Period between readiness probe checks |
| trivy.probes.readiness.successThreshold | int | `1` | Success threshold for readiness probe |
| trivy.probes.readiness.failureThreshold | int | `3` | Failure threshold for readiness probe |
| trivy.serviceAccount.create | bool | `false` | Create a dedicated service account for Trivy |
| trivy.serviceAccount.name | string | `""` | Existing ServiceAccount name to use, or generated when create=true |
| trivy.serviceAccount.annotations | object | `{}` | Annotations for Trivy service account |
| trivy.serviceAccount.automountServiceAccountToken | bool | `false` | Mount the ServiceAccount token into Trivy pods |
| trivy.env | list | `[]` | Environment variables for the Trivy container |
| trivy.extraEnvs | list | `[]` | Additional Trivy environment variables appended after env |
| trivy.envFrom | list | `[]` | Environment variable sources for the Trivy container |
| trivy.extraEnvFrom | list | `[]` | Additional Trivy environment variable sources appended after envFrom |

### Network Policies

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicies | object | See [values.yaml](values.yaml) | Map of Kubernetes NetworkPolicy resources. K8s-only entries (no matching ciliumNetworkPolicies key) are always rendered. Entries that share a key with ciliumNetworkPolicies act as fallbacks on non-Cilium clusters. |
| ciliumNetworkPolicies | object | See [values.yaml](values.yaml) | Map of CiliumNetworkPolicy resources. Rendered only when cilium.io/v2 is available. Entries sharing a key with networkPolicies fall back to K8s NetworkPolicy on non-Cilium clusters. |
| templates | object | `{}` | Configuration for the KvalitetsIT templates library chart (https://github.com/KvalitetsIT/helm-templates-chart). Use templates.sealedSecrets, templates.resources, etc. to render additional resources via the library. |

### Gateway Routes

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| gateway-routes | object | See values.yaml | Configuration for the KvalitetsIT gateway-routes chart (https://github.com/KvalitetsIT/helm-gateway-routes-chart). Declares HTTPRoute and ListenerSet resources against an existing Istio gateway. |
| gateway-routes.routes.backend.httpRoute | object | `{"hostnames":[]}` | HTTPRoute config for the backend API |
| gateway-routes.routes.backend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack-api.example.com]) |
| gateway-routes.routes.frontend.httpRoute | object | `{"hostnames":[]}` | HTTPRoute config for the frontend UI |
| gateway-routes.routes.frontend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack.example.com]) |
