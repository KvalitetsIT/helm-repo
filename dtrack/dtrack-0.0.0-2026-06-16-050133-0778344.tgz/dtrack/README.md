# DependencyTrack Helm Chart

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.5.0](https://img.shields.io/badge/AppVersion-0.5.0-informational?style=flat-square)

This chart deploys OWASP Dependency-Track (backend API server and frontend UI), an optional bootstrap job
for initial provisioning, and an optional Trivy vulnerability scanning service.

Routing can be configured with either standard Kubernetes Ingress resources or Gateway API resources via the
KvalitetsIT `gateway-routes` library chart.

## Prerequisites

Required:

- Kubernetes 1.25+
- PostgreSQL reachable from the backend
- A Secret for Dependency-Track's `secret.key`

Optional, depending on enabled features:

- Istio with Gateway API support when using `gateway-routes`
- An existing Gateway resource when using Gateway API
- cert-manager with a ClusterIssuer when using Gateway API TLS automation

## Required configuration

### Backend secret key

> [!NOTE]
> Dependency-Track requires a stable `secret.key` for deterministic encryption. Create a Secret containing a key
> named `secret.key`, then reference it from `backend.secretKeySecret.name`:

```yaml
backend:
  secretKeySecret:
    name: dtrack-secret-key
```

### PostgreSQL

> [!NOTE]
> This chart configures Dependency-Track to connect to PostgreSQL, but it does not install PostgreSQL.
> We recommend installing PostgreSQL separately with the [KvalitetsIT cnpg-cluster chart](https://artifacthub.io/packages/helm/kvalitetsit/cnpg-cluster),
> then pointing `backend.database` at that service and credentials. `backend.database.serviceName` is required.

```yaml
backend:
  database:
    serviceName: postgresql
    port: 5432
    name: dtrack
    usernameSecret:
      name: dtrack-postgres-user-secret
      key: username
    passwordSecret:
      name: dtrack-postgres-user-secret
      key: password
```

## Routing

This chart supports two routing options that can be used independently or together:

- **Gateway API**: configured through the `gateway-routes` dependency.
- **Ingress**: configured with `backend.ingress` and `frontend.ingress`.

### Gateway API

```yaml
gateway-routes:
  defaults:
    gateway:
      name: ingressgateway
      namespace: istio-ingress
    clusterIssuer: letsencrypt-prod-istio

  routes:
    backend:
      httpRoute:
        hostnames:
          - dtrack-api.example.com
    frontend:
      httpRoute:
        hostnames:
          - dtrack.example.com
```

The frontend `API_BASE_URL` environment variable is derived automatically from
`gateway-routes.routes.backend.httpRoute.hostnames[0]`. Set `frontend.apiBaseUrl` only when you need to override it.

If you set `nameOverride` and also use custom `gateway-routes.routes.*.httpRoute.rules`, make sure your
`backendRefs` point at the rendered backend/frontend Service names.

### Ingress

```yaml
backend:
  ingress:
    enabled: true
    host: dtrack-api.example.com

frontend:
  ingress:
    enabled: true
    host: dtrack.example.com
```

## Authentication (OIDC / Keycloak)

Both backend and frontend share OIDC configuration through `global.auth`. The `clientId` is shared: the frontend
authenticates with it, and the backend validates tokens issued to that same client.

```yaml
global:
  auth:
    enabled: true
    baseUrl: https://keycloak.example.com
    realm: dependency-track
    clientId: dtrack
```

## Images and private registries

To pull all images from a private registry mirror, set `global.image.registry`. It overrides the per-component
fallback registries, so all chart-managed images use the same registry prefix unless you leave it empty.

```yaml
global:
  image:
    registry: mirror.example.com
  imagePullSecrets:
    - name: regcred
```

## Network policies

The chart renders Kubernetes `NetworkPolicy` and `CiliumNetworkPolicy` resources from the `networkPolicies` and
`ciliumNetworkPolicies` value maps.

Port values in `networkPolicies` must be integers (a Kubernetes requirement). Because Helm's `tpl` function cannot
produce unquoted integers from template expressions, ports in the built-in `networkPolicies.backend` entry are
hardcoded to their well-known defaults (`8080`, `8000`, `5432`, `4954`).

> [!NOTE]
> If you change `backend.database.port` from the default `5432`, you must also override the corresponding egress rule in `networkPolicies.backend`.

To disable all network policies:

```yaml
networkPolicies: ~
ciliumNetworkPolicies: ~
```

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| nameOverride | string | `""` | Override the release/name base used for resource naming and labels. |
| global | object | See [values.yaml](values.yaml) | Global configuration options |
| global.commonAnnotations | object | `{}` | Common annotations to add to all resources |
| global.imagePullSecrets | list | `[]` | Image pull secrets applied to all workloads. Per-component pullSecrets are merged with this list. |
| global.image.registry | string | `""` | Registry prefix applied to all component images. Takes precedence over per-component image.registry. |
| global.packageRepositories | list | See [values.yaml](values.yaml) | Package repository domains reachable by Cilium policies |
| global.vulnerabilityFeeds | list | See [values.yaml](values.yaml) | Vulnerability feed domains reachable by Cilium policies |
| global.ghcrRepositories | list | See [values.yaml](values.yaml) | GitHub Container Registry domains reachable by Trivy |
| global.githubApi | list | See [values.yaml](values.yaml) | GitHub API domains for advisory and token-backed integrations |
| global.googleOsv | list | See [values.yaml](values.yaml) | Google OSV domains for bootstrap OSV integration |
| global.nvdApi | list | See [values.yaml](values.yaml) | NVD API domains for bootstrap NVD integration |
| global.sonatypeApi | list | See [values.yaml](values.yaml) | Sonatype OSS Index domains for bootstrap analyzer integration |
| global.auth | object | See [values.yaml](values.yaml) | Shared OIDC/Keycloak auth configuration applied to both backend and frontend |
| global.auth.enabled | bool | `false` | Enable OIDC authentication |
| global.auth.baseUrl | string | `""` | Keycloak base URL (e.g. https://keycloak.example.com) |
| global.auth.realm | string | `""` | Keycloak realm name |
| global.auth.clientId | string | `""` | OAuth2 client ID |
| global.auth.usernameClaim | string | `"preferred_username"` | JWT claim used as the username |
| global.auth.userProvisioning | bool | `true` | Auto-provision users from Keycloak on first login |
| global.auth.teamsClaim | string | `"groups"` | JWT claim containing team/group membership |
| global.auth.teamSynchronization | bool | `true` | Sync team membership on every login |

### Bootstrap Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| bootstrap | object | See [values.yaml](values.yaml) | Bootstrap job configuration for initial Dependency-Track setup (users, teams, groups, repositories, vulnerability sources, analyzers) |
| bootstrap.enabled | bool | `true` | Whether to run the bootstrap job (creates users/teams/groups) |
| bootstrap.logLevel | string | `"INFO"` | Log level for bootstrap container (TRACE|DEBUG|INFO|WARN|ERROR) |
| bootstrap.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for bootstrap job |
| bootstrap.image.registry | string | `"docker.io"` | Fallback registry prefix for bootstrap image. Overridden by global.image.registry when set. |
| bootstrap.image.repository | string | `"kvalitetsit/dtrack-bootstrap"` | Image repository path (without registry prefix) |
| bootstrap.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| bootstrap.image.pullSecrets | list | `[]` | Image pull secrets for bootstrap job. Merged with global.imagePullSecrets. |
| bootstrap.image.tag | string | `"0.5.0"` | Image tag (overwritten automatically by CI on release) |
| bootstrap.baseUrl | string | `""` | Backend API base URL (must point to Dependency-Track /api endpoint). If empty, auto-generates based on release name. |
| bootstrap.frontendBaseUrl | string | `""` | Frontend base URL for UI links (optional) |
| bootstrap.identities.userSync | string | `"replace"` | How users are reconciled: replace (default) removes and recreates all listed users each run; create only adds new users without removing; ignore skips user management entirely. |
| bootstrap.identities.users | list | `[]` | Admin users to create |
| bootstrap.identities.teams | list | See [values.yaml](values.yaml) | Teams to create |
| bootstrap.identities.extraTeams | list | `[]` | Additional teams merged with `teams` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.extraUsers | list | `[]` | Additional users merged with `users` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.identities.oidcGroups | list | `[]` | OIDC group-to-team mappings to create |
| bootstrap.identities.extraOidcGroups | list | `[]` | Additional OIDC group-to-team mappings merged with `oidcGroups` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.defaultAdminPassword | string | `"admin"` | Default admin password expected in a fresh install (used to rotate to adminPasswordSecret) |
| bootstrap.adminPasswordSecret.name | string | `"dtrack-bootstrap"` | Secret name containing admin password |
| bootstrap.adminPasswordSecret.key | string | `"admin-password"` | Key within secret containing admin password |
| bootstrap.vulnerabilitySources.googleOsv.enabled | bool | `true` | Enable Google OSV ingestion during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.enabled | bool | `true` | Enable GitHub advisory mirroring during bootstrap |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.name | string | `""` | Secret name containing GitHub advisory token |
| bootstrap.vulnerabilitySources.githubAdvisories.tokenSecret.key | string | `""` | Key containing GitHub advisory token |
| bootstrap.vulnerabilitySources.nvd.enabled | bool | `true` | Enable NVD integration during bootstrap |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.name | string | `""` | Secret name containing the NVD API key |
| bootstrap.vulnerabilitySources.nvd.apiKeySecret.key | string | `""` | Key containing the NVD API key |
| bootstrap.analyzers | object | See [values.yaml](values.yaml) | Analyzer configuration managed by the bootstrap job |
| bootstrap.analyzers.trivy.enabled | bool | `true` | Enable Trivy analyzer during bootstrap |
| bootstrap.analyzers.trivy.ignoreUnfixed | bool | `true` | Ignore unfixed vulnerabilities in Dependency-Track Trivy analyzer |
| bootstrap.analyzers.trivy.baseUrl | string | `""` | External Trivy URL. If empty and bundled Trivy is enabled, the in-cluster URL is used |
| bootstrap.analyzers.trivy.apiTokenSecret.name | string | `""` | Secret name containing Trivy API token |
| bootstrap.analyzers.trivy.apiTokenSecret.key | string | `""` | Key containing Trivy API token |
| bootstrap.analyzers.sonatype.enabled | bool | `false` | Enable Sonatype OSS Index analyzer during bootstrap |
| bootstrap.analyzers.sonatype.username | string | `""` | Sonatype OSS Index username |
| bootstrap.analyzers.sonatype.tokenSecret.name | string | `""` | Secret name containing Sonatype OSS Index token |
| bootstrap.analyzers.sonatype.tokenSecret.key | string | `""` | Key containing Sonatype OSS Index token |
| bootstrap.repositories | list | `[]` | Repository objects managed by the bootstrap job. Each entry maps to one Dependency-Track repository object. |
| bootstrap.extraRepositories | list | `[]` | Additional repositories merged with `repositories` at render time. Useful for extending a shared base values file without overriding it. |
| bootstrap.waitForBackend.image.registry | string | `"docker.io"` | Fallback registry prefix for wait-for-backend image. Overridden by global.image.registry when set. |
| bootstrap.waitForBackend.image.repository | string | `"library/busybox"` | Image repository path (without registry prefix) |
| bootstrap.waitForBackend.image.digest | string | `""` | Optional image digest (e.g., sha256:...) |
| bootstrap.waitForBackend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| bootstrap.waitForBackend.image.tag | string | `"1.37"` | Image tag |
| bootstrap.waitForBackend.periodSeconds | int | `5` | Seconds between readiness poll attempts |
| bootstrap.waitForBackend.timeoutSeconds | int | `300` | Maximum seconds to wait before failing the init container |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | See [values.yaml](values.yaml) | Dependency-Track API server configuration |
| backend.logLevel | string | `"INFO"` | Backend log level |
| backend.jvm.options | string | `"-XX:MaxRAMPercentage=75.0 -XX:+UseStringDeduplication"` | JVM flags (e.g. GC, heap sizing). Empty string = JVM defaults. |
| backend.image.registry | string | `""` | Fallback registry prefix for backend image. Overridden by global.image.registry when set. |
| backend.image.repository | string | `"dependencytrack/apiserver"` | Image repository path (without registry prefix) |
| backend.image.digest | string | `"sha256:ee5f27462afa73201a362c0d8e3203b56367ffa059a661e26dedeb83dd92ae6b"` | Optional image digest (e.g., sha256:...) |
| backend.image.pullSecrets | list | `[]` | Image pull secrets for backend pods. Merged with global.imagePullSecrets. |
| backend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| backend.image.tag | string | `"4.14.2-alpine"` | Backend image tag |
| backend.replicas | int | `1` | Number of backend replicas. Dependency-Track 4.x backend does not support HA — keep this at 1. |
| backend.labels | object | `{}` | Additional labels to add to backend workload resources |
| backend.annotations | object | `{}` | Additional annotations to add to backend workload resources |
| backend.podLabels | object | `{}` | Additional labels to add to backend pods |
| backend.podAnnotations | object | `{}` | Additional annotations to add to backend pods |
| backend.extraVolumes | list | `[]` | Additional volumes for backend pod (e.g., mount custom CA bundle) |
| backend.extraVolumeMounts | list | `[]` | Additional volume mounts for backend container |
| backend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for backend pods |
| backend.ingress.enabled | bool | `false` | Enable Ingress for backend API |
| backend.ingress.className | string | `""` | Ingress class name |
| backend.ingress.annotations | object | `{}` | Ingress annotations |
| backend.ingress.host | string | `""` | Ingress hostname |
| backend.ingress.tls | list | `[]` | TLS configuration |
| backend.livenessProbe.enabled | bool | `true` | Enable liveness probe |
| backend.livenessProbe.path | string | `"/api/version"` | Path for liveness probe |
| backend.livenessProbe.initialDelaySeconds | int | `60` | Initial delay before liveness probe starts |
| backend.livenessProbe.periodSeconds | int | `10` | Period between liveness probe checks |
| backend.livenessProbe.timeoutSeconds | int | `2` | Timeout for liveness probe |
| backend.livenessProbe.successThreshold | int | `1` | Success threshold for liveness probe |
| backend.livenessProbe.failureThreshold | int | `3` | Failure threshold for liveness probe |
| backend.readinessProbe.enabled | bool | `true` | Enable readiness probe |
| backend.readinessProbe.path | string | `"/"` | Path for readiness probe |
| backend.readinessProbe.initialDelaySeconds | int | `60` | Initial delay before readiness probe starts |
| backend.readinessProbe.periodSeconds | int | `10` | Period between readiness probe checks |
| backend.readinessProbe.timeoutSeconds | int | `2` | Timeout for readiness probe |
| backend.readinessProbe.successThreshold | int | `1` | Success threshold for readiness probe |
| backend.readinessProbe.failureThreshold | int | `3` | Failure threshold for readiness probe |
| backend.database | object | See [values.yaml](values.yaml) | PostgreSQL connection configuration. Install PostgreSQL separately, for example with the KvalitetsIT cnpg-cluster chart. |
| backend.database.serviceName | string | `""` | PostgreSQL service name used for auto-generating the in-cluster host. Required. |
| backend.database.namespace | string | `""` | Namespace of the PostgreSQL service. Defaults to the release namespace. |
| backend.database.port | int | `5432` | PostgreSQL port |
| backend.database.name | string | `"dtrack"` | Database name |
| backend.database.usernameSecret.name | string | `"dtrack-postgres-user-secret"` | Secret name containing PostgreSQL username |
| backend.database.usernameSecret.key | string | `"username"` | Key within secret containing PostgreSQL username |
| backend.database.passwordSecret.name | string | `"dtrack-postgres-user-secret"` | Secret name containing PostgreSQL password |
| backend.database.passwordSecret.key | string | `"password"` | Key within secret containing PostgreSQL password |
| backend.secretKeySecret.name | string | `""` | Secret name containing secret.key |
| backend.service.labels."istio.io/use-waypoint" | string | `"waypoint"` | Route traffic through the Istio waypoint proxy for L7 policy enforcement. |
| backend.service.labels."istio.io/ingress-use-waypoint" | string | `"true"` | Apply waypoint enforcement to ingress traffic only (not east-west mesh traffic). |
| backend.serviceAccount.create | bool | `false` | Create service account for backend |
| backend.serviceAccount.name | string | `""` | Existing ServiceAccount name to use, or generated when create=true |
| backend.serviceAccount.annotations | object | `{}` | Annotations for backend service account |
| backend.serviceAccount.automountServiceAccountToken | bool | `false` | Mount the ServiceAccount token into backend pods |
| backend.serviceMonitor.enabled | bool | `false` | When true, add a netpol rule allowing Prometheus to scrape metrics |
| backend.persistentVolumeClaimRetentionPolicy | string | `nil` | StatefulSet PVC retention policy. Set to null to omit the field and retain PVCs. |
| backend.persistence.accessModes | list | `["ReadWriteOnce"]` | Access modes for persistent volume |
| backend.persistence.resources | object | `{"requests":{"storage":"10Gi"}}` | PersistentVolumeClaim resource requests |
| backend.persistence.storageClassName | string | `""` | Storage class for persistent volume. Empty string omits the field. |
| backend.persistence.existingClaim | string | `""` | Use existing PVC claim |
| backend.truststore.enabled | bool | `false` | Enable truststore PVC for CA certificates |
| backend.truststore.storage | string | `"100M"` | Storage size for truststore PVC |
| backend.truststore.storageClassName | string | `""` | Storage class for truststore PVC (optional) |
| backend.truststore.accessMode | string | `"ReadWriteOnce"` | Access mode for truststore PVC |
| backend.truststore.mountPath | string | `"/opt/java/openjdk/lib/security"` | Mount path for truststore PVC |
| backend.truststore.ca.enabled | bool | `false` | Create ConfigMap with root CA certificate |
| backend.truststore.ca.cert | string | `""` | Root CA certificate content (PEM format) |
| backend.pool.maxSize | int | `20` | Maximum number of database connections (idle + in-use) |
| backend.pool.minIdle | int | `10` | Minimum number of idle connections maintained in the pool |
| backend.pool.idleTimeout | int | `300000` | Maximum time (ms) a connection can sit idle before being removed |
| backend.pool.maxLifetime | int | `600000` | Maximum lifetime (ms) of a connection in the pool |
| backend.workers.threads | int | `0` | Number of worker threads (0 = auto-detect from CPU cores) |
| backend.workers.threadMultiplier | int | `4` | Multiplier applied to CPU cores when threads=0 |
| backend.datanucleus.cacheLevel2Type | string | `""` | L2 cache reference type ("soft" or "weak"). Empty = DTrack default ("soft"). Use "weak" for large deployments to allow GC reclamation under memory pressure. |
| backend.cors.enabled | bool | `true` | Enable CORS headers in REST responses |
| backend.cors.allowOrigin | string | `""` | Allowed origins (empty string = allow all) |
| backend.cors.allowMethods | string | `"GET, POST, PUT, PATCH, DELETE, OPTIONS"` | Allowed HTTP methods |
| backend.cors.allowHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *"` | Allowed request headers |
| backend.cors.exposeHeaders | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count"` | Headers exposed to the browser |
| backend.cors.allowCredentials | bool | `true` | Allow credentials (cookies, auth headers) |
| backend.cors.maxAge | int | `3600` | Preflight response cache duration in seconds |
| backend.env | list | See [values.yaml](values.yaml) | Environment variables for the backend container |
| backend.extraEnvs | list | `[]` | Additional backend environment variables appended after env |
| backend.envFrom | list | `[]` | Environment variable sources for the backend container |
| backend.extraEnvFrom | list | `[]` | Additional backend environment variable sources appended after envFrom |

### Frontend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| frontend | object | See [values.yaml](values.yaml) | Dependency-Track UI configuration |
| frontend.image.registry | string | `""` | Fallback registry prefix for frontend image. Overridden by global.image.registry when set. |
| frontend.image.repository | string | `"dependencytrack/frontend"` | Image repository path (without registry prefix) |
| frontend.image.digest | string | `"sha256:00560b57a6cfdec3c02a6e02be80fce97029241a9c653e8b83c0b670dff1f3ca"` | Optional image digest (e.g., sha256:...) |
| frontend.image.pullSecrets | list | `[]` | Image pull secrets for frontend pods. Merged with global.imagePullSecrets. |
| frontend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| frontend.image.tag | string | `"4.14.2"` | Frontend image tag |
| frontend.service.labels."istio.io/use-waypoint" | string | `"waypoint"` | Route traffic through the Istio waypoint proxy for L7 policy enforcement. |
| frontend.service.labels."istio.io/ingress-use-waypoint" | string | `"true"` | Apply waypoint enforcement to ingress traffic only (not east-west mesh traffic). |
| frontend.replicas | int | `1` | Number of frontend replicas |
| frontend.labels | object | `{}` | Additional labels to add to frontend workload resources |
| frontend.annotations | object | `{}` | Additional annotations to add to frontend workload resources |
| frontend.podLabels | object | `{}` | Additional labels to add to frontend pods |
| frontend.podAnnotations | object | `{}` | Additional annotations to add to frontend pods |
| frontend.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for frontend pods |
| frontend.ingress.enabled | bool | `false` | Enable Ingress for frontend UI |
| frontend.ingress.className | string | `""` | Ingress class name |
| frontend.ingress.annotations | object | `{}` | Ingress annotations |
| frontend.ingress.host | string | `""` | Ingress hostname |
| frontend.ingress.tls | list | `[]` | TLS configuration |
| frontend.apiBaseUrl | string | `""` | API base URL exposed to browser clients. If empty, auto-generates from backend ingress or service |
| frontend.env | list | `[]` | Environment variables for the frontend container |
| frontend.extraEnvs | list | `[]` | Additional frontend environment variables appended after env |
| frontend.envFrom | list | `[]` | Environment variable sources for the frontend container |
| frontend.extraEnvFrom | list | `[]` | Additional frontend environment variable sources appended after envFrom |

### Trivy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| trivy | object | See [values.yaml](values.yaml) | Trivy server configuration (bundled vulnerability scanner) |
| trivy.enabled | bool | `true` | Enable Trivy server deployment |
| trivy.replicas | int | `1` | Number of Trivy replicas |
| trivy.labels | object | `{}` | Additional labels to add to Trivy workload resources |
| trivy.annotations | object | `{}` | Additional annotations to add to Trivy workload resources |
| trivy.image.registry | string | `"ghcr.io"` | Fallback registry prefix for Trivy image. Overridden by global.image.registry when set. |
| trivy.image.repository | string | `"aquasecurity/trivy"` | Image repository path (without registry prefix) |
| trivy.image.digest | string | `"sha256:016eae51fdcf989332a5404af7e8f625cd5d95d7c0907a221d080a996f556500"` | Optional image digest (e.g., sha256:...) |
| trivy.image.tag | string | `"0.71.0"` | Trivy image tag |
| trivy.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| trivy.image.pullSecrets | list | `[]` | Image pull secrets for Trivy pods. Merged with global.imagePullSecrets. |
| trivy.persistence.enabled | bool | `true` | Enable persistence for Trivy cache |
| trivy.persistence.storageClassName | string | `""` | Storage class for Trivy persistent volume. Empty string omits the field. |
| trivy.persistence.accessModes | list | `["ReadWriteOnce"]` | Access modes for Trivy persistent volume |
| trivy.persistence.resources | object | `{"requests":{"storage":"5Gi"}}` | PersistentVolumeClaim resource requests |
| trivy.resources | object | See [values.yaml](values.yaml) | Resource requests and limits for Trivy pods |
| trivy.resources.requests.cpu | string | `"200m"` | CPU request for Trivy pods |
| trivy.resources.requests.memory | string | `"512Mi"` | Memory request for Trivy pods |
| trivy.resources.limits.cpu | int | `1` | CPU limit for Trivy pods |
| trivy.resources.limits.memory | string | `"1Gi"` | Memory limit for Trivy pods |
| trivy.podSecurityContext.runAsUser | int | `65534` | User ID to run Trivy pods |
| trivy.podSecurityContext.runAsNonRoot | bool | `true` | Enforce non-root user for Trivy pods |
| trivy.podSecurityContext.fsGroup | int | `65534` | File system group for Trivy pods |
| trivy.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` | Seccomp profile type for Trivy pods |
| trivy.securityContext.privileged | bool | `false` | Run Trivy container in privileged mode |
| trivy.securityContext.readOnlyRootFilesystem | bool | `true` | Enforce read-only root filesystem for Trivy container |
| trivy.securityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation for Trivy container |
| trivy.securityContext.capabilities.drop | list | `["ALL"]` | Capabilities to drop for Trivy container |
| trivy.nodeSelector | object | `{}` | Node selector for Trivy pods |
| trivy.affinity | object | `{}` | Affinity settings for Trivy pods |
| trivy.tolerations | list | `[]` | Tolerations for Trivy pods |
| trivy.podAnnotations | object | `{}` | Annotations for Trivy pods |
| trivy.config.debugMode | bool | `false` | Enable debug mode for Trivy |
| trivy.config.githubTokenSecret.name | string | `""` | Secret name containing GitHub token for Trivy |
| trivy.config.githubTokenSecret.key | string | `""` | Key within secret containing GitHub token for Trivy |
| trivy.config.tokenSecret.name | string | `""` | Secret name containing Trivy API token |
| trivy.config.tokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| trivy.config.registryUsernameSecret.name | string | `""` | Secret name containing registry username for Trivy |
| trivy.config.registryUsernameSecret.key | string | `""` | Key within secret containing registry username for Trivy |
| trivy.config.registryPasswordSecret.name | string | `""` | Secret name containing registry password for Trivy |
| trivy.config.registryPasswordSecret.key | string | `""` | Key within secret containing registry password for Trivy |
| trivy.config.skipDBUpdate | bool | `false` | Skip database update on Trivy startup |
| trivy.config.dbRepository | string | `"ghcr.io/aquasecurity/trivy-db"` | Trivy database repository |
| trivy.config.httpProxy | string | `""` | HTTP proxy for Trivy |
| trivy.config.httpsProxy | string | `""` | HTTPS proxy for Trivy |
| trivy.config.noProxy | string | `""` | No proxy settings for Trivy |
| trivy.cache.redis.enabled | bool | `false` | Enable Redis cache for Trivy |
| trivy.cache.redis.url | string | `""` | Redis URL for Trivy cache |
| trivy.cache.redis.ttl | string | `""` | Time-to-live for Redis cache entries |
| trivy.cache.redis.tls | bool | `false` | Enable TLS for Redis connection |
| trivy.probes.liveness.initialDelaySeconds | int | `5` | Initial delay before liveness probe starts |
| trivy.probes.liveness.periodSeconds | int | `10` | Period between liveness probe checks |
| trivy.probes.liveness.successThreshold | int | `1` | Success threshold for liveness probe |
| trivy.probes.liveness.failureThreshold | int | `10` | Failure threshold for liveness probe |
| trivy.probes.readiness.initialDelaySeconds | int | `5` | Initial delay before readiness probe starts |
| trivy.probes.readiness.periodSeconds | int | `10` | Period between readiness probe checks |
| trivy.probes.readiness.successThreshold | int | `1` | Success threshold for readiness probe |
| trivy.probes.readiness.failureThreshold | int | `3` | Failure threshold for readiness probe |
| trivy.serviceAccount.create | bool | `false` | Create a dedicated service account for Trivy |
| trivy.serviceAccount.name | string | `""` | Existing ServiceAccount name to use, or generated when create=true |
| trivy.serviceAccount.annotations | object | `{}` | Annotations for Trivy service account |
| trivy.serviceAccount.automountServiceAccountToken | bool | `false` | Mount the ServiceAccount token into Trivy pods |
| trivy.env | list | `[]` | Environment variables for the Trivy container |
| trivy.extraEnvs | list | `[]` | Additional Trivy environment variables appended after env |
| trivy.envFrom | list | `[]` | Environment variable sources for the Trivy container |
| trivy.extraEnvFrom | list | `[]` | Additional Trivy environment variable sources appended after envFrom |

### Network Policies

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| networkPolicies | object | See [values.yaml](values.yaml) | Map of Kubernetes NetworkPolicy resources. K8s-only entries (no matching ciliumNetworkPolicies key) are always rendered. Entries that share a key with ciliumNetworkPolicies act as fallbacks on non-Cilium clusters. |
| ciliumNetworkPolicies | object | See [values.yaml](values.yaml) | Map of CiliumNetworkPolicy resources. Rendered only when cilium.io/v2 is available. Entries sharing a key with networkPolicies fall back to K8s NetworkPolicy on non-Cilium clusters. |
| templates | object | `{}` | Configuration for the KvalitetsIT templates library chart (https://github.com/KvalitetsIT/helm-templates-chart). Use templates.sealedSecrets, templates.resources, etc. to render additional resources via the library. |

### Gateway Routes

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| gateway-routes | object | See values.yaml | Configuration for the KvalitetsIT gateway-routes chart (https://github.com/KvalitetsIT/helm-gateway-routes-chart). Declares HTTPRoute and ListenerSet resources against an existing Istio gateway. |
| gateway-routes.routes.backend.httpRoute | object | `{"hostnames":[]}` | HTTPRoute config for the backend API |
| gateway-routes.routes.backend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack-api.example.com]) |
| gateway-routes.routes.frontend.httpRoute | object | `{"hostnames":[]}` | HTTPRoute config for the frontend UI |
| gateway-routes.routes.frontend.httpRoute.hostnames | list | `[]` | Hostnames to expose (e.g. [dtrack.example.com]) |
