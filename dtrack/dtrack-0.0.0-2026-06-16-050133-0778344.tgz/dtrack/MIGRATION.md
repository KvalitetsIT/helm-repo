# dtrack chart values migration prompt

Use this prompt with an LLM to migrate downstream values files for the chart cleanup PR:

```text
Update my dtrack Helm values for the breaking chart cleanup.

Rename replica keys everywhere:
- backend.replicaCount -> backend.replicas
- frontend.replicaCount -> frontend.replicas
- trivy.replicaCount -> trivy.replicas

Migrate backend database configuration:
- backend.postgresql.database -> backend.database.name
- backend.postgresql.serviceName -> backend.database.serviceName
- backend.postgresql.namespace -> backend.database.namespace
- backend.postgresql.port -> backend.database.port
- backend.postgresql.passwordSecret -> backend.database.passwordSecret
- backend.postgresql.usernameSecret -> backend.database.usernameSecret

Remove keys that no longer exist:
- backend.postgresql.enabled (PostgreSQL is always configured by backend.database)
- backend.postgresql.host (use backend.database.serviceName and backend.database.namespace)
- backend.postgresql.connectionName
- backend.postgresql.ip
- backend.secretKeySecret.key (the Secret key must be named secret.key)
- bootstrap.endpoints.frontend.url (use bootstrap.frontendBaseUrl instead)
- fullnameOverride (use nameOverride only if a custom release/name base is required)
- trivy.nameOverride
- trivy.fullnameOverride
- trivy.extraLabels
- trivy.extraEnvVars (use trivy.extraEnvs)
- frontend.swagger.*

Rename/fix documented-but-wrong keys if present:
- global.imageRegistry -> global.image.registry

Review bootstrap wait-for-backend image settings:
- bootstrap.waitForBackend.image is now an image object. Move an old string value into bootstrap.waitForBackend.image.repository/tag or set registry/repository/tag/digest explicitly.

Review persistence behavior:
- backend PVC retention is now safer by default. If I previously relied on automatic PVC deletion, add backend.persistentVolumeClaimRetentionPolicy explicitly.
- Convert persistence accessMode fields to accessModes lists.
- Convert persistence size fields to resources.requests.storage.

Review environment variables:
- Convert backend.env and frontend.env maps to env lists with name/value entries.
- Use extraEnvs for overlay-only additions where needed.
- Move envFrom-style references to envFrom/extraEnvFrom lists if present.

Review resource names and route backendRefs:
- backend/frontend resource names are now release-qualified. If I override gateway-routes backendRefs manually, update them to the rendered backend/frontend Service names for my release.

Preserve unrelated values. Do not add compatibility aliases. Remove old keys after migrating their values.
```
