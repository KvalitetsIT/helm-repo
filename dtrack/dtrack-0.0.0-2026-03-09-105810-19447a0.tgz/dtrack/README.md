# DependencyTrack Helm Chart

![Version: 0.6.0](https://img.shields.io/badge/Version-0.6.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

This chart deploys OWASP Dependency-Track (backend API server and frontend UI), plus optional bootstrap job
for initial provisioning (users, teams, OIDC groups) and an optional Trivy vulnerability scanning service.

## Values

### Global Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global | object | `{"commonAnnotations":{},"egress":{"repositories":["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"],"vulnerabilityDatabases":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]},"networkPolicy":{"defaultDenyAll":true}}` | Global configuration options |
| global.commonAnnotations | object | `{}` | Common annotations to add to all resources |
| global.networkPolicy | object | `{"defaultDenyAll":true}` | Global network policy configuration |
| global.networkPolicy.defaultDenyAll | bool | `true` | Enable default deny network policy (requires Cilium CNI) |
| global.egress | object | `{"repositories":["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"],"vulnerabilityDatabases":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]}` | Global egress configuration for network policies |
| global.egress.repositories | list | `["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net","reg.kyverno.io"]` | Package repositories available to all components (can be overridden per component) |
| global.egress.vulnerabilityDatabases | list | `["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]` | Vulnerability databases available to all components (can be overridden per component) |

### Bootstrap Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| bootstrap | object | `{"adminPasswordSecret":{"key":"admin-password","name":"dtrack-bootstrap"},"baseUrl":"","defaultAdminPassword":"admin","enabled":true,"frontendBaseUrl":"","github":{"advisoryMirroringTokenSecret":{"key":"","name":""}},"google":{"osv_enabled":true},"groups":[],"image":{"repository":"docker.io/kvalitetsit/dtrack-bootstrap","tag":"yolo"},"logLevel":"INFO","networkPolicy":{"annotations":{},"enabled":true},"nvd":{"apiKeySecret":{"key":"","name":""}},"oss_index":{"tokenSecret":{"key":"","name":""},"username":""},"resources":{"limits":{"cpu":"50m","memory":"512Mi"},"requests":{"cpu":"10m","memory":"128Mi"}},"teams":[],"trivy":{"apiTokenSecret":{"key":"","name":""},"base_url":"","ignore_unfixed":true},"users":[]}` | Bootstrap job configuration for initial Dependency-Track setup (users, teams, groups, integrations) |
| bootstrap.enabled | bool | `true` | Whether to run the bootstrap job (creates users/teams/groups) |
| bootstrap.logLevel | string | `"INFO"` | Log level for bootstrap container (TRACE|DEBUG|INFO|WARN|ERROR) |
| bootstrap.resources.requests | object | `{"cpu":"10m","memory":"128Mi"}` | Resource requests for bootstrap job |
| bootstrap.resources.requests.memory | string | `"128Mi"` | Memory request for bootstrap job |
| bootstrap.resources.requests.cpu | string | `"10m"` | CPU request for bootstrap job |
| bootstrap.resources.limits | object | `{"cpu":"50m","memory":"512Mi"}` | Resource limits for bootstrap job |
| bootstrap.resources.limits.memory | string | `"512Mi"` | Memory limit for bootstrap job |
| bootstrap.resources.limits.cpu | string | `"50m"` | CPU limit for bootstrap job |
| bootstrap.image | object | `{"repository":"docker.io/kvalitetsit/dtrack-bootstrap","tag":"yolo"}` | Bootstrap job image configuration |
| bootstrap.image.repository | string | `"docker.io/kvalitetsit/dtrack-bootstrap"` | OCI repository with image name (e.g., docker.io/kvalitetsit/dtrack-bootstrap) |
| bootstrap.image.tag | string | `"yolo"` | Image tag (overwritten automatically by CI on release) |
| bootstrap.networkPolicy | object | `{"annotations":{},"enabled":true}` | Network policy configuration for bootstrap job |
| bootstrap.networkPolicy.enabled | bool | `true` | Enable network policy for bootstrap job |
| bootstrap.networkPolicy.annotations | object | `{}` | Annotations for bootstrap network policy |
| bootstrap.baseUrl | string | `""` | Backend API base URL (must point to Dependency-Track /api endpoint). If empty, auto-generates based on release name. |
| bootstrap.frontendBaseUrl | string | `""` | Frontend base URL for UI links (optional) |
| bootstrap.defaultAdminPassword | string | `"admin"` | Default admin password expected in a fresh install (used to rotate to adminPasswordSecret) |
| bootstrap.adminPasswordSecret | object | `{"key":"admin-password","name":"dtrack-bootstrap"}` | Secret containing new admin password |
| bootstrap.adminPasswordSecret.name | string | `"dtrack-bootstrap"` | Secret name containing admin password |
| bootstrap.adminPasswordSecret.key | string | `"admin-password"` | Key within secret containing admin password |
| bootstrap.github | object | `{"advisoryMirroringTokenSecret":{"key":"","name":""}}` | GitHub advisory mirroring configuration |
| bootstrap.github.advisoryMirroringTokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub advisory token |
| bootstrap.github.advisoryMirroringTokenSecret.name | string | `""` | Secret name containing GitHub token |
| bootstrap.github.advisoryMirroringTokenSecret.key | string | `""` | Key within secret containing GitHub token |
| bootstrap.google | object | `{"osv_enabled":true}` | Google OSV configuration |
| bootstrap.google.osv_enabled | bool | `true` | Enable Google OSV ingestion (set false to disable) |
| bootstrap.users | list | `[]` | List of admin users to create (AdminUser objects) |
| bootstrap.teams | list | `[]` | List of team definitions to create |
| bootstrap.groups | list | `[]` | List of OIDC group mappings to create |
| bootstrap.trivy | object | `{"apiTokenSecret":{"key":"","name":""},"base_url":"","ignore_unfixed":true}` | Trivy integration configuration |
| bootstrap.trivy.ignore_unfixed | bool | `true` | Ignore unfixed vulnerabilities when enabling Trivy integration |
| bootstrap.trivy.apiTokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| bootstrap.trivy.apiTokenSecret.name | string | `""` | Secret name containing Trivy API token |
| bootstrap.trivy.apiTokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| bootstrap.trivy.base_url | string | `""` | Base URL of Trivy server. If empty and trivy.enabled is true, auto-generates based on release name. |
| bootstrap.oss_index | object | `{"tokenSecret":{"key":"","name":""},"username":""}` | Sonatype OSS Index integration settings |
| bootstrap.oss_index.username | string | `""` | OSS Index username |
| bootstrap.oss_index.tokenSecret | object | `{"key":"","name":""}` | Secret reference for OSS Index token |
| bootstrap.oss_index.tokenSecret.name | string | `""` | Secret name containing OSS Index token |
| bootstrap.oss_index.tokenSecret.key | string | `""` | Key within secret containing OSS Index token |
| bootstrap.nvd.apiKeySecret | object | `{"key":"","name":""}` | Secret reference for NVD API key |
| bootstrap.nvd.apiKeySecret.name | string | `""` | Secret name containing NVD API key |
| bootstrap.nvd.apiKeySecret.key | string | `""` | Key within secret containing NVD API key |

### Backend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backend | object | `{"env":{"ALPINE_CORS_ALLOW_CREDENTIALS":true,"ALPINE_CORS_ALLOW_HEADERS":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *","ALPINE_CORS_ALLOW_METHODS":"GET, POST, PUT, PATCH, DELETE, OPTIONS","ALPINE_CORS_ALLOW_ORIGIN":"","ALPINE_CORS_ENABLED":true,"ALPINE_CORS_EXPOSE_HEADERS":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count","ALPINE_CORS_MAX_AGE":3600,"ALPINE_METRICS_ENABLED":true,"ALPINE_OIDC_CLIENT_ID":"","ALPINE_OIDC_ENABLED":true,"ALPINE_OIDC_ISSUER":"","ALPINE_OIDC_USERNAME_CLAIM":"email","ALPINE_OIDC_USER_PROVISIONING":true,"LOGGING_CONFIG_PATH":"logback-json.xml","TELEMETRY_SUBMISSION_ENABLED_DEFAULT":false},"extraVolumeMounts":[],"extraVolumes":[],"image":{"pullPolicy":"IfNotPresent","repository":"dependencytrack/apiserver","tag":"4.13.6"},"ingress":{"annotations":{},"className":"","enabled":true,"host":"","tls":[]},"livenessProbe":{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/api/version","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2},"logLevel":"INFO","networkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[],"postgresql":{"matchLabels":{},"namespace":""},"repositories":["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"],"vulnerabilityDatabases":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]},"persistence":{"accessMode":"ReadWriteOnce","enableStatefulSetAutoDeletePVC":true,"existingClaim":"","size":"10Gi","storageClass":"standard","whenDeleted":"Delete","whenScaled":"Delete"},"podAnnotations":{},"podLabels":{},"postgresql":{"connectionName":"","database":"dependencytrack","enabled":true,"host":"","ip":"","passwordSecret":{"key":"postgresql-password","name":"dtrack-backend"},"port":5432,"serviceName":"postgresql","usernameSecret":{"key":"postgresql-username","name":"dtrack-backend"}},"readinessProbe":{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2},"replicaCount":2,"resources":{"limits":{"cpu":"2","memory":"8Gi"},"requests":{"cpu":"1","memory":"4Gi"}},"secretKeySecret":{"key":"secret.key","name":""},"serviceAccount":{"create":true},"serviceMonitor":{"enabled":false,"matchLabels":{},"namespace":"infrastructure","port":8000},"truststore":{"accessMode":"ReadWriteMany","ca":{"cert":"","enabled":false},"enabled":false,"mountPath":"/opt/java/openjdk/lib/security","storage":"1Gi","storageClassName":""}}` | Dependency-Track API server configuration |
| backend.logLevel | string | `"INFO"` | Backend log level |
| backend.image | object | `{"pullPolicy":"IfNotPresent","repository":"dependencytrack/apiserver","tag":"4.13.6"}` | Backend container image configuration |
| backend.image.repository | string | `"dependencytrack/apiserver"` | Backend image repository with name (e.g., dependencytrack/apiserver) |
| backend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| backend.image.tag | string | `"4.13.6"` | Overrides the image tag whose default is the chart appVersion |
| backend.replicaCount | int | `2` | Number of backend replicas |
| backend.podLabels | object | `{}` | Additional labels to add to backend pods |
| backend.podAnnotations | object | `{}` | Additional annotations to add to backend pods |
| backend.extraVolumes | list | `[]` | Additional volumes for backend pod (e.g., mount custom CA bundle) |
| backend.extraVolumeMounts | list | `[]` | Additional volume mounts for backend container |
| backend.resources | object | `{"limits":{"cpu":"2","memory":"8Gi"},"requests":{"cpu":"1","memory":"4Gi"}}` | Resource requests and limits for backend pods |
| backend.resources.requests | object | `{"cpu":"1","memory":"4Gi"}` | Resource requests for backend pods |
| backend.resources.requests.memory | string | `"4Gi"` | Memory request for backend pods |
| backend.resources.requests.cpu | string | `"1"` | CPU request for backend pods |
| backend.resources.limits | object | `{"cpu":"2","memory":"8Gi"}` | Resource limits for backend pods |
| backend.resources.limits.memory | string | `"8Gi"` | Memory limit for backend pods |
| backend.resources.limits.cpu | string | `"2"` | CPU limit for backend pods |
| backend.networkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[],"postgresql":{"matchLabels":{},"namespace":""},"repositories":["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"],"vulnerabilityDatabases":["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]}` | Network policy configuration for backend |
| backend.networkPolicy.enabled | bool | `true` | Enable network policy for backend |
| backend.networkPolicy.annotations | object | `{}` | Annotations for backend network policy |
| backend.networkPolicy.ingress | list | `[]` | Ingress rules for backend network policy |
| backend.networkPolicy.egress | list | `[]` | Egress rules for backend network policy |
| backend.networkPolicy.postgresql | object | `{"matchLabels":{},"namespace":""}` | Egress rules for backend to access PostgreSQL |
| backend.networkPolicy.postgresql.namespace | string | `""` | Namespace of PostgreSQL service |
| backend.networkPolicy.postgresql.matchLabels | object | `{}` | Match labels for PostgreSQL service |
| backend.networkPolicy.repositories | list | `["*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"]` | Egress rules for backend to access package repositories |
| backend.networkPolicy.vulnerabilityDatabases | list | `["osv-vulnerabilities.storage.googleapis.com","api.github.com","nvd.nist.gov","epss.cyentia.com","epss.empiricalsecurity.com"]` | Egress rules for backend to access vulnerability databases |
| backend.ingress | object | `{"annotations":{},"className":"","enabled":true,"host":"","tls":[]}` | Ingress configuration for backend API |
| backend.ingress.enabled | bool | `true` | Enable ingress for backend |
| backend.ingress.className | string | `""` | Ingress class name |
| backend.ingress.annotations | object | `{}` | Ingress annotations |
| backend.ingress.host | string | `""` | Ingress hostname |
| backend.ingress.tls | list | `[]` | TLS configuration |
| backend.livenessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/api/version","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Liveness probe configuration |
| backend.livenessProbe.enabled | bool | `true` | Enable liveness probe |
| backend.livenessProbe.path | string | `"/api/version"` | Path for liveness probe |
| backend.livenessProbe.initialDelaySeconds | int | `60` | Initial delay before liveness probe starts |
| backend.livenessProbe.periodSeconds | int | `10` | Period between liveness probe checks |
| backend.livenessProbe.timeoutSeconds | int | `2` | Timeout for liveness probe |
| backend.livenessProbe.successThreshold | int | `1` | Success threshold for liveness probe |
| backend.livenessProbe.failureThreshold | int | `3` | Failure threshold for liveness probe |
| backend.readinessProbe | object | `{"enabled":true,"failureThreshold":3,"initialDelaySeconds":60,"path":"/","periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Readiness probe configuration |
| backend.readinessProbe.enabled | bool | `true` | Enable readiness probe |
| backend.readinessProbe.path | string | `"/"` | Path for readiness probe |
| backend.readinessProbe.initialDelaySeconds | int | `60` | Initial delay before readiness probe starts |
| backend.readinessProbe.periodSeconds | int | `10` | Period between readiness probe checks |
| backend.readinessProbe.timeoutSeconds | int | `2` | Timeout for readiness probe |
| backend.readinessProbe.successThreshold | int | `1` | Success threshold for readiness probe |
| backend.readinessProbe.failureThreshold | int | `3` | Failure threshold for readiness probe |
| backend.postgresql | object | `{"connectionName":"","database":"dependencytrack","enabled":true,"host":"","ip":"","passwordSecret":{"key":"postgresql-password","name":"dtrack-backend"},"port":5432,"serviceName":"postgresql","usernameSecret":{"key":"postgresql-username","name":"dtrack-backend"}}` | PostgreSQL database configuration |
| backend.postgresql.enabled | bool | `true` | Enable PostgreSQL for backend |
| backend.postgresql.database | string | `"dependencytrack"` | Database name |
| backend.postgresql.serviceName | string | `"postgresql"` | PostgreSQL service name (used for auto-generating host if not set) |
| backend.postgresql.passwordSecret | object | `{"key":"postgresql-password","name":"dtrack-backend"}` | Secret reference for PostgreSQL password |
| backend.postgresql.passwordSecret.name | string | `"dtrack-backend"` | Secret name containing PostgreSQL password |
| backend.postgresql.passwordSecret.key | string | `"postgresql-password"` | Key within secret containing PostgreSQL password |
| backend.postgresql.usernameSecret | object | `{"key":"postgresql-username","name":"dtrack-backend"}` | Secret reference for PostgreSQL username |
| backend.postgresql.usernameSecret.name | string | `"dtrack-backend"` | Secret name containing PostgreSQL username |
| backend.postgresql.usernameSecret.key | string | `"postgresql-username"` | Key within secret containing PostgreSQL username |
| backend.postgresql.host | string | `""` | PostgreSQL host. If empty, auto-generates FQDN based on serviceName and namespace. |
| backend.postgresql.port | int | `5432` | PostgreSQL port |
| backend.postgresql.connectionName | string | `""` | Cloud SQL connection name (for GCP) |
| backend.postgresql.ip | string | `""` | PostgreSQL IP address |
| backend.secretKeySecret | object | `{"key":"secret.key","name":""}` | Secret providing Alpine secret.key content (required for deterministic encryption) |
| backend.secretKeySecret.name | string | `""` | Secret name containing secret.key |
| backend.secretKeySecret.key | string | `"secret.key"` | Key within secret containing secret.key content |
| backend.serviceAccount | object | `{"create":true}` | Service account configuration |
| backend.serviceAccount.create | bool | `true` | Create service account for backend |
| backend.serviceMonitor | object | `{"enabled":false,"matchLabels":{},"namespace":"infrastructure","port":8000}` | Backend ServiceMonitor configuration (used by Prometheus) |
| backend.serviceMonitor.enabled | bool | `false` | When true, add a netpol rule allowing Prometheus to scrape metrics |
| backend.serviceMonitor.namespace | string | `"infrastructure"` | Namespace where Prometheus pods run |
| backend.serviceMonitor.matchLabels | object | `{}` | Match labels for Prometheus pod selector (optional) |
| backend.serviceMonitor.port | int | `8000` | Port to allow for Prometheus scraping (default: metrics port) |
| backend.persistence | object | `{"accessMode":"ReadWriteOnce","enableStatefulSetAutoDeletePVC":true,"existingClaim":"","size":"10Gi","storageClass":"standard","whenDeleted":"Delete","whenScaled":"Delete"}` | Persistence configuration for backend storage |
| backend.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for persistent volume |
| backend.persistence.size | string | `"10Gi"` | Size of persistent volume |
| backend.persistence.storageClass | string | `"standard"` | Storage class for persistent volume |
| backend.persistence.existingClaim | string | `""` | Use existing PVC claim |
| backend.persistence.enableStatefulSetAutoDeletePVC | bool | `true` | Enable automatic PVC deletion in StatefulSet |
| backend.persistence.whenDeleted | string | `"Delete"` | PVC retention policy when StatefulSet is deleted |
| backend.persistence.whenScaled | string | `"Delete"` | PVC retention policy when StatefulSet is scaled down |
| backend.truststore | object | `{"accessMode":"ReadWriteMany","ca":{"cert":"","enabled":false},"enabled":false,"mountPath":"/opt/java/openjdk/lib/security","storage":"1Gi","storageClassName":""}` | Truststore configuration for CA certificates |
| backend.truststore.enabled | bool | `false` | Enable truststore PVC for CA certificates |
| backend.truststore.storage | string | `"1Gi"` | Storage size for truststore PVC |
| backend.truststore.storageClassName | string | `""` | Storage class for truststore PVC (optional) |
| backend.truststore.mountPath | string | `"/opt/java/openjdk/lib/security"` | Mount path for truststore PVC |
| backend.truststore.ca | object | `{"cert":"","enabled":false}` | Root CA certificate configuration |
| backend.truststore.ca.enabled | bool | `false` | Create ConfigMap with root CA certificate |
| backend.truststore.ca.cert | string | `""` | Root CA certificate content (PEM format) |
| backend.env | object | `{"ALPINE_CORS_ALLOW_CREDENTIALS":true,"ALPINE_CORS_ALLOW_HEADERS":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *","ALPINE_CORS_ALLOW_METHODS":"GET, POST, PUT, PATCH, DELETE, OPTIONS","ALPINE_CORS_ALLOW_ORIGIN":"","ALPINE_CORS_ENABLED":true,"ALPINE_CORS_EXPOSE_HEADERS":"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count","ALPINE_CORS_MAX_AGE":3600,"ALPINE_METRICS_ENABLED":true,"ALPINE_OIDC_CLIENT_ID":"","ALPINE_OIDC_ENABLED":true,"ALPINE_OIDC_ISSUER":"","ALPINE_OIDC_USERNAME_CLAIM":"email","ALPINE_OIDC_USER_PROVISIONING":true,"LOGGING_CONFIG_PATH":"logback-json.xml","TELEMETRY_SUBMISSION_ENABLED_DEFAULT":false}` | Environment variables for backend container |
| backend.env.ALPINE_OIDC_ENABLED | bool | `true` | Enable OIDC authentication |
| backend.env.ALPINE_OIDC_ISSUER | string | `""` | OIDC issuer URL |
| backend.env.ALPINE_OIDC_CLIENT_ID | string | `""` | OIDC client ID |
| backend.env.ALPINE_OIDC_USERNAME_CLAIM | string | `"email"` | OIDC username claim |
| backend.env.ALPINE_OIDC_USER_PROVISIONING | bool | `true` | Enable OIDC user provisioning |
| backend.env.ALPINE_CORS_ENABLED | bool | `true` | Enable CORS |
| backend.env.ALPINE_CORS_ALLOW_ORIGIN | string | `""` | CORS allowed origins |
| backend.env.ALPINE_CORS_ALLOW_METHODS | string | `"GET, POST, PUT, PATCH, DELETE, OPTIONS"` | CORS allowed methods |
| backend.env.ALPINE_CORS_ALLOW_HEADERS | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count, *"` | CORS allowed headers |
| backend.env.ALPINE_CORS_EXPOSE_HEADERS | string | `"Origin, Content-Type, Authorization, X-Requested-With, Content-Length, Accept, Origin, X-Api-Key, X-Total-Count"` | CORS exposed headers |
| backend.env.ALPINE_CORS_ALLOW_CREDENTIALS | bool | `true` | CORS allow credentials |
| backend.env.ALPINE_CORS_MAX_AGE | int | `3600` | CORS max age |
| backend.env.ALPINE_METRICS_ENABLED | bool | `true` | Enable metrics endpoint |
| backend.env.LOGGING_CONFIG_PATH | string | `"logback-json.xml"` | Logging configuration path |
| backend.env.TELEMETRY_SUBMISSION_ENABLED_DEFAULT | bool | `false` | Default telemetry submission setting |

### Frontend Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| frontend | object | `{"env":{"API_BASE_URL":"","OIDC_CLIENT_ID":"","OIDC_ISSUER":""},"image":{"pullPolicy":"IfNotPresent","repository":"dependencytrack/frontend","tag":"4.13.6"},"ingress":{"annotations":{},"className":"","enabled":true,"host":"","tls":[]},"networkPolicy":{"annotations":{},"egress":[],"enabled":true,"ingress":[]},"podAnnotations":{},"podLabels":{},"replicaCount":1,"resources":{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"128m","memory":"256Mi"}},"swagger":{"enabled":false,"path":"/swagger","port":8181}}` | Dependency-Track UI configuration |
| frontend.swagger | object | `{"enabled":false,"path":"/swagger","port":8181}` | Swagger UI configuration |
| frontend.swagger.enabled | bool | `false` | Enable Swagger UI |
| frontend.swagger.path | string | `"/swagger"` | Swagger UI path |
| frontend.swagger.port | int | `8181` | Swagger UI port |
| frontend.image | object | `{"pullPolicy":"IfNotPresent","repository":"dependencytrack/frontend","tag":"4.13.6"}` | Frontend container image configuration |
| frontend.image.repository | string | `"dependencytrack/frontend"` | Frontend image repository with name (e.g., dependencytrack/frontend) |
| frontend.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| frontend.image.tag | string | `"4.13.6"` | Overrides the image tag whose default is the chart appVersion |
| frontend.replicaCount | int | `1` | Number of frontend replicas |
| frontend.podLabels | object | `{}` | Additional labels to add to frontend pods |
| frontend.podAnnotations | object | `{}` | Additional annotations to add to frontend pods |
| frontend.resources | object | `{"limits":{"cpu":"1","memory":"512Mi"},"requests":{"cpu":"128m","memory":"256Mi"}}` | Resource requests and limits for frontend pods |
| frontend.resources.requests | object | `{"cpu":"128m","memory":"256Mi"}` | Resource requests for frontend pods |
| frontend.resources.requests.memory | string | `"256Mi"` | Memory request for frontend pods |
| frontend.resources.requests.cpu | string | `"128m"` | CPU request for frontend pods |
| frontend.resources.limits | object | `{"cpu":"1","memory":"512Mi"}` | Resource limits for frontend pods |
| frontend.resources.limits.memory | string | `"512Mi"` | Memory limit for frontend pods |
| frontend.resources.limits.cpu | string | `"1"` | CPU limit for frontend pods |
| frontend.networkPolicy | object | `{"annotations":{},"egress":[],"enabled":true,"ingress":[]}` | Network policy configuration for frontend |
| frontend.networkPolicy.enabled | bool | `true` | Enable network policy for frontend |
| frontend.networkPolicy.annotations | object | `{}` | Annotations for frontend network policy |
| frontend.networkPolicy.ingress | list | `[]` | Ingress rules for frontend network policy |
| frontend.networkPolicy.egress | list | `[]` | Egress rules for frontend network policy |
| frontend.ingress | object | `{"annotations":{},"className":"","enabled":true,"host":"","tls":[]}` | Ingress configuration for frontend |
| frontend.ingress.enabled | bool | `true` | Enable ingress for frontend |
| frontend.ingress.className | string | `""` | Ingress class name |
| frontend.ingress.annotations | object | `{}` | Ingress annotations |
| frontend.ingress.host | string | `""` | Ingress hostname |
| frontend.ingress.tls | list | `[]` | TLS configuration |
| frontend.env | object | `{"API_BASE_URL":"","OIDC_CLIENT_ID":"","OIDC_ISSUER":""}` | Environment variables for frontend container |
| frontend.env.API_BASE_URL | string | `""` | Backend API base URL (accessed by browser). If empty, auto-generates based on backend ingress or release name. |
| frontend.env.OIDC_ISSUER | string | `""` | OIDC issuer URL |
| frontend.env.OIDC_CLIENT_ID | string | `""` | OIDC client ID |

### Trivy Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| trivy | object | `{"affinity":{},"cache":{"redis":{"enabled":false,"tls":false,"ttl":"","url":""}},"config":{"dbRepository":"ghcr.io/aquasecurity/trivy-db","debugMode":false,"githubTokenSecret":{"key":"","name":""},"httpProxy":"","httpsProxy":"","noProxy":"","registryPasswordSecret":{"key":"","name":""},"registryUsernameSecret":{"key":"","name":""},"skipDBUpdate":false,"tokenSecret":{"key":"","name":""}},"enabled":true,"extraEnvVars":[],"extraLabels":{},"fullnameOverride":"","image":{"pullPolicy":"IfNotPresent","pullSecret":"","repository":"ghcr.io/aquasecurity/trivy","tag":"0.68.2"},"ingress":{"annotations":{},"enabled":false,"hosts":[{"host":null}],"ingressClassName":null,"path":"/","pathType":"Prefix","tls":[]},"nameOverride":"","networkPolicy":{"annotations":{},"enabled":true,"repositories":["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"]},"nodeSelector":{},"persistence":{"accessMode":"ReadWriteOnce","enabled":true,"size":"5Gi","storageClass":""},"podAnnotations":{},"podSecurityContext":{"fsGroup":65534,"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}},"probes":{"liveness":{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}},"replicaCount":1,"resources":{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"200m","memory":"512Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true},"service":{"name":null,"port":4954,"sessionAffinity":"ClientIP","type":"ClusterIP"},"serviceAccount":{"annotations":{}},"tolerations":[]}` | Trivy server configuration (bundled vulnerability scanner) |
| trivy.enabled | bool | `true` | Enable Trivy server deployment |
| trivy.nameOverride | string | `""` | Override name for Trivy resources |
| trivy.fullnameOverride | string | `""` | Override full name for Trivy resources |
| trivy.replicaCount | int | `1` | Number of Trivy replicas |
| trivy.image | object | `{"pullPolicy":"IfNotPresent","pullSecret":"","repository":"ghcr.io/aquasecurity/trivy","tag":"0.68.2"}` | Trivy container image configuration |
| trivy.image.repository | string | `"ghcr.io/aquasecurity/trivy"` | Trivy image repository with name (e.g., ghcr.io/aquasecurity/trivy) |
| trivy.image.tag | string | `"0.68.2"` | Trivy image tag |
| trivy.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| trivy.image.pullSecret | string | `""` | Image pull secret name |
| trivy.networkPolicy | object | `{"annotations":{},"enabled":true,"repositories":["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"]}` | Network policy configuration for Trivy |
| trivy.networkPolicy.enabled | bool | `true` | Enable network policy for Trivy |
| trivy.networkPolicy.annotations | object | `{}` | Annotations for Trivy network policy |
| trivy.networkPolicy.repositories | list | `["ghcr.io","*.ghcr.io","*.github.com","*.githubassets.com","*.githubusercontent.com","*.pkg.github.com","api.nuget.org","channels.nixos.org","containers.pkg.github.com","crates.io","docker-proxy.pkg.github.com","docker.pkg.github.com","fastapi.metacpan.org","hex.pm","maven.artifacts.atlassian.com","maven.google.com","maven.pkg.github.com","mavenregistryv2prod.blob.core.windows.net","npm-beta-proxy.pkg.github.com","npm-beta.pkg.github.com","npm-proxy.pkg.github.com","npm.pkg.github.com","npmregistryv2prod.blob.core.windows.net","nuget.pkg.github.com","nugetregistryv2prod.blob.core.windows.net","package.haskell.org","packages.atlassian.com","proxy.golang.org","pypi.org","registry.npmjs.org","repo.clojars.org","repo.packagist.org","repo1.maven.org","repository.jboss.org","rubygems.org","rubygems.pkg.github.com","dl.google.com","rubygemsregistryv2prod.blob.core.windows.net"]` | Egress rules for Trivy to access vulnerability repositories |
| trivy.persistence | object | `{"accessMode":"ReadWriteOnce","enabled":true,"size":"5Gi","storageClass":""}` | Persistence configuration for Trivy cache |
| trivy.persistence.enabled | bool | `true` | Enable persistence for Trivy cache |
| trivy.persistence.storageClass | string | `""` | Storage class for Trivy persistent volume |
| trivy.persistence.accessMode | string | `"ReadWriteOnce"` | Access mode for Trivy persistent volume |
| trivy.persistence.size | string | `"5Gi"` | Size of Trivy persistent volume |
| trivy.resources | object | `{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"200m","memory":"512Mi"}}` | Resource requests and limits for Trivy pods |
| trivy.resources.requests | object | `{"cpu":"200m","memory":"512Mi"}` | Resource requests for Trivy pods |
| trivy.resources.requests.cpu | string | `"200m"` | CPU request for Trivy pods |
| trivy.resources.requests.memory | string | `"512Mi"` | Memory request for Trivy pods |
| trivy.resources.limits | object | `{"cpu":1,"memory":"1Gi"}` | Resource limits for Trivy pods |
| trivy.resources.limits.cpu | int | `1` | CPU limit for Trivy pods |
| trivy.resources.limits.memory | string | `"1Gi"` | Memory limit for Trivy pods |
| trivy.podSecurityContext | object | `{"fsGroup":65534,"runAsNonRoot":true,"runAsUser":65534,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context for Trivy pods |
| trivy.podSecurityContext.runAsUser | int | `65534` | User ID to run Trivy pods |
| trivy.podSecurityContext.runAsNonRoot | bool | `true` | Enforce non-root user for Trivy pods |
| trivy.podSecurityContext.fsGroup | int | `65534` | File system group for Trivy pods |
| trivy.podSecurityContext.seccompProfile | object | `{"type":"RuntimeDefault"}` | Seccomp profile for Trivy pods |
| trivy.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` | Seccomp profile type for Trivy pods |
| trivy.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true}` | Container security context for Trivy |
| trivy.securityContext.privileged | bool | `false` | Run Trivy container in privileged mode |
| trivy.securityContext.readOnlyRootFilesystem | bool | `true` | Enforce read-only root filesystem for Trivy container |
| trivy.securityContext.allowPrivilegeEscalation | bool | `false` | Allow privilege escalation for Trivy container |
| trivy.securityContext.capabilities | object | `{"drop":["ALL"]}` | Capabilities for Trivy container |
| trivy.securityContext.capabilities.drop | list | `["ALL"]` | Capabilities to drop for Trivy container |
| trivy.nodeSelector | object | `{}` | Node selector for Trivy pods |
| trivy.affinity | object | `{}` | Affinity settings for Trivy pods |
| trivy.tolerations | list | `[]` | Tolerations for Trivy pods |
| trivy.podAnnotations | object | `{}` | Annotations for Trivy pods |
| trivy.config | object | `{"dbRepository":"ghcr.io/aquasecurity/trivy-db","debugMode":false,"githubTokenSecret":{"key":"","name":""},"httpProxy":"","httpsProxy":"","noProxy":"","registryPasswordSecret":{"key":"","name":""},"registryUsernameSecret":{"key":"","name":""},"skipDBUpdate":false,"tokenSecret":{"key":"","name":""}}` | Additional Trivy configuration options |
| trivy.config.debugMode | bool | `false` | Enable debug mode for Trivy |
| trivy.config.githubTokenSecret | object | `{"key":"","name":""}` | Secret reference for GitHub token |
| trivy.config.githubTokenSecret.name | string | `""` | Secret name containing GitHub token for Trivy |
| trivy.config.githubTokenSecret.key | string | `""` | Key within secret containing GitHub token for Trivy |
| trivy.config.tokenSecret | object | `{"key":"","name":""}` | Secret reference for Trivy API token |
| trivy.config.tokenSecret.name | string | `""` | Secret name containing Trivy API token |
| trivy.config.tokenSecret.key | string | `""` | Key within secret containing Trivy API token |
| trivy.config.registryUsernameSecret | object | `{"key":"","name":""}` | Secret reference for registry username |
| trivy.config.registryUsernameSecret.name | string | `""` | Secret name containing registry username for Trivy |
| trivy.config.registryUsernameSecret.key | string | `""` | Key within secret containing registry username for Trivy |
| trivy.config.registryPasswordSecret | object | `{"key":"","name":""}` | Secret reference for registry password |
| trivy.config.registryPasswordSecret.name | string | `""` | Secret name containing registry password for Trivy |
| trivy.config.registryPasswordSecret.key | string | `""` | Key within secret containing registry password for Trivy |
| trivy.config.skipDBUpdate | bool | `false` | Skip database update on Trivy startup |
| trivy.config.dbRepository | string | `"ghcr.io/aquasecurity/trivy-db"` | Trivy database repository |
| trivy.config.httpProxy | string | `""` | HTTP proxy for Trivy |
| trivy.config.httpsProxy | string | `""` | HTTPS proxy for Trivy |
| trivy.config.noProxy | string | `""` | No proxy settings for Trivy |
| trivy.cache | object | `{"redis":{"enabled":false,"tls":false,"ttl":"","url":""}}` | Trivy cache configuration |
| trivy.cache.redis | object | `{"enabled":false,"tls":false,"ttl":"","url":""}` | Redis cache configuration for Trivy |
| trivy.cache.redis.enabled | bool | `false` | Enable Redis cache for Trivy |
| trivy.cache.redis.url | string | `""` | Redis URL for Trivy cache |
| trivy.cache.redis.ttl | string | `""` | Time-to-live for Redis cache entries |
| trivy.cache.redis.tls | bool | `false` | Enable TLS for Redis connection |
| trivy.probes | object | `{"liveness":{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1},"readiness":{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}}` | Liveness and readiness probe configuration for Trivy |
| trivy.probes.liveness | object | `{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Liveness probe configuration for Trivy |
| trivy.probes.liveness.initialDelaySeconds | int | `5` | Initial delay before liveness probe starts |
| trivy.probes.liveness.periodSeconds | int | `10` | Period between liveness probe checks |
| trivy.probes.liveness.successThreshold | int | `1` | Success threshold for liveness probe |
| trivy.probes.liveness.failureThreshold | int | `10` | Failure threshold for liveness probe |
| trivy.probes.readiness | object | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1}` | Readiness probe configuration for Trivy |
| trivy.probes.readiness.initialDelaySeconds | int | `5` | Initial delay before readiness probe starts |
| trivy.probes.readiness.periodSeconds | int | `10` | Period between readiness probe checks |
| trivy.probes.readiness.successThreshold | int | `1` | Success threshold for readiness probe |
| trivy.probes.readiness.failureThreshold | int | `3` | Failure threshold for readiness probe |
| trivy.serviceAccount | object | `{"annotations":{}}` | Service account configuration for Trivy |
| trivy.serviceAccount.annotations | object | `{}` | Annotations for Trivy service account |
| trivy.extraLabels | object | `{}` | Extra labels to add to Trivy resources |
| trivy.extraEnvVars | list | `[]` | Extra environment variables for Trivy container |
| trivy.service | object | `{"name":null,"port":4954,"sessionAffinity":"ClientIP","type":"ClusterIP"}` | Service configuration for Trivy |
| trivy.service.name | string | `nil` | Service name override for Trivy service (optional) |
| trivy.service.type | string | `"ClusterIP"` | Kubernetes service type |
| trivy.service.port | int | `4954` | Kubernetes service port |
| trivy.service.sessionAffinity | string | `"ClientIP"` | Kubernetes service session affinity |
| trivy.ingress | object | `{"annotations":{},"enabled":false,"hosts":[{"host":null}],"ingressClassName":null,"path":"/","pathType":"Prefix","tls":[]}` | Ingress configuration for Trivy |
| trivy.ingress.enabled | bool | `false` | Enable ingress for Trivy |
| trivy.ingress.ingressClassName | string | `nil` | Ingress class name for Trivy |
| trivy.ingress.annotations | object | `{}` | Annotations for Trivy ingress |
| trivy.ingress.hosts | list | `[{"host":null}]` | Hosts for Trivy ingress |
| trivy.ingress.hosts[0].host | string | `nil` | Hostname for Trivy ingress |
| trivy.ingress.path | string | `"/"` | Path for Trivy ingress |
| trivy.ingress.pathType | string | `"Prefix"` | Path type for Trivy ingress |
| trivy.ingress.tls | list | `[]` | TLS configuration for Trivy ingress |

