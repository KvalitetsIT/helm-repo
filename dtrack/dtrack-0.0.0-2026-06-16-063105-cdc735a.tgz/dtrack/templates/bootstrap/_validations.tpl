{{- define "dependencytrack.bootstrap.validateIdentities" -}}
{{- if .Values.bootstrap.enabled -}}
{{- $b := .Values.bootstrap | default dict -}}
{{- $teams := concat (dig "identities" "teams" (list) $b) (dig "identities" "extraTeams" (list) $b) -}}
{{- $users := concat (dig "identities" "users" (list) $b) (dig "identities" "extraUsers" (list) $b) -}}
{{- $groups := concat (dig "identities" "oidcGroups" (list) $b) (dig "identities" "extraOidcGroups" (list) $b) -}}
{{- $allRepos := concat ($b.repositories | default list) (dig "extraRepositories" (list) $b) -}}

{{/* userSync must be one of the accepted values */}}
{{- $userSync := dig "identities" "userSync" "" $b -}}
{{- if and $userSync (not (has $userSync (list "replace" "create" "ignore"))) -}}
  {{- fail (printf "bootstrap.identities.userSync: invalid value %q — must be one of: replace, create, ignore" $userSync) -}}
{{- end -}}

{{/* duplicate team names */}}
{{- $seen := list -}}
{{- range $teams -}}
  {{- if not .name -}}
    {{- fail "bootstrap.identities: a team entry is missing a 'name' field" -}}
  {{- end -}}
  {{- if has .name $seen -}}
    {{- fail (printf "bootstrap.identities: duplicate team name %q (check teams + extraTeams)" .name) -}}
  {{- end -}}
  {{- $seen = append $seen .name -}}
{{- end -}}

{{/* duplicate usernames */}}
{{- $seen = list -}}
{{- range $users -}}
  {{- $uname := dig "user" "username" "" . -}}
  {{- if not $uname -}}
    {{- fail "bootstrap.identities: a user entry is missing user.username" -}}
  {{- end -}}
  {{- if has $uname $seen -}}
    {{- fail (printf "bootstrap.identities: duplicate username %q (check users + extraUsers)" $uname) -}}
  {{- end -}}
  {{- $seen = append $seen $uname -}}
{{- end -}}

{{/* duplicate oidcGroup names */}}
{{- $seen = list -}}
{{- range $groups -}}
  {{- if not .name -}}
    {{- fail "bootstrap.identities: an oidcGroups entry is missing a 'name' field" -}}
  {{- end -}}
  {{- if has .name $seen -}}
    {{- fail (printf "bootstrap.identities: duplicate oidcGroup name %q (check oidcGroups + extraOidcGroups)" .name) -}}
  {{- end -}}
  {{- $seen = append $seen .name -}}
{{- end -}}

{{/* duplicate repositories (type + identifier) */}}
{{- $seen = list -}}
{{- range $allRepos -}}
  {{- if not .type -}}
    {{- fail "bootstrap.repositories: a repository entry is missing a 'type' field" -}}
  {{- end -}}
  {{- if not .identifier -}}
    {{- fail "bootstrap.repositories: a repository entry is missing an 'identifier' field" -}}
  {{- end -}}
  {{- $key := printf "%s/%s" .type .identifier -}}
  {{- if has $key $seen -}}
    {{- fail (printf "bootstrap.repositories: duplicate type/identifier %q (check repositories + extraRepositories)" $key) -}}
  {{- end -}}
  {{- $seen = append $seen $key -}}
{{- end -}}

{{/* cross-reference: team names in users/oidcGroups must exist in the managed teams list.
     Skipped when no teams are defined (operator may rely entirely on pre-existing teams). */}}
{{- if $teams -}}
{{- $teamNames := list -}}
{{- range $teams -}}
  {{- $teamNames = append $teamNames .name -}}
{{- end -}}
{{- range $users -}}
  {{- $uname := dig "user" "username" "" . -}}
  {{- range .teams -}}
    {{- if not (has . $teamNames) -}}
      {{- fail (printf "bootstrap.identities: user %q references unknown team %q — add it to identities.teams if it is managed by bootstrap" $uname .) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- range $groups -}}
  {{- $groupName := .name -}}
  {{- range .teams -}}
    {{- if not (has . $teamNames) -}}
      {{- fail (printf "bootstrap.identities: oidcGroup %q references unknown team %q — add it to identities.teams if it is managed by bootstrap" $groupName .) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- end -}}
{{- end -}}
