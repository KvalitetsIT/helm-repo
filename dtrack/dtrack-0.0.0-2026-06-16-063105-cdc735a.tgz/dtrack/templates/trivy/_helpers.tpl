{{- /*
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2019-2025 Aqua Security, Inc.
# Licensed under the Apache License, Version 2.0 (the "License");
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Modifications by: KvalitetsIT (2025)
# Modifications made:
# - Inlined and adapted for dtrack (2025-11-19).
*/}}
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "trivy.name" -}}
{{- printf "%s-trivy" (include "dependencytrack.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "trivy.fullname" -}}
{{- include "trivy.name" . -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "trivy.chart" -}}
{{- printf "%s-%s" (include "trivy.name" .) .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "trivy.labels" -}}
app.kubernetes.io/name: {{ include "trivy.name" . }}
helm.sh/chart: {{ include "trivy.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
