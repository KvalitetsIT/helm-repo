{{/*
Render a single SealedSecret.
dict: root (chart root $), name (default metadata.name), value (secret map; encryptedData required)
*/}}
{{- define "templates.sealedSecret" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $value := .value -}}
{{- if not $value.encryptedData }}
  {{- fail (printf "sealedSecrets.%s.encryptedData is required" $name) }}
{{- end }}
{{- $templateMetadata := (default dict $value.template).metadata | default dict }}
{{- $metadata := (include "templates.metadata" (dict "root" $root "metadata" (default dict $value.metadata) "name" $name) | fromYaml) }}
---
apiVersion: bitnami.com/v1alpha1
kind: SealedSecret
metadata:
  name: {{ $metadata.name | quote }}
  namespace: {{ $metadata.namespace | quote }}
  labels:
    {{- toYaml $metadata.labels | nindent 4 }}
  {{- with $metadata.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  encryptedData:
  {{- range $key, $secret := $value.encryptedData }}
    {{ $key }}: {{ $secret | quote }}
  {{- end }}
  template:
    metadata:
      labels:
        {{- include "templates.labels" $root | nindent 8 }}
        {{- with $templateMetadata.labels }}
          {{- tpl (toYaml .) $root | nindent 8 }}
        {{- end }}
      {{- with $templateMetadata.annotations }}
      annotations:
        {{- tpl (toYaml .) $root | nindent 8 }}
      {{- end }}
    type: {{ (default dict $value.template).type | default "Opaque" | quote }}
    {{- with (default dict $value.template).data }}
    data:
      {{- toYaml . | nindent 6 }}
    {{- end }}
{{- end -}}

{{/*
Render all entries in .Values.sealedSecrets. Honors enabled: false per entry.
*/}}
{{- define "templates.sealedSecrets" -}}
{{- $root := . -}}
{{- range $name, $value := ($root.Values.sealedSecrets | default dict) }}
{{- if and $value (ne $value.enabled false) }}
{{- include "templates.sealedSecret" (dict "root" $root "name" $name "value" $value) }}
{{- end }}
{{- end }}
{{- end -}}
