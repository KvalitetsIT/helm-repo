{{/*
Render a single CiliumNetworkPolicy.
dict: root (chart root $), name (default metadata.name), value (policy map; endpointSelector required)
*/}}
{{- define "templates.ciliumNetworkPolicy" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $value := .value -}}
{{- if not (hasKey $value "endpointSelector") }}
  {{- fail (printf "ciliumNetworkPolicies.%s.endpointSelector is required (use {} for all endpoints)" $name) }}
{{- end }}
{{- include "templates.cnp.applyDefaultPorts" $value }}
{{- $ingressRules := $value.ingress | default (list) }}
{{- $egressRules := $value.egress | default (list) }}
{{- $metadata := (include "templates.metadata" (dict "root" $root "metadata" (default dict $value.metadata) "name" $name) | fromYaml) }}
---
apiVersion: cilium.io/v2
kind: CiliumNetworkPolicy
metadata:
  name: {{ $metadata.name | quote }}
  namespace: {{ $metadata.namespace | quote }}
  labels:
    {{- toYaml $metadata.labels | nindent 4 }}
  {{- with $metadata.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- with $value.description }}
  description: {{ . | quote }}
  {{- end }}
  {{- if $egressRules }}
  egress:
    {{- tpl (toYaml $egressRules) $root | nindent 4 }}
  {{- end }}
  {{- if $value.egressDeny }}
  egressDeny:
    {{- tpl (toYaml $value.egressDeny) $root | nindent 4 }}
  {{- end }}
  {{- if $value.enableDefaultDeny }}
  enableDefaultDeny:
    {{- toYaml $value.enableDefaultDeny | nindent 4 }}
  {{- end }}
  endpointSelector:
    {{- tpl (toYaml $value.endpointSelector) $root | nindent 4 }}
  {{- if $ingressRules }}
  ingress:
    {{- tpl (toYaml $ingressRules) $root | nindent 4 }}
  {{- end }}
  {{- if $value.ingressDeny }}
  ingressDeny:
    {{- tpl (toYaml $value.ingressDeny) $root | nindent 4 }}
  {{- end }}
  {{- if $value.labels }}
  labels:
    {{- toYaml $value.labels | nindent 4 }}
  {{- end }}
  {{- if $value.log }}
  log:
    {{- toYaml $value.log | nindent 4 }}
  {{- end }}
{{- end -}}

{{/*
Render all entries in .Values.ciliumNetworkPolicies. Honors enabled: false per entry.
*/}}
{{- define "templates.ciliumNetworkPolicies" -}}
{{- $root := . -}}
{{- range $name, $value := ($root.Values.ciliumNetworkPolicies | default dict) }}
{{- if and $value (ne $value.enabled false) }}
{{- include "templates.ciliumNetworkPolicy" (dict "root" $root "name" $name "value" $value) }}
{{- end }}
{{- end }}
{{- end -}}
