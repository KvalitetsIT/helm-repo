{{/*
Standard Helm labels. Arg: chart root (.).
*/}}
{{- define "templates.labels" -}}
app.kubernetes.io/managed-by: "Helm"
app.kubernetes.io/instance: {{ .Release.Name | quote }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
{{- end }}

{{/*
Build and return a metadata map: resolves name/namespace defaults, merges labels (custom wins), preserves annotations.
dict: root (chart root $), name (default metadata.name), metadata (input metadata map)
*/}}
{{- define "templates.metadata" -}}
{{- $metadata := (default dict .metadata) -}}
{{- if and .name (not (hasKey $metadata "name")) -}}
{{- $_ := set $metadata "name" .name -}}
{{- end -}}
{{- if hasKey $metadata "name" -}}
{{- $_ := set $metadata "name" (tpl (get $metadata "name") .root) -}}
{{- end -}}
{{- $namespace := .namespace | default .root.Release.Namespace -}}
{{- if and $namespace (not (hasKey $metadata "namespace")) -}}
{{- $_ := set $metadata "namespace" $namespace -}}
{{- end -}}
{{- $commonLabels := (include "templates.labels" .root | fromYaml) -}}
{{- $customLabels := (default dict .metadata.labels) -}}
{{- $_ := set $metadata "labels" (merge $customLabels $commonLabels) -}}
{{- if .metadata.annotations -}}
{{- $_ := set $metadata "annotations" .metadata.annotations -}}
{{- end -}}
{{- toYaml $metadata -}}
{{- end }}

{{/*
Set default protocol (TCP) and stringify port for each CiliumNetworkPolicy toPorts entry. Mutates input in place.
*/}}
{{- define "templates.cnp.applyDefaultPorts" -}}
{{- range (concat (.ingress | default (list)) (.egress | default (list))) -}}
  {{- range (.toPorts | default (list)) -}}
    {{- range (.ports | default (list)) -}}
      {{- $_ := set . "protocol" (default "TCP" .protocol) -}}
      {{- $_ := set . "port" (required "Port is required" .port | toString) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end }}

{{/*
Set default protocol (TCP) for each NetworkPolicy ports entry. Mutates input in place.
*/}}
{{- define "templates.np.applyDefaultPortProtocols" -}}
{{- range (concat (.ingress | default (list)) (.egress | default (list))) -}}
  {{- range (.ports | default (list)) -}}
    {{- $_ := set . "protocol" (default "TCP" .protocol) -}}
    {{- $_ := set . "port" (required "Port is required" .port) -}}
  {{- end -}}
{{- end -}}
{{- end }}
