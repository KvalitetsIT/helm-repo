{{/*
Render a single Kubernetes resource. Strips the enabled key before rendering.
dict: root (chart root $), name (default metadata.name), value (full manifest map)
*/}}
{{- define "templates.resource" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $resource := deepCopy .value }}
{{- $_ := unset $resource "enabled" }}
{{- $metadata := (default dict $resource.metadata) }}
{{- $metadata := (include "templates.metadata" (dict "root" $root "metadata" $metadata "name" $name) | fromYaml) }}
{{- $_ := set $resource "metadata" $metadata }}
---
{{ tpl (toYaml $resource) $root }}
{{- end -}}

{{/*
Render all entries in .Values.resources. Honors enabled: false per entry.
*/}}
{{- define "templates.resources" -}}
{{- $root := . -}}
{{- range $name, $resource := ($root.Values.resources | default dict) }}
{{- if ne ($resource.enabled) false }}
{{- include "templates.resource" (dict "root" $root "name" $name "value" $resource) }}
{{- end }}
{{- end }}
{{- end -}}
