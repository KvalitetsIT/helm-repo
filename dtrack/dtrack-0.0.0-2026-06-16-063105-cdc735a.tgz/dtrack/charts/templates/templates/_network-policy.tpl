{{/*
Render a single NetworkPolicy.
dict: root (chart root $), name (default metadata.name), value (policy map; podSelector required)
*/}}
{{- define "templates.networkPolicy" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $value := .value -}}
{{- if not (hasKey $value "podSelector") }}
  {{- fail (printf "networkPolicies.%s.podSelector is required (use {} for all pods)" $name) }}
{{- end }}
{{- include "templates.np.applyDefaultPortProtocols" $value }}
{{- $ingressRules := $value.ingress | default (list) }}
{{- $egressRules := $value.egress | default (list) }}
{{- $metadata := (include "templates.metadata" (dict "root" $root "metadata" (default dict $value.metadata) "name" $name) | fromYaml) }}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: {{ $metadata.name | quote }}
  namespace: {{ $metadata.namespace | quote }}
  labels:
    {{- toYaml $metadata.labels | nindent 4 }}
  {{- with $metadata.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  podSelector:
    {{- tpl (toYaml $value.podSelector) $root | nindent 4 }}
  {{- with $value.policyTypes }}
  policyTypes:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if $ingressRules }}
  ingress:
    {{- tpl (toYaml $ingressRules) $root | nindent 4 }}
  {{- end }}
  {{- if $egressRules }}
  egress:
    {{- tpl (toYaml $egressRules) $root | nindent 4 }}
  {{- end }}
{{- end -}}

{{/*
Render all entries in .Values.networkPolicies. Honors enabled: false per entry.
*/}}
{{- define "templates.networkPolicies" -}}
{{- $root := . -}}
{{- range $name, $value := ($root.Values.networkPolicies | default dict) }}
{{- if and $value (ne $value.enabled false) }}
{{- include "templates.networkPolicy" (dict "root" $root "name" $name "value" $value) }}
{{- end }}
{{- end }}
{{- end -}}
