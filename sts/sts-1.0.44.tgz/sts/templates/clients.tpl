{{- define "sts.clients" -}}
    {{- $temp := dict "clients" (list) -}}

    {{- range $name, $client := .Values.sts.clients }}
        {{- $noop := include "sts.client" $client | nindent 4 | append $temp.clients | set $temp "clients" -}}
    {{- end}}
    [
     {{- join "," $temp.clients -}}
    ]
{{- end}}

{{- define "sts.client" -}}
{
  {{- if (.certificate) }}
  "certificate": "/config/{{ .name}}.cer",
  {{- end }}
  {{- if (.caName) }}
  "caName": {{.caName | quote}},
  {{- end }}
    {{- if (.copyAttributes) }}
    "copyAttributes": [
        {{- range $index, $attribute := .copyAttributes}}
            {{- if $index}},{{- end}}
            {
              {{- if ($attribute.value) }}
              "attributeName": {{$attribute.name | quote}},
              "targetAttributeName": {{$attribute.value | quote}}
              {{ else }}
                "attributeName": {{$attribute.name | quote}}
              {{- end}}
            }
        {{- end}}
    ],
    {{- end }}
  {{- if (.signatureAlgorithm) }}
    "signatureAlgorithm": {{.signatureAlgorithm | quote}},
    {{- end }}
  "itSystem": {{.itSystem | quote}},
    "subject": {{.subject | quote}},
    "attributes": [
    {{- range $index, $attribute := .attributes}}
        {{- if $index}},{{- end}}
        {
          "name": {{$attribute.name | quote}},
          "value": {{$attribute.value | quote}}
        }
    {{- end}}
    ],
    {{- if (.allowedClaims)}}
    "allowedClaims": [
    {{- range $index, $claim := .allowedClaims}}
        {{- if $index}},{{- end}}
        {{$claim | quote}}
    {{- end }}
    ],
    {{- end }}
    "endpoints": [
    {{- range $index, $endpoint := .endpoints}}
        {{- if $index}},{{- end}}
        {
          "name": {{$endpoint.name | quote}},
          "audience": {{$endpoint.audience | quote}}
        }
    {{- end}}
    ]
}
{{- end}}

{{- define "sts.client.certs" -}}
{{- range $name, $client := .Values.sts.clients }}
  {{- if (.certificate) }}
  {{$name}}.cer: |
  {{- $client.certificate | nindent 4 }}
{{- end }}
{{- end }}
{{- end}}

{{- define "sts.trust.certs" -}}
{{- range $name, $value := .Values.sts.trust }}
  {{$name}}.cer: |
  {{- $value | nindent 4 }}
{{- end }}
{{- end}}