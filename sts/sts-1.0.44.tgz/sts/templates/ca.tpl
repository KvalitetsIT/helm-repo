{{- define "sts.cas" -}}
    {{- $temp := dict "cas" (list) -}}

    {{- range $name, $ca := .Values.sts.ca }}
    {{- $noop := include "sts.ca" $ca | nindent 4 | append $temp.cas | set $temp "cas" -}}
    {{- end}}
    [
      {{- join "," $temp.cas -}}
    ]
{{- end}}

{{- define "sts.ca" -}}
    {
      "caName": {{.name | quote}},
      "caPath": {{.file | quote}}
    }
{{- end}}
